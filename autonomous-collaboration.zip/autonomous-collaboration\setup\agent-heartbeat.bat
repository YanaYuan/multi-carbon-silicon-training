@echo off
REM {AGENT_NAME} Heartbeat - Windows Task Scheduler entry point
REM Delegates to heartbeat-runner.ps1 for business hours check + goal-heartbeat execution
REM Runs hourly on weekdays via Task Scheduler

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%USERPROFILE%\.{agent_name}\scripts\heartbeat-runner.ps1"
