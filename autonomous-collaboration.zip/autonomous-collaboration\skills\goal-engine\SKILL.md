---
name: goal-engine
description: "Goal-driven autonomous work engine. Define goals, decompose into tiered tasks (🟢auto/🟡review/🔴decision), track in Microsoft To Do, and drive progress via scheduled heartbeats. Use when user says '/goal', 'my goal is...', 'I want to achieve...', 'set a goal', 'goal create', 'goal list', 'goal pause', 'goal complete', or discusses objectives/targets/OKRs."
---

# Goal Engine — {AGENT_NAME} 的目标驱动引擎

将 {AGENT_NAME} 从被动的事件驱动升级为**主动的目标驱动**。用户定义目标 → {AGENT_NAME} 分解为分级任务 → 通过心跳机制自主推进 → 定期向 {OWNER_NAME} review。

## 核心概念

### 目标生命周期

```
创建 → 分解为任务 → 注册心跳 → 自动推进 → /review → 完成
 │         │            │           │           │        │
 │    TODO.md          scheduler   heartbeat    {OWNER_NAME}    archive
 └── goals.json ──────────────────────────────────────────┘
```

### 三级自治

| 等级 | 标记 | 含义 | 心跳行为 |
|------|------|------|----------|
| 🟢 绿色 | `[G]` | 自主执行 | 运行思维审计员 → 通过后执行 |
| 🟡 黄色 | `[Y]` | 做完待审 | 执行 → 产出保存 → 等 /review 时 {OWNER_NAME} 审核 |
| 🔴 红色 | `[R]` | 需先决策 | 不执行 → 记录阻塞原因 → 等 /review 时 {OWNER_NAME} 决策 |

## 使用方式

### 创建目标

**对话式**（推荐）：
用户直接说出目标，{AGENT_NAME} 提取关键信息：

> 用户：我的目标是在 3 月 28 日前完成 XiaoMei 产品规格书 v3
> {AGENT_NAME}：理解。让我确认几个关键信息...

{AGENT_NAME} 需要确认：
1. **名称** — 一句话（如 "Ship XiaoMei Spec v3"）
2. **成功指标** — 可衡量的完成标准
3. **截止日期** — 如有
4. **项目** — 所属项目（VSWork、Concordia 等）
5. **心跳频率** — 默认 `0 9,13,17 * * 1-5`（工作日 3 次/天）

**CLI 方式**：
```bash
node {HOME_DIR}/teams-tasks/.claude/skills/goal-engine/scripts/goals.js create \
  --name "Ship XiaoMei Spec v3" \
  --description "完成并分发 XiaoMei 产品规格书 v3" \
  --metric "Spec 发到群，团队确认收到" \
  --deadline "2026-03-28" \
  --project "VSWork"
```

### 分解目标为任务

创建目标后，立即进行任务分解：

1. **先调研** — 在动手拆分前，先理解这个目标的领域、上下文、已有进展
2. **再拆分** — 每个任务应可在 1 次心跳内完成（15-30 分钟工作量）
3. **标注等级** — 根据以下规则：
   - `[G]` 🟢 — 纯执行类：调研、起草、总结、搜索、分析
   - `[Y]` 🟡 — 有外部影响：发消息、创建文档、分享文件
   - `[R]` 🔴 — 需要判断：对外沟通、策略方向、重大决策
4. **排序** — 按逻辑依赖排序，前置任务在前

分解后写入 **`{HOME_DIR}/TODO.md`**（本地任务主存储）：

```markdown
## 🎯 Goal: {目标名}

> **Goal ID:** goal-{id}
> **Deadline:** {date}
> **Success Metric:** {metric}
> **Working Dir:** ~/Downloads/{project}/

| # | 等级 | 任务 | 状态 | 产出物 | 备注 |
|---|------|------|------|--------|------|
| 1 | `[G]` | 调研竞品 PM agent 产品 | ⬜ TODO | `memory/research-xxx.md` | ... |
| 2 | `[Y]` | 分享竞品分析到 Discuss VSWork | ⬜ TODO | `content/xxx.md` | 依赖 #1 |
| 3 | `[R]` | 确认产品定位方向 | ⬜ TODO | — | 需 {OWNER_NAME} 决策 |
```

**状态标记：** `⬜ TODO` | `🔄 IN PROGRESS` | `✅ DONE` | `⛔ BLOCKED`

> **为什么不用 Microsoft To Do？** 格式太受限，无法存放产出路径、依赖关系、备注等结构化信息。TODO.md 格式灵活，心跳直接读取，支持跨 session 持久化。

### 启动心跳 — Back-to-back 模式（像 Yama 一样）

目标创建 + 任务分解完成后，启动 goal scheduler：

```bash
# 启动 back-to-back 心跳（连续执行直到没活干）
python {HOME_DIR}/teams-tasks/.claude/skills/goal-engine/scripts/{agent_name}-goal-scheduler.py start {goalId}

# 手动跑 1 次心跳（测试用）
python {agent_name}-goal-scheduler.py once {goalId}

# 查看状态
python {agent_name}-goal-scheduler.py status

# 停止
python {agent_name}-goal-scheduler.py stop
```

**工作模式**：每次心跳做 1 个 TODO → 完成后立即开始下一个 → 直到：
- 连续 3 次 IDLE（所有任务被 🔴 阻塞）→ 自动停止，等 {OWNER_NAME} /review
- 连续 2 次失败 → 自动停止
- 12 小时窗口到期 → 自动停止

每个心跳产出 **HTML 报告**，保存在 `{HOME_DIR}/goal-logs/{goalId}/`，可在浏览器直接查看。

### 目标工作目录 — Folder Convention

每个目标在 `~/Downloads/{project}/` 下有独立工作空间：

```
~/Downloads/{project}/
  ├── PLAN.md          # 阶段性战略计划（{AGENT_NAME} 维护）
  ├── memory/          # 内部思考（调研、分析、笔记）
  ├── content/         # 对外产出（给 {OWNER_NAME} 看的）
  └── logs/            # 心跳日志的可读版本
```

- `memory/` — {AGENT_NAME} 的内部思考，不需要 {OWNER_NAME} review
- `content/` — 所有 [Y] 黄色任务的产出，放这里等 {OWNER_NAME} 审核
- `PLAN.md` — 阶段计划，用 "← WE ARE HERE" 标记当前阶段

### 管理目标

```bash
# 列出所有目标
node goals.js list

# 查看某个目标详情
node goals.js show <goalId>

# 暂停目标（停心跳）
node goals.js pause <goalId>

# 恢复目标
node goals.js resume <goalId>

# 完成目标
node goals.js complete <goalId>
```

## 状态文件

主文件：`{HOME_DIR}/goals.json`

```json
{
  "version": 1,
  "goals": [
    {
      "id": "goal-20260316-abc",
      "name": "Ship XiaoMei Spec v3",
      "description": "完成并分发 XiaoMei 产品规格书 v3",
      "successMetric": "Spec 发到 Discuss VSWork 群，团队确认收到",
      "deadline": "2026-03-28",
      "project": "VSWork",
      "status": "active",
      "todoListName": "🎯 Ship XiaoMei Spec v3",
      "heartbeatSchedule": "0 9,13,17 * * 1-5",
      "heartbeatTaskId": "task-xxx",
      "createdAt": "2026-03-16T19:00:00Z",
      "lastReviewAt": null,
      "stats": {
        "totalHeartbeats": 0,
        "tasksCompleted": 0,
        "tasksTotal": 0,
        "consecutiveIdles": 0,
        "consecutiveFailures": 0,
        "lastHeartbeatAt": null
      },
      "decisionLog": []
    }
  ]
}
```

## 与其他系统的关系

| 系统 | 关系 |
|------|------|
| **task-scheduler** | 心跳通过 recurring task 调度 |
| **TODO.md** | 任务存储在 `{HOME_DIR}/TODO.md`（本地 Markdown 文档） |
| **goal-heartbeat** | 每次心跳执行 1 个任务 |
| **review** | {OWNER_NAME} 按需 review 产出 + 决策 |
| **meditate** | 每晚反思"行动是否推进目标" |
| **heartbeat** | Dashboard 显示目标进度 |
| **memory-write** | 重大决策/里程碑写入 MEMORY.md |
| **goal-logs/** | 每次心跳写详细日志 |
