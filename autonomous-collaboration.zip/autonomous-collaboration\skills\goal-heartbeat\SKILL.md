---
name: goal-heartbeat
description: "Execute one heartbeat for a goal — pick ONE task from MS To Do, run thinking auditor (for green tasks), execute, update state. Triggered by scheduled tasks or manually via /goal-heartbeat. Each heartbeat does exactly one task to keep token usage low and quality high."
---

# Goal Heartbeat — 目标心跳执行引擎

每次心跳只做 **1 个 TODO**，保证 Token 充裕、产出质量高。

## 触发方式

1. **Back-to-back（主要模式）** — 由 `{agent_name}-goal-scheduler.py` 调用 `claude -p`，连续执行直到没活干
2. **手动触发** — `/goal-heartbeat` 或 `/goal-heartbeat {goalId}`

## 执行流程

### Step 0: Business Hours 检查

> **工作时间检查由外部调度器（Windows Task Scheduler heartbeat-runner.ps1）负责。**
> 心跳本身不再做时间检查，直接开始执行。
> 如果你是被 `claude -p` 或定时任务调用的，直接跳到 Step 1。

### Step 1: 读取目标上下文

```bash
# 读取目标详情
node {HOME_DIR}/teams-tasks/.claude/skills/goal-engine/scripts/goals.js show {goalId}

# 读取 TODO.md 任务列表
# 直接读取 {HOME_DIR}/TODO.md 中对应 Goal 的任务表格
# 找到 "## 🎯 Goal: {goal.name}" 下面的任务表

# 如果存在，读取项目 PLAN.md
# ~/Downloads/{project}/PLAN.md — 阶段计划 + "WE ARE HERE" 标记
```

同时读取上下文：
- 搜索 memory 获取项目相关记忆
- 读取最近 2 条心跳日志（避免重复工作）
- 读取 `~/Downloads/{project}/memory/` 中的调研笔记

### Step 1.5: 催办扫描（I9 Delegated Task Follow-up）

**在选择自己的任务之前，先扫描 `📤 Delegated Tasks` 区域。** 这一步优先级高于 Step 2。

```
读取 TODO.md 中 "📤 Delegated Tasks" 表格
对于每个 Status = ⏳ 的任务:
  today = date 命令获取真实日期（I6 规则）
  days_overdue = today - Due
  days_since_ping = today - Last_Ping（如果有）

  如果需要催办（满足以下任一条件）:
    - Due 是明天 且 Last_Ping 为空
    - days_overdue >= 1 且 days_since_ping >= 2（或从未 ping 过）
    - days_overdue >= 3 且尚未升级给 {OWNER_NAME}

  执行催办:
    1. 查 people.md 确认 Assignee 的沟通级别（I8）
    2. 用 ms-teams-chat 发催办消息到 Source 群/1:1
    3. 更新 TODO.md 中该行的 Last_Ping = today
    4. 如果 days_overdue >= 3，额外私聊通知 {OWNER_NAME}
    5. 记录到心跳日志

  如果对方已回复交付物:
    1. 读取交付物内容
    2. 对比原始 Deliverable 描述
    3. 通过 → 标 ✅ 已交付，群里确认
    4. 不通过 → Round += 1，指出缺失项
    5. Round >= 2 仍不通过 → 升级给 {OWNER_NAME}
```

**催办消息模板（按沟通级别调整措辞）：**
- 日常："Hi {name}，{task} 的进展怎么样了？deadline 是 {due}，有什么需要帮忙的吗？"
- 重要："你好 {name}，想跟进一下 {task}，原定 {due} 交付，目前进展如何？如果有阻塞请告诉我。"
- 关键级别不自动催办，升级给 {OWNER_NAME} 处理

### Step 2: 选择 1 个任务

优先级规则：
1. **最优先：`📥 External Tasks` 区域的未完成任务** — 外部分配的任务永远优先于内部 Goal 任务
2. **其次：未完成的 `[G]` 绿色任务** — {AGENT_NAME} 可自主执行
3. **如果只剩 `[Y]` 任务** — 选影响最大的 `[Y]` 任务
4. **如果只剩 `[R]` 任务** — 输出 `IDLE`，不执行任何任务
5. **不要重复上次心跳做的任务** — 检查最近的心跳日志

**外部任务抢占规则：**
- 当新的外部任务进入 TODO.md 时，当前 Goal 心跳**暂停**（不是取消）
- 暂停的 Goal 任务保持 `⬜ TODO` 或 `⏸️ PAUSED` 状态
- 外部任务全部完成后，心跳**自动恢复**被暂停的 Goal 任务，继续执行
- 恢复时从暂停点继续，不重复已完成的任务

**外部任务执行注意事项：**
- 执行中遇到不清楚的地方，用 ms-teams-chat skill 回到来源群聊追问分配人
- 完成后在来源群聊通知分配人
- 标记为 `✅ DONE (待{OWNER_NAME}审)` 而非直接 `✅ DONE`

### Step 3: 思维审计员（仅 [G] 任务）

**在执行 [G] 绿色任务前，必须回答 6 个审计问题：**

#### 1. 知识审计
> 我做了足够的调研吗？我是这个领域的专家了吗？
- 🟢 扎实：有足够调研基础，理解充分
- 🟡 合理但未验证：有基本理解，但缺少深度
- 🔴 薄弱：缺乏基础知识，需要先调研

#### 2. 用户证据审计
> 有真实用户/{OWNER_NAME}/团队说过支持或反对这个结论的话吗？
- 🟢 有直接引用/对话记录
- 🟡 有间接暗示，但没有明确表态
- 🔴 纯粹是我的假设，没有用户证据

#### 3. 数据审计
> 有可信的数据/数字支撑吗？来源是什么？
- 🟢 有可引用的数据来源
- 🟡 有大致估算，但未精确验证
- 🔴 无数据支撑，凭感觉

#### 4. 逻辑审计
> 从证据到结论的推理链条完整吗？有没有跳跃？
- 🟢 推理链完整，每一步都有支撑
- 🟡 大体合理，但有 1-2 处跳跃
- 🔴 逻辑链断裂，结论与证据脱节

#### 5. 假设审计
> 这个决策隐含了哪些假设？哪些没被验证？
- 🟢 假设已识别且大部分已验证
- 🟡 假设已识别但未验证
- 🔴 存在未被识别的隐含假设

#### 6. Pre-mortem
> 如果失败了，最可能是因为什么？
- 🟢 失败风险低且可控
- 🟡 有明确风险但可以缓解
- 🔴 高风险且后果不可逆

### 审计判定

| 综合结果 | 行动 |
|----------|------|
| 全部 🟢 | ✅ **EXECUTE** — 直接执行任务 |
| 任一 🟡 | ⚠️ **EXPERIMENT** — 缩小范围执行，标记为待审 |
| 任一 🔴 | 🛑 **STOP** — 不执行，加入 /review 队列等待调研/决策 |

### Step 4: 执行任务

- 专注于这 **1 个任务**，不要发散
- 产出物保存到 `~/Downloads/{project}/` 或记录在心跳日志中
- [Y] 任务的产出额外保存一份副本，供 /review 时 {OWNER_NAME} 审核
- 时间限制：每次心跳最多 15 分钟工作量

### Step 5: 更新状态

```bash
# 在 TODO.md 中将任务状态从 ⬜ TODO 改为 ✅ DONE
# 直接编辑 {HOME_DIR}/TODO.md，修改对应任务行的状态列

# 如果发现新子任务，直接在 TODO.md 的任务表格中添加新行

# 记录心跳日志
node {HOME_DIR}/teams-tasks/.claude/skills/goal-engine/scripts/goals.js log {goalId} \
  --task "{task title}" --tier "G" --outcome "completed" --audit-rating "green"

# 如果有策略变化，记录决策
node goals.js add-decision {goalId} --decision "..." --rationale "..."
```

### Step 6: 写心跳报告

在心跳日志基础上，将简要报告发送到 Teams self-chat（通过 scheduled task 机制自动完成）。

报告格式：
```
🎯 Goal Heartbeat #{n} — {goal.name}
任务: [G] 调研竞品 PM agent 产品
审计: 🟢🟢🟡🟢🟢🟢 → EXPERIMENT (缩小范围)
结果: ✅ 完成 — 聚焦 3 个主要竞品
产出: ~/Downloads/VSWork/competitor-analysis.md
下一步: [Y] 分享到 Discuss VSWork
进度: 6/15 | 截止: 3/28 (12天)
```

## 自动停止条件

| 条件 | 行为 |
|------|------|
| 连续 3 次 IDLE（只剩 [R] 任务） | 暂停心跳，通知 {OWNER_NAME} 需要 /review |
| 连续 2 次失败 | 暂停心跳，通知 {OWNER_NAME} 排查问题 |
| 所有任务完成（含外部任务） | 检查成功指标，触发目标完成流程 |
| 超过截止日期 | 标记 overdue，但继续执行 |

**Back-to-back 规则（适用于所有任务）：**
- 每次心跳完成一个任务后，检查 TODO.md 是否还有可执行的任务
- 如果有 → 立即开始下一次心跳，不等调度器
- 如果没有（全 IDLE/BLOCKED/DONE）→ 停止
- 外部任务触发的心跳也遵循此规则：做完一个外部任务后，如果还有其他外部任务或执行中产生了新子任务，继续执行

## 心跳日志目录

位置：`{HOME_DIR}/goal-logs/{goalId}/`

文件：
- `heartbeat-{YYYY-MM-DD-HHMM}.html` — 可在浏览器查看的 HTML 报告
- `heartbeat-{YYYY-MM-DD-HHMM}-raw.txt` — 原始文本备份
- `heartbeat-{YYYY-MM-DD-HHMM}.json` — 结构化心跳记录（由 goals.js log 写入）

## Folder Convention（学自 Yama）

每个目标在 `~/Downloads/{project}/` 下有独立工作空间：

| 目录 | 用途 | 谁看 |
|------|------|------|
| `memory/` | 内部思考（调研、分析、笔记） | {AGENT_NAME} 自己 |
| `content/` | 对外产出（[Y] 任务的产出） | **{OWNER_NAME} 审核** |
| `PLAN.md` | 阶段性战略计划 | 双方共享 |

**Folder 纪律：**
- 调研结果 → `memory/research-{topic}.md`
- 给 {OWNER_NAME} 看的产出 → `content/{name}.md`
- PLAN.md 用 `← WE ARE HERE` 标记当前阶段
- 只在阶段变化时更新 PLAN.md

## Thinking Auditor

思维审计员定义在 `{HOME_DIR}/thinking-auditor.md`。
在执行 [G] 任务前必须调用，6 步审计：知识 → 用户证据 → 数据 → 逻辑 → 假设 → Pre-mortem。

## 与 goal-engine 的关系

goal-engine 管理目标的生命周期（创建/暂停/完成），goal-heartbeat 负责**每次心跳的具体执行**。心跳通过 `{agent_name}-goal-scheduler.py` 的 back-to-back 模式调度（`claude -p`），连续执行直到没活干。
