/**
 * {AGENT_NAME} Review Dashboard — WebSocket Server
 * Bridges the review dashboard HTML with Claude CLI for real-time AI conversation.
 *
 * Usage:  node review-server.mjs [port]
 * Default port: 3457 (localhost only)
 *
 * Adapted from Concordia 0.2 POC dashboard_server.mjs for {AGENT_NAME}'s review workflow.
 */

import { createServer } from 'http';
import { spawn } from 'child_process';
import { resolve, dirname, extname } from 'path';
import { fileURLToPath } from 'url';
import { readFile, writeFile, unlink } from 'fs/promises';
import { existsSync } from 'fs';
import { createRequire } from 'module';

const CLAUDE_MODEL = process.env.CORTANA_REVIEW_MODEL || 'sonnet';

// ---------------------------------------------------------------------------
// Resolve Claude CLI launch command (Windows-aware)
// ---------------------------------------------------------------------------
async function resolveClaudeLaunch() {
  if (process.platform !== 'win32') {
    return { command: 'claude', baseArgs: [] };
  }

  try {
    const probe = spawn('where.exe', ['claude'], { stdio: ['ignore', 'pipe', 'ignore'] });
    let output = '';
    probe.stdout.on('data', (chunk) => { output += chunk.toString(); });

    await new Promise((res, rej) => {
      probe.on('close', (code) => (code === 0 ? res() : rej(new Error('where.exe failed'))));
      probe.on('error', rej);
    });

    const candidates = output.split(/\r?\n/).map(l => l.trim()).filter(Boolean);
    const cmdShim = candidates.find(l => l.toLowerCase().endsWith('.cmd'));
    if (cmdShim) {
      const installDir = dirname(cmdShim);
      const bundledNode = resolve(installDir, 'node.exe');
      const cliJs = resolve(installDir, 'node_modules', '@anthropic-ai', 'claude-code', 'cli.js');
      if (existsSync(cliJs)) {
        return { command: existsSync(bundledNode) ? bundledNode : 'node', baseArgs: [cliJs] };
      }
    }
  } catch { /* fall through */ }

  return { command: 'claude', baseArgs: [] };
}

const CLAUDE_LAUNCH = await resolveClaudeLaunch();

// ---------------------------------------------------------------------------
// Dependency: ws
// ---------------------------------------------------------------------------
let WebSocketServer;
try {
  const require = createRequire(import.meta.url);
  const ws = require('ws');
  WebSocketServer = ws.WebSocketServer || ws.Server;
} catch {
  console.error('Missing dependency: ws\n\n  npm install ws\n\nThen re-run.');
  process.exit(1);
}

// Check Claude CLI
try {
  const test = spawn(CLAUDE_LAUNCH.command, [...CLAUDE_LAUNCH.baseArgs, '--version'], { stdio: 'pipe' });
  await new Promise((ok, fail) => {
    test.on('close', (code) => (code === 0 ? ok() : fail()));
    test.on('error', fail);
  });
} catch {
  console.error('Claude CLI not found. Ensure "claude --version" works.');
  process.exit(1);
}

// ---------------------------------------------------------------------------
// Config
// ---------------------------------------------------------------------------
const __dirname = dirname(fileURLToPath(import.meta.url));
const CORTANA_ROOT = resolve(__dirname, '..', '..', '..', '..');  // {HOME_DIR}/teams-tasks
const TODO_PATH = resolve(CORTANA_ROOT, '..', 'TODO.md');          // {HOME_DIR}/TODO.md
const PORT = parseInt(process.argv[2] || '3457', 10);
const IDLE_TIMEOUT_MS = 120_000; // 2 min idle (reviews take longer)

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------
function cleanEnv() {
  const env = { ...process.env };
  for (const k of Object.keys(env)) {
    if (k.startsWith('CLAUDECODE') || k.startsWith('CLAUDE_CODE') || k.startsWith('ANTHROPIC_')) {
      delete env[k];
    }
  }
  return env;
}

function killSession(clientState, reason) {
  if (!clientState?.session) return;
  const { proc, idleTimer } = clientState.session;
  clearTimeout(idleTimer);
  try { proc?.stdin?.end(); } catch { /* ignore */ }
  try { proc?.kill(); } catch { /* ignore */ }
  clientState.session = null;
  console.log(`[session] killed — ${reason}`);
}

function resetIdleTimer(clientState) {
  if (!clientState.session) return;
  clearTimeout(clientState.session.idleTimer);
  clientState.session.idleTimer = setTimeout(() => {
    sendToClient(clientState, { type: 'error', text: 'Session timed out (2 min idle). Send another message to reconnect.' });
    killSession(clientState, 'idle timeout');
  }, IDLE_TIMEOUT_MS);
}

function sendToClient(clientState, obj) {
  if (clientState.ws && clientState.ws.readyState === 1) {
    clientState.ws.send(JSON.stringify(obj));
  }
}

function markDone(clientState, streamState) {
  if (streamState.doneSent) return;
  streamState.doneSent = true;
  sendToClient(clientState, { type: 'done' });
}

// ---------------------------------------------------------------------------
// Claude subprocess management
// ---------------------------------------------------------------------------
function buildSystemPrompt(ctx) {
  return [
    'You are {AGENT_NAME}, an autonomous product partner embedded in a review dashboard sidebar.',
    '{OWNER_NAME} is reviewing her task list. She clicks an item and talks to you about it.',
    '',
    '## Current Item Context',
    `- Task ID: ${ctx.itemId || ''}`,
    `- Task Title: ${ctx.itemTitle || ''}`,
    `- Task Description: ${ctx.itemDesc || ''}`,
    `- Section: ${ctx.sectionTitle || ''} (${ctx.sectionKey || ''})`,
    ctx.itemFile ? `- Deliverable File: ${ctx.itemFile}` : '',
    ctx.itemSource ? `- Source: ${ctx.itemSource}` : '',
    ctx.itemAssigner ? `- Assigned by: ${ctx.itemAssigner}` : '',
    ctx.itemDeadline ? `- Deadline: ${ctx.itemDeadline}` : '',
    ctx.itemNotes ? `- Notes: ${ctx.itemNotes}` : '',
    '',
    '## TODO.md Location',
    `- Path: ${TODO_PATH}`,
    '',
    '## Your Behavior',
    '- You have full read/write access to project files.',
    '- When {OWNER_NAME} makes a decision (Approve/Close/Reject/Hold), update TODO.md accordingly.',
    '- When she asks about a deliverable, read the file and summarize.',
    '- Be concise: under 200 words unless asked for detail.',
    '- Respond in whatever language {OWNER_NAME} uses (Chinese or English).',
    '- When updating TODO.md, preserve the exact table format.',
    '- After making changes, confirm what you did.',
  ].filter(Boolean).join('\n');
}

function spawnClaude(clientState, ctx) {
  killSession(clientState, 'new open');
  clientState.session = { proc: null, idleTimer: null, context: ctx, history: [], buffer: '' };
  sendToClient(clientState, { type: 'status', state: 'session_started' });
}

function handleClaudeMessage(clientState, msg, streamState) {
  const payload = msg.type === 'stream_event' ? msg.event : msg;

  if (payload.type === 'assistant' && payload.message) return;

  if (payload.type === 'content_block_delta') {
    const delta = payload.delta;
    if (delta && delta.type === 'text_delta' && delta.text) {
      streamState.hasText = true;
      sendToClient(clientState, { type: 'chunk', text: delta.text });
    }
    return;
  }

  if (payload.type === 'message_stop') return;

  if (msg.result !== undefined) {
    if (!streamState.hasText) {
      const text = typeof msg.result === 'string' ? msg.result : JSON.stringify(msg.result);
      streamState.hasText = true;
      sendToClient(clientState, { type: 'chunk', text });
    }
    return;
  }
}

async function sendMessage(clientState, text) {
  const history = clientState.session?.history || [];
  const ctx = clientState.session?.context;

  if (!ctx) {
    sendToClient(clientState, { type: 'error', text: 'No active session. Click an item to start.' });
    return;
  }

  history.push({ role: 'user', content: text });

  const systemPrompt = buildSystemPrompt(ctx);
  const parts = [
    '[System Context]',
    systemPrompt,
    '',
    '[Conversation]',
  ];
  for (const m of history) {
    parts.push(m.role === 'user' ? `User: ${m.content}` : `Assistant: ${m.content}`);
    parts.push('');
  }
  parts.push('Please respond to the latest user message above.');
  const fullPrompt = parts.join('\n');

  killSession(clientState, 'new message');

  const tmpFile = resolve(CORTANA_ROOT, `.claude/_tmp_review_prompt_${Date.now()}.txt`);
  try {
    await writeFile(tmpFile, fullPrompt, 'utf8');
  } catch (err) {
    console.error(`[claude] failed to write temp prompt: ${err.message}`);
    sendToClient(clientState, { type: 'error', text: 'Internal error preparing prompt.' });
    return;
  }

  const args = [
    '-p',
    '--model', CLAUDE_MODEL,
    '--permission-mode', 'bypassPermissions',
    '--output-format', 'stream-json',
    '--verbose',
    '--include-partial-messages',
    '--no-session-persistence',
  ];
  console.log(`[claude] spawning (${fullPrompt.length} chars): ${tmpFile}`);

  const proc = spawn(CLAUDE_LAUNCH.command, [...CLAUDE_LAUNCH.baseArgs, ...args], {
    stdio: ['pipe', 'pipe', 'pipe'],
    cwd: CORTANA_ROOT,
    env: cleanEnv(),
  });

  clientState.session = { proc, idleTimer: null, context: ctx, history, buffer: '', tmpFile };
  resetIdleTimer(clientState);

  const streamState = { doneSent: false, hasText: false };
  let responseText = '';
  let stderrText = '';

  proc.stdout.on('data', (chunk) => {
    resetIdleTimer(clientState);
    if (!clientState.session) return;
    const raw = chunk.toString();
    clientState.session.buffer += raw;

    let newlineIdx;
    while ((newlineIdx = clientState.session.buffer.indexOf('\n')) !== -1) {
      const line = clientState.session.buffer.slice(0, newlineIdx).trim();
      clientState.session.buffer = clientState.session.buffer.slice(newlineIdx + 1);
      if (!line) continue;

      try {
        const msg = JSON.parse(line);
        if (msg.type === 'content_block_delta' && msg.delta?.text) {
          responseText += msg.delta.text;
        } else if (msg.type === 'assistant' && msg.message?.content) {
          const c = msg.message.content;
          responseText = typeof c === 'string' ? c :
            c.filter(b => b.type === 'text').map(b => b.text).join('');
        } else if (msg.result !== undefined) {
          responseText = typeof msg.result === 'string' ? msg.result : JSON.stringify(msg.result);
        }
        handleClaudeMessage(clientState, msg, streamState);
      } catch {
        if (line.length > 0) {
          responseText += line;
          sendToClient(clientState, { type: 'chunk', text: line });
        }
      }
    }
  });

  proc.stderr.on('data', (chunk) => {
    const t = chunk.toString().trim();
    if (t) {
      stderrText += `${t}\n`;
      console.error(`[claude stderr] ${t}`);
    }
  });

  proc.on('close', (code) => {
    console.log(`[claude] exited with code ${code}`);
    if (responseText) {
      history.push({ role: 'assistant', content: responseText });
    }
    if (code === 0) {
      markDone(clientState, streamState);
    } else {
      const message = stderrText.trim() || `Claude exited with code ${code}.`;
      sendToClient(clientState, { type: 'error', text: message });
    }
    if (clientState.session && clientState.session.proc === proc) {
      clearTimeout(clientState.session.idleTimer);
      clientState.session.proc = null;
    }
    unlink(tmpFile).catch(() => {});
  });

  proc.on('error', (err) => {
    console.error(`[claude] spawn error: ${err.message}`);
    sendToClient(clientState, { type: 'error', text: `Failed to start Claude: ${err.message}` });
    unlink(tmpFile).catch(() => {});
  });

  try {
    const promptData = await readFile(tmpFile, 'utf8');
    proc.stdin.write(promptData);
    proc.stdin.end();
  } catch (err) {
    console.error(`[claude] failed to read temp prompt: ${err.message}`);
    sendToClient(clientState, { type: 'error', text: 'Internal error reading prompt.' });
    proc.kill();
  }
}

// ---------------------------------------------------------------------------
// HTTP server
// ---------------------------------------------------------------------------
const MIME = { '.html': 'text/html', '.js': 'application/javascript', '.css': 'text/css', '.json': 'application/json', '.png': 'image/png', '.jpg': 'image/jpeg', '.svg': 'image/svg+xml', '.md': 'text/plain; charset=utf-8' };

const httpServer = createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host}`);
  let pathname = decodeURIComponent(url.pathname);

  if (pathname === '/') {
    // Redirect to the latest review dashboard
    res.writeHead(200, { 'Content-Type': 'text/html' });
    res.end(`<!DOCTYPE html><html><head><title>{AGENT_NAME} Review Server</title>
<style>body{font-family:system-ui;max-width:600px;margin:40px auto;padding:0 20px}
a{color:#4361ee;text-decoration:none}a:hover{text-decoration:underline}</style></head>
<body><h2>{AGENT_NAME} Review Server</h2>
<p>Server is running. Open the review dashboard HTML file directly.</p>
<p style="color:#888;font-size:12px">WebSocket: ws://localhost:${PORT}</p></body></html>`);
    return;
  }

  // Serve files — support both CORTANA_ROOT and user home paths
  let filePath = pathname.startsWith('/~')
    ? resolve(process.env.USERPROFILE || process.env.HOME, pathname.slice(2))
    : resolve(CORTANA_ROOT, pathname.replace(/^\//, ''));

  try {
    const data = await readFile(filePath);
    const ext = extname(filePath).toLowerCase();
    res.writeHead(200, { 'Content-Type': MIME[ext] || 'application/octet-stream' });
    res.end(data);
  } catch {
    res.writeHead(404);
    res.end('Not found');
  }
});

// ---------------------------------------------------------------------------
// WebSocket server
// ---------------------------------------------------------------------------
const wss = new WebSocketServer({ server: httpServer });

wss.on('connection', (ws) => {
  console.log('[ws] new connection');
  const clientState = { ws, session: null };
  sendToClient(clientState, { type: 'status', state: 'connected' });

  ws.on('message', (raw) => {
    let msg;
    try { msg = JSON.parse(raw.toString()); } catch { return; }

    console.log(`[ws] received: ${msg.type}`);

    switch (msg.type) {
      case 'open': {
        const ctx = {
          itemId: msg.itemId || '',
          itemTitle: msg.item?.title || '',
          itemDesc: msg.item?.desc || '',
          itemFile: msg.item?.file || '',
          itemSource: msg.item?.source || '',
          itemAssigner: msg.item?.assigner || '',
          itemDeadline: msg.item?.deadline || '',
          itemNotes: msg.item?.notes || '',
          sectionTitle: msg.section?.title || '',
          sectionKey: msg.section?.key || '',
        };
        spawnClaude(clientState, ctx);
        break;
      }
      case 'message': {
        if (msg.text) sendMessage(clientState, msg.text);
        break;
      }
      case 'close': {
        killSession(clientState, 'client close');
        break;
      }
      default:
        console.log(`[ws] unknown type: ${msg.type}`);
    }
  });

  ws.on('close', () => {
    console.log('[ws] disconnected');
    killSession(clientState, 'ws disconnected');
  });

  ws.on('error', (err) => {
    console.error(`[ws] error: ${err.message}`);
  });
});

httpServer.listen(PORT, '127.0.0.1', () => {
  console.log(`\n  {AGENT_NAME} Review Server listening on http://localhost:${PORT}`);
  console.log(`  WebSocket: ws://localhost:${PORT}`);
  console.log(`  Claude model: ${CLAUDE_MODEL}`);
  console.log(`  Press Ctrl+C to stop\n`);
});

process.on('SIGINT', () => {
  console.log('\nShutting down...');
  wss.clients.forEach(ws => {
    try { ws.close(); } catch { /* ignore */ }
  });
  wss.close();
  httpServer.close();
  process.exit(0);
});

process.on('SIGTERM', () => {
  wss.close();
  httpServer.close();
  process.exit(0);
});
