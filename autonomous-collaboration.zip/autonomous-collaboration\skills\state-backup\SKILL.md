---
name: state-backup
version: "1.0.0"
description: "Version control and auto-backup for {AGENT_NAME}'s state files (MEMORY.md, INSTINCT.md, action-queue, scheduled-tasks, monitors, meditation-log). Uses git for versioning with timestamped snapshots. Runs daily via scheduled task or on-demand via /backup."
---

# State Backup — {AGENT_NAME} Version Control

Provides git-based version control for all {AGENT_NAME} state files, enabling rollback, diff, and audit trail.

## Usage

```bash
# Snapshot current state (auto-commit with timestamp)
node {HOME_DIR}/teams-tasks/.claude/skills/state-backup/scripts/backup.js snapshot

# Show recent state history
node backup.js log

# Show what changed since last snapshot
node backup.js diff

# Restore a specific file from a past snapshot
node backup.js restore <commit-hash> <filename>

# Show state file sizes and growth
node backup.js stats
```

## When to Invoke

- User says `/backup`, "backup my state", "snapshot"
- After significant changes (bulk memory update, meditation cycle)
- Before risky operations (MEMORY.md consolidation, instinct recalibration)
- User asks "what changed in my memory?" or "roll back my memory"

## What It Tracks

| File | Path | Why |
|------|------|-----|
| `MEMORY.md` | `{HOME_DIR}/MEMORY.md` | Persistent facts — most critical |
| `INSTINCT.md` | `{HOME_DIR}/INSTINCT.md` | Learned preferences |
| `action-queue.json` | `{HOME_DIR}/action-queue.json` | Proposal history |
| `scheduled-tasks.json` | `{HOME_DIR}/teams-tasks/scheduled-tasks.json` | Task definitions + state |
| `monitors.json` | `{HOME_DIR}/teams-tasks/monitors.json` | Chat monitor configs |
| `meditation-log.md` | `{HOME_DIR}/meditation-log.md` | Meditation history |
| `proposal-outcomes.jsonl` | `{HOME_DIR}/proposal-outcomes.jsonl` | Outcome audit trail |
| `SOUL.md` | `{HOME_DIR}/SOUL.md` | Identity (should never change, but tracked for safety) |

## How It Works

1. **Init**: Creates a `.git` repo at `{HOME_DIR}/state-snapshots/` with symlinks/copies of tracked files
2. **Snapshot**: Copies current state files → snapshot dir, `git add + commit` with timestamp
3. **Log**: `git log --oneline` over the snapshot repo
4. **Diff**: `git diff` against last commit
5. **Restore**: `git show <hash>:<file>` → restore to original location

## Auto-Backup Schedule

Runs as part of the nightly meditation cycle (23:30). Meditate calls `backup.js snapshot` in Phase 5 after logging.

Can also be scheduled independently:
```bash
node scheduler.js recurring "nightly-backup" "0 23 * * *" "Run state backup: node {HOME_DIR}/teams-tasks/.claude/skills/state-backup/scripts/backup.js snapshot"
```

## Safety

- **NEVER overwrites live state without explicit restore command**
- Snapshot dir is separate from live state (`state-snapshots/` vs root)
- Restore shows diff before applying
- Git history is append-only (no force pushes, no rebase)
