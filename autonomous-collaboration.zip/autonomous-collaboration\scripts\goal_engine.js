#!/usr/bin/env node
/**
 * goal_engine.js — Universalized goal state management engine.
 *
 * A direct, configurable adaptation of {AGENT_NAME}'s goals.js.
 * Replace the Configuration section below to fit any agent.
 *
 * Commands:
 *   create   --name "..." --description "..." --metric "..." --deadline "YYYY-MM-DD" --project "..."
 *   list
 *   show     <goalId>
 *   pause    <goalId>
 *   resume   <goalId>
 *   complete <goalId>
 *   log      <goalId> --task "..." --tier "G|Y|R" --outcome "completed|idle|failed" [--audit-rating "green|yellow|red"]
 *   update-stats <goalId> --field <field> --value <value>
 *   add-decision <goalId> --decision "..." --rationale "..."
 */

const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');

// --- Configuration (customize per agent) ---
const AGENT_HOME = path.join(os.homedir(), '.agent');  // Change to your agent's home
const GOALS_FILE = path.join(AGENT_HOME, 'goals.json');
const LOGS_DIR = path.join(AGENT_HOME, 'heartbeat-logs');

// --- Helpers ---

function ensureDirs() {
  if (!fs.existsSync(AGENT_HOME)) {
    fs.mkdirSync(AGENT_HOME, { recursive: true });
  }
  if (!fs.existsSync(LOGS_DIR)) {
    fs.mkdirSync(LOGS_DIR, { recursive: true });
  }
}

function loadGoals() {
  ensureDirs();
  if (!fs.existsSync(GOALS_FILE)) {
    return [];
  }
  try {
    const raw = fs.readFileSync(GOALS_FILE, 'utf-8');
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

function saveGoals(goals) {
  ensureDirs();
  fs.writeFileSync(GOALS_FILE, JSON.stringify(goals, null, 2), 'utf-8');
}

function generateId() {
  const ts = Date.now();
  const suffix = crypto.randomBytes(4).toString('hex');
  return `goal-${ts}-${suffix}`;
}

function findGoal(goals, goalId) {
  const goal = goals.find(g => g.id === goalId);
  if (!goal) {
    console.error(`Error: Goal not found: ${goalId}`);
    process.exit(1);
  }
  return goal;
}

function parseArgs(argv) {
  const args = {};
  let i = 0;
  while (i < argv.length) {
    const arg = argv[i];
    if (arg.startsWith('--')) {
      const key = arg.slice(2);
      const next = argv[i + 1];
      if (next && !next.startsWith('--')) {
        args[key] = next;
        i += 2;
      } else {
        args[key] = true;
        i += 1;
      }
    } else {
      if (!args._positional) args._positional = [];
      args._positional.push(arg);
      i += 1;
    }
  }
  return args;
}

function formatDate(iso) {
  if (!iso) return 'N/A';
  return new Date(iso).toISOString().replace('T', ' ').slice(0, 19);
}

function daysUntil(deadline) {
  if (!deadline) return null;
  const now = new Date();
  const dl = new Date(deadline);
  const diff = Math.ceil((dl - now) / (1000 * 60 * 60 * 24));
  return diff;
}

// --- Command Handlers ---

function cmdCreate(args) {
  const required = ['name', 'description', 'metric', 'deadline', 'project'];
  for (const field of required) {
    if (!args[field]) {
      console.error(`Error: Missing required flag --${field}`);
      process.exit(1);
    }
  }

  const goals = loadGoals();
  const goal = {
    id: generateId(),
    name: args.name,
    description: args.description,
    successMetric: args.metric,
    deadline: args.deadline,
    project: args.project,
    status: 'active',
    todoListName: `\u{1F3AF} ${args.name}`,
    heartbeatSchedule: '0 9,13,17 * * 1-5',
    createdAt: new Date().toISOString(),
    stats: {
      totalHeartbeats: 0,
      tasksCompleted: 0,
      tasksTotal: 0,
      consecutiveIdles: 0,
      consecutiveFailures: 0,
      lastHeartbeatAt: null,
    },
    decisionLog: [],
  };

  goals.push(goal);
  saveGoals(goals);

  console.log(`Goal created: ${goal.id}`);
  console.log(`  Name:     ${goal.name}`);
  console.log(`  Project:  ${goal.project}`);
  console.log(`  Deadline: ${goal.deadline}`);
  console.log(`  Status:   ${goal.status}`);
}

function cmdList() {
  const goals = loadGoals();
  if (goals.length === 0) {
    console.log('No goals found.');
    return;
  }

  console.log(`\n  ${'ID'.padEnd(30)} ${'Name'.padEnd(25)} ${'Status'.padEnd(10)} ${'Deadline'.padEnd(12)} Days Left`);
  console.log(`  ${'-'.repeat(30)} ${'-'.repeat(25)} ${'-'.repeat(10)} ${'-'.repeat(12)} ---------`);

  for (const g of goals) {
    const days = daysUntil(g.deadline);
    const daysStr = days !== null ? String(days) : 'N/A';
    console.log(`  ${g.id.padEnd(30)} ${(g.name || '').slice(0, 24).padEnd(25)} ${g.status.padEnd(10)} ${(g.deadline || '').padEnd(12)} ${daysStr}`);
  }
  console.log();
}

function cmdShow(goalId) {
  const goals = loadGoals();
  const g = findGoal(goals, goalId);
  const days = daysUntil(g.deadline);

  console.log(`\n  Goal: ${g.name}`);
  console.log(`  ID:          ${g.id}`);
  console.log(`  Description: ${g.description}`);
  console.log(`  Metric:      ${g.successMetric}`);
  console.log(`  Project:     ${g.project}`);
  console.log(`  Status:      ${g.status}`);
  console.log(`  Deadline:    ${g.deadline} (${days !== null ? days + ' days left' : 'N/A'})`);
  console.log(`  Created:     ${formatDate(g.createdAt)}`);
  console.log(`  Todo List:   ${g.todoListName}`);
  console.log(`  Schedule:    ${g.heartbeatSchedule}`);
  console.log();
  console.log(`  --- Stats ---`);
  console.log(`  Total Heartbeats:      ${g.stats.totalHeartbeats}`);
  console.log(`  Tasks Completed:       ${g.stats.tasksCompleted} / ${g.stats.tasksTotal}`);
  console.log(`  Consecutive Idles:     ${g.stats.consecutiveIdles}`);
  console.log(`  Consecutive Failures:  ${g.stats.consecutiveFailures}`);
  console.log(`  Last Heartbeat:        ${formatDate(g.stats.lastHeartbeatAt)}`);

  if (g.decisionLog.length > 0) {
    console.log();
    console.log(`  --- Decision Log (${g.decisionLog.length} entries) ---`);
    for (const d of g.decisionLog) {
      console.log(`  [${formatDate(d.timestamp)}] ${d.decision}`);
      if (d.rationale) {
        console.log(`    Rationale: ${d.rationale}`);
      }
    }
  }
  console.log();
}

function cmdPause(goalId) {
  const goals = loadGoals();
  const goal = findGoal(goals, goalId);

  if (goal.status === 'paused') {
    console.log(`Goal ${goalId} is already paused.`);
    return;
  }
  if (goal.status === 'completed') {
    console.error(`Error: Cannot pause a completed goal.`);
    process.exit(1);
  }

  goal.status = 'paused';
  saveGoals(goals);
  console.log(`Goal paused: ${goalId} ("${goal.name}")`);
}

function cmdResume(goalId) {
  const goals = loadGoals();
  const goal = findGoal(goals, goalId);

  if (goal.status === 'active') {
    console.log(`Goal ${goalId} is already active.`);
    return;
  }
  if (goal.status === 'completed') {
    console.error(`Error: Cannot resume a completed goal.`);
    process.exit(1);
  }

  goal.status = 'active';
  saveGoals(goals);
  console.log(`Goal resumed: ${goalId} ("${goal.name}")`);
}

function cmdComplete(goalId) {
  const goals = loadGoals();
  const goal = findGoal(goals, goalId);

  if (goal.status === 'completed') {
    console.log(`Goal ${goalId} is already completed.`);
    return;
  }

  goal.status = 'completed';
  goal.completedAt = new Date().toISOString();
  saveGoals(goals);
  console.log(`Goal completed: ${goalId} ("${goal.name}")`);
  console.log(`  Completed at: ${formatDate(goal.completedAt)}`);
}

function cmdLog(goalId, args) {
  if (!args.task) {
    console.error('Error: Missing required flag --task');
    process.exit(1);
  }
  if (!args.tier) {
    console.error('Error: Missing required flag --tier');
    process.exit(1);
  }
  if (!args.outcome) {
    console.error('Error: Missing required flag --outcome');
    process.exit(1);
  }

  const validTiers = ['G', 'Y', 'R'];
  if (!validTiers.includes(args.tier)) {
    console.error(`Error: --tier must be one of: ${validTiers.join(', ')}`);
    process.exit(1);
  }

  const validOutcomes = ['completed', 'idle', 'failed'];
  if (!validOutcomes.includes(args.outcome)) {
    console.error(`Error: --outcome must be one of: ${validOutcomes.join(', ')}`);
    process.exit(1);
  }

  const goals = loadGoals();
  const goal = findGoal(goals, goalId);

  const entry = {
    timestamp: new Date().toISOString(),
    goalId: goal.id,
    goalName: goal.name,
    task: args.task,
    tier: args.tier,
    outcome: args.outcome,
    auditRating: args['audit-rating'] || null,
  };

  // Update stats
  goal.stats.totalHeartbeats += 1;
  goal.stats.lastHeartbeatAt = entry.timestamp;

  if (args.outcome === 'completed') {
    goal.stats.tasksCompleted += 1;
    goal.stats.tasksTotal += 1;
    goal.stats.consecutiveIdles = 0;
    goal.stats.consecutiveFailures = 0;
  } else if (args.outcome === 'idle') {
    goal.stats.tasksTotal += 1;
    goal.stats.consecutiveIdles += 1;
    goal.stats.consecutiveFailures = 0;
  } else if (args.outcome === 'failed') {
    goal.stats.tasksTotal += 1;
    goal.stats.consecutiveIdles = 0;
    goal.stats.consecutiveFailures += 1;
  }

  // Write log file
  const logFileName = `heartbeat-${goal.id}-${Date.now()}.json`;
  const logFilePath = path.join(LOGS_DIR, logFileName);
  fs.writeFileSync(logFilePath, JSON.stringify(entry, null, 2), 'utf-8');

  saveGoals(goals);

  console.log(`Heartbeat logged for goal: ${goal.id}`);
  console.log(`  Task:    ${entry.task}`);
  console.log(`  Tier:    ${entry.tier}`);
  console.log(`  Outcome: ${entry.outcome}`);
  if (entry.auditRating) {
    console.log(`  Audit:   ${entry.auditRating}`);
  }
  console.log(`  Log:     ${logFilePath}`);
}

function cmdUpdateStats(goalId, args) {
  if (!args.field) {
    console.error('Error: Missing required flag --field');
    process.exit(1);
  }
  if (args.value === undefined || args.value === true) {
    console.error('Error: Missing required flag --value');
    process.exit(1);
  }

  const goals = loadGoals();
  const goal = findGoal(goals, goalId);

  const validFields = [
    'totalHeartbeats',
    'tasksCompleted',
    'tasksTotal',
    'consecutiveIdles',
    'consecutiveFailures',
    'lastHeartbeatAt',
  ];

  if (!validFields.includes(args.field)) {
    console.error(`Error: --field must be one of: ${validFields.join(', ')}`);
    process.exit(1);
  }

  const field = args.field;
  let value = args.value;

  // Coerce numeric fields
  if (field !== 'lastHeartbeatAt') {
    value = Number(value);
    if (isNaN(value)) {
      console.error(`Error: --value must be a number for field "${field}"`);
      process.exit(1);
    }
  }

  const oldValue = goal.stats[field];
  goal.stats[field] = value;
  saveGoals(goals);

  console.log(`Stats updated for goal: ${goal.id}`);
  console.log(`  Field: ${field}`);
  console.log(`  Old:   ${oldValue}`);
  console.log(`  New:   ${value}`);
}

function cmdAddDecision(goalId, args) {
  if (!args.decision) {
    console.error('Error: Missing required flag --decision');
    process.exit(1);
  }
  if (!args.rationale) {
    console.error('Error: Missing required flag --rationale');
    process.exit(1);
  }

  const goals = loadGoals();
  const goal = findGoal(goals, goalId);

  const entry = {
    timestamp: new Date().toISOString(),
    decision: args.decision,
    rationale: args.rationale,
  };

  goal.decisionLog.push(entry);
  saveGoals(goals);

  console.log(`Decision added to goal: ${goal.id}`);
  console.log(`  Decision:  ${entry.decision}`);
  console.log(`  Rationale: ${entry.rationale}`);
}

// --- Usage ---

function printUsage() {
  console.log(`
Usage: node goal_engine.js <command> [options]

Commands:
  create        --name "..." --description "..." --metric "..." --deadline "YYYY-MM-DD" --project "..."
  list          List all goals
  show          <goalId>
  pause         <goalId>
  resume        <goalId>
  complete      <goalId>
  log           <goalId> --task "..." --tier "G|Y|R" --outcome "completed|idle|failed" [--audit-rating "green|yellow|red"]
  update-stats  <goalId> --field <field> --value <value>
  add-decision  <goalId> --decision "..." --rationale "..."

Configuration:
  AGENT_HOME:  ${AGENT_HOME}
  GOALS_FILE:  ${GOALS_FILE}
  LOGS_DIR:    ${LOGS_DIR}
`);
}

// --- Main ---

function main() {
  const rawArgs = process.argv.slice(2);
  if (rawArgs.length === 0) {
    printUsage();
    process.exit(0);
  }

  const command = rawArgs[0];
  const rest = rawArgs.slice(1);
  const args = parseArgs(rest);
  const goalId = args._positional ? args._positional[0] : null;

  switch (command) {
    case 'create':
      cmdCreate(args);
      break;
    case 'list':
      cmdList();
      break;
    case 'show':
      if (!goalId) { console.error('Error: Missing <goalId>'); process.exit(1); }
      cmdShow(goalId);
      break;
    case 'pause':
      if (!goalId) { console.error('Error: Missing <goalId>'); process.exit(1); }
      cmdPause(goalId);
      break;
    case 'resume':
      if (!goalId) { console.error('Error: Missing <goalId>'); process.exit(1); }
      cmdResume(goalId);
      break;
    case 'complete':
      if (!goalId) { console.error('Error: Missing <goalId>'); process.exit(1); }
      cmdComplete(goalId);
      break;
    case 'log':
      if (!goalId) { console.error('Error: Missing <goalId>'); process.exit(1); }
      cmdLog(goalId, args);
      break;
    case 'update-stats':
      if (!goalId) { console.error('Error: Missing <goalId>'); process.exit(1); }
      cmdUpdateStats(goalId, args);
      break;
    case 'add-decision':
      if (!goalId) { console.error('Error: Missing <goalId>'); process.exit(1); }
      cmdAddDecision(goalId, args);
      break;
    default:
      console.error(`Unknown command: ${command}`);
      printUsage();
      process.exit(1);
  }
}

main();
