---
name: People & Teams
description: Team members, meetings, org relationships, expertise, communication levels
type: reference
---

## 沟通级别定义

每个人有两个维度：**质量要求**和**权限**。

### 质量要求（发消息前投入多少认知）

| 级别 | 含义 | 发消息前做什么 |
|------|------|-------------|
| **日常** | 团队内日常协作 | 直接说，自然表达 |
| **重要** | 需要注意表达质量 | 读上下文 → 想清楚对方关注什么 → 结构化表达（结论先行） |
| **关键** | 每句话都要斟酌 | 读所有相关上下文 → 分析对方提问的动机和关注点 → 找数据/事实支撑 → 金字塔结构组织 → 检查措辞 |

### 权限（能不能直接发）

| 级别 | 含义 | 怎么操作 |
|------|------|--------|
| **自由** | 可以直接发 | 发完让 {OWNER_NAME} 知道就行 |
| **审批** | 需要 {OWNER_NAME} 批准 | 草拟好 → 发给 {OWNER_NAME} 看 → 批准后再发 |
| **代笔** | 只准备材料 | 准备内容和建议 → {OWNER_NAME} 自己发 |

### 默认值

遇到不在列表中的人，默认 **重要 + 审批**（宁可谨慎）。

---

## Key Stakeholders

| 人 | Title | 沟通质量 | 权限 | 备注 |
|---|---|---|---|---|
| **Zhang Qi** | CVP | 关键 | 代笔 | 对PA代参会场景有明确兴趣 |

## Concordia & {AGENT_NAME} 团队

"Concordia and {AGENT_NAME}" Teams群，共20人。以下按职能分组。

### Leadership

| 人 | Title | 部门 | 邮箱 | 擅长/负责 | 沟通质量 | 权限 |
|---|---|---|---|---|---|---|
| **Allen Sun** | Partner Applied Science Mgr | MAI-A Ads BJ OPEX | hasun | 团队技术负责人，Applied Science 方向 | 重要 | 审批 |
| **Aibo Liu** | Principal PM Manager | China Online Business BJ | aiboliu | PM 团队负责人 | 重要 | 审批 |

### Product

| 人 | Title | 部门 | 邮箱 | 擅长/负责 | 沟通质量 | 权限 |
|---|---|---|---|---|---|---|
| **{OWNER_FULL_NAME}** | Senior Product Manager | — | {OWNER_ALIAS} | {AGENT_NAME} 项目 owner，我的直属搭档 | 日常 | 自由 |
| **Yuecong Yang** | Principal Product Manager | China Online Business BJ | yuecongyang | | 日常 | 自由 |
| **Shan Peng** | Principal Product Manager | China Online Business BJ | shanpeng | | 日常 | 自由 |
| **Mengmeng Zhao** | Senior Product Manager | China Online Business BJ | mengmengzhao | | 日常 | 自由 |
| **Danxia Wen** | Senior Product Manager | China Online Business BJ | danxiawen | | 日常 | 自由 |
| **Ruoqing Tang** | Senior Product Manager | China Online Business BJ | ruoqingtang | | 日常 | 自由 |
| **Yimeng Wu** | PM Intern | MAI-A MGMT BJ OPEX | t-yimengwu | | 日常 | 自由 |

### Engineering

| 人 | Title | 部门 | 邮箱 | 擅长/负责 | 沟通质量 | 权限 |
|---|---|---|---|---|---|---|
| **David Dai** | Principal Applied Scientist | MAI-A Ads BJ OPEX | daviddai | Concordia 核心开发，GitHub: daviddai_microsoft | 日常 | 自由 |
| **Dongyang Cui** | Principal Software Engineer | Win in China Project | dongyangcui | | 日常 | 自由 |
| **Xiao Chang** | Sr. Software Engineer | Win in China BJ | xiaochang | | 日常 | 自由 |
| **Zhiwei Gao** | Senior Software Engineer | Win in China BJ | zhiweigao | | 日常 | 自由 |
| **Lin Xu** | Sr. Software Engineer | Win in China BJ | linxu1 | | 日常 | 自由 |
| **Luyao Zhang** | Sr. Software Engineer | Win in China BJ | zhangluyao | | 日常 | 自由 |
| **Delong Liu** | Software Engineer 2 | Win in China Project | delongliu | 苏州办公 | 日常 | 自由 |

### Design

| 人 | Title | 部门 | 邮箱 | 擅长/负责 | 沟通质量 | 权限 |
|---|---|---|---|---|---|---|
| **Hepeng Wang** | Senior Designer | Win in China BJ | hepengwang | | 日常 | 自由 |

### 未确认 alias（org API 404）

| 人 | 记录的 alias | 备注 |
|---|---|---|
| Danny Gu | danny.gu | dannygu 查到的是 Danny Guillory（美国，不是团队成员） |
| Jian Liu | — | jianliu 查到的是 Jianbo Liu（ISD，不是团队成员） |
| Jing Zhang | jing.zhang | jingzhang 也 404 |
| Chenxu Lu | — | chenxulu 404 |

## 求助路由（持续积累中）

根据问题类型，优先找谁：

| 问题类型 | 找谁 | 来源 |
|---------|------|------|
| Concordia 技术实现 | David Dai | 核心开发者 |
| UI/视觉设计 | Hepeng Wang | 团队唯一设计师 |
| PM 方向/优先级 | {OWNER_FULL_NAME} | 项目 owner |
| 团队整体决策 | Allen Sun / Aibo Liu | Leadership |

> **注：** "擅长/负责"列会随协作交互持续更新。每天 TODO review 时，从心跳日志和群聊记录中提取新的人物信息回写此表。
- [2026-05-01] 不用实时转写，事后发录音或者transcription给你就行。但是我希望简化步骤，因为我直接打开teams meeting，加入会议，再打开recording太麻烦了。我希望只跟你说一句话，比如线下开会，你就都帮我搞定。
