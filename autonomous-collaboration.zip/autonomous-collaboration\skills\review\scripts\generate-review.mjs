/**
 * {AGENT_NAME} Review Dashboard — Generator
 *
 * Reads TODO.md, parses external tasks and goal tasks, generates review HTML.
 *
 * Usage:  node generate-review.mjs [--open] [--port 3457]
 *   --open    Open the generated HTML in the default browser
 *   --port N  WebSocket port to embed in generated HTML (default: 3457)
 *
 * Output: {HOME_DIR}/teams-tasks/outputs/_review.html
 */

import { readFile, writeFile } from 'fs/promises';
import { resolve, dirname } from 'path';
import { fileURLToPath } from 'url';
import { exec } from 'child_process';

const __dirname = dirname(fileURLToPath(import.meta.url));
const CORTANA_ROOT = resolve(__dirname, '..', '..', '..', '..');
const TODO_PATH = resolve(CORTANA_ROOT, '..', 'TODO.md');
const TEMPLATE_PATH = resolve(__dirname, 'review-template.html');
const OUTPUT_PATH = resolve(CORTANA_ROOT, 'outputs', '_review.html');

// ---------------------------------------------------------------------------
// Parse command line args
// ---------------------------------------------------------------------------
const args = process.argv.slice(2);
const shouldOpen = args.includes('--open');
const portIdx = args.indexOf('--port');
const wsPort = portIdx >= 0 ? parseInt(args[portIdx + 1], 10) : 3457;

// ---------------------------------------------------------------------------
// TODO.md Parser
// ---------------------------------------------------------------------------
function parseTodoMd(content) {
  const lines = content.split('\n');
  const items = [];
  let inExternalTable = false;
  let inGoalTable = false;
  let headerParsed = false;

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];

    // Detect External Tasks section
    if (line.includes('## 📥 External Tasks')) {
      inExternalTable = true;
      inGoalTable = false;
      headerParsed = false;
      continue;
    }

    // Detect other sections that end external tasks
    if (line.match(/^## [^📥]/) || line.match(/^---$/)) {
      if (inExternalTable && headerParsed) {
        inExternalTable = false;
      }
    }

    // Parse external task table rows
    if (inExternalTable && line.startsWith('|')) {
      // Skip header and separator rows
      if (line.includes('---') && line.includes('|---|')) {
        headerParsed = true;
        continue;
      }
      if (line.includes('| # |') || line.includes('| 等级 |')) continue;

      if (headerParsed) {
        const item = parseExternalTaskRow(line);
        if (item) items.push(item);
      }
    }
  }

  return items;
}

function parseExternalTaskRow(line) {
  // Split by | and trim
  const cells = line.split('|').map(c => c.trim()).filter((_, i, arr) => i > 0 && i < arr.length);
  // Expected: # | 等级 | 任务 | 状态 | 来源 | 分配人 | 截止 | 交付物 | 备注

  if (cells.length < 8) return null;

  const [id, level, task, status, source, assigner, deadline, deliverable, notes = ''] = cells;

  // Clean up markdown formatting
  const cleanId = id.trim();
  const cleanLevel = level.replace(/`/g, '').trim();
  const cleanTask = task.replace(/\*\*/g, '').replace(/~~(.*?)~~/g, '$1').trim();
  const cleanStatus = status.trim();
  const cleanSource = source.trim();
  const cleanAssigner = assigner.trim();
  const cleanDeadline = deadline.replace(/\*\*/g, '').replace(/~~/g, '').trim();
  const cleanDeliverable = deliverable.replace(/`/g, '').trim();
  const cleanNotes = notes.replace(/\*\*/g, '').trim();

  // Extract task title (before —)
  const titleMatch = cleanTask.match(/^(.+?)(?:\s*—\s*(.*))?$/);
  const title = titleMatch ? titleMatch[1].trim() : cleanTask;
  const desc = titleMatch && titleMatch[2] ? titleMatch[2].trim() : '';

  return {
    id: cleanId,
    level: cleanLevel,
    title,
    desc,
    status: cleanStatus,
    source: cleanSource,
    assigner: cleanAssigner,
    deadline: cleanDeadline,
    deliverable: cleanDeliverable,
    notes: cleanNotes,
  };
}

// ---------------------------------------------------------------------------
// Categorize items into dashboard sections
// ---------------------------------------------------------------------------
function categorize(items) {
  const sections = {
    decision: [],   // [R] items needing decision
    review: [],     // [Y] items needing review (not DONE)
    action: [],     // [G] TODO/IN PROGRESS items
    hold: [],       // HOLD items
    done: [],       // Completed items from last 7 days (for context)
  };

  for (const item of items) {
    const isDone = item.status.includes('DONE');
    const isHold = item.status.includes('HOLD');
    const isRemoved = item.status.includes('误判移除');
    const isBlocked = item.status.includes('BLOCKED');

    if (isRemoved) continue;

    if (isHold) {
      sections.hold.push(item);
    } else if (isDone) {
      // Check if this is a "DONE (待审)" or recently closed — still show in review if [Y] and awaiting
      if (item.level === '[Y]' && !item.notes.includes('Review 关闭') && !item.notes.includes('关闭')) {
        sections.review.push(item);
      } else {
        sections.done.push(item);
      }
    } else if (item.level === '[R]') {
      sections.decision.push(item);
    } else if (item.level === '[Y]') {
      if (item.status.includes('TODO') || item.status.includes('IN PROGRESS') || isBlocked) {
        sections.review.push(item);
      } else {
        sections.review.push(item);
      }
    } else if (item.level === '[G]') {
      if (!isDone) {
        sections.action.push(item);
      } else {
        sections.done.push(item);
      }
    } else {
      // No level or other — treat as done if done, otherwise action
      if (isDone) sections.done.push(item);
      else sections.action.push(item);
    }
  }

  return sections;
}

// ---------------------------------------------------------------------------
// Build dashboard JSON
// ---------------------------------------------------------------------------
function buildDashboardData(sections) {
  const today = new Date().toISOString().split('T')[0];

  function mapItem(item, sectionKey) {
    const iconMap = {
      decision: 'fa-solid fa-circle-exclamation',
      review: 'fa-solid fa-eye',
      action: 'fa-solid fa-bolt',
      hold: 'fa-solid fa-pause',
      done: 'fa-solid fa-check',
    };

    // Build context HTML
    const ctxParts = [];
    const labelMap = {
      decision: { icon: 'fa-solid fa-circle-exclamation', text: 'Needs Decision' },
      review: { icon: 'fa-solid fa-eye', text: 'Needs Review' },
      action: { icon: 'fa-solid fa-bolt', text: 'In Progress' },
      hold: { icon: 'fa-solid fa-pause', text: 'On Hold' },
    };
    const label = labelMap[sectionKey];
    if (label) {
      ctxParts.push(`<div class="ctx-label"><i class="${label.icon}"></i> ${label.text}</div>`);
    }
    if (item.source) ctxParts.push(`<strong>Source:</strong> ${escHtml(item.source)}<br>`);
    if (item.assigner) ctxParts.push(`<strong>Assigned by:</strong> ${escHtml(item.assigner)}<br>`);
    if (item.deadline) ctxParts.push(`<strong>Deadline:</strong> <span class="hl-red">${escHtml(item.deadline)}</span><br>`);
    if (item.desc) ctxParts.push(`<br>${escHtml(item.desc)}`);
    if (item.notes) ctxParts.push(`<br><em style="color:var(--text-3)">${escHtml(item.notes)}</em>`);

    // Build questions based on section
    let questions = [];
    if (sectionKey === 'decision') {
      questions = [{
        text: `${item.id}: ${item.title}<br><br>How do you want to proceed?`,
        options: [
          { icon: 'fa-solid fa-check', label: 'Approve & proceed' },
          { icon: 'fa-solid fa-pen', label: 'Discuss first' },
          { icon: 'fa-solid fa-clock', label: 'Defer / Hold' },
          { icon: 'fa-solid fa-xmark', label: 'Close / Cancel' },
        ]
      }];
    } else if (sectionKey === 'review') {
      questions = [{
        text: `${item.id}: ${item.title}<br><br>Review this item:`,
        options: [
          { icon: 'fa-solid fa-check', label: 'Approve & close' },
          { icon: 'fa-solid fa-eye', label: 'Show deliverable' },
          { icon: 'fa-solid fa-pen', label: 'Request changes' },
          { icon: 'fa-solid fa-clock', label: 'Hold for later' },
        ]
      }];
    } else if (sectionKey === 'action') {
      questions = [{
        text: `${item.id}: ${item.title}<br><br>What should I do?`,
        options: [
          { icon: 'fa-solid fa-play', label: 'Continue as planned' },
          { icon: 'fa-solid fa-pen', label: 'Change approach' },
          { icon: 'fa-solid fa-clock', label: 'Hold' },
        ]
      }];
    } else if (sectionKey === 'hold') {
      questions = [{
        text: `${item.id}: ${item.title}<br><br>This item is on hold.`,
        options: [
          { icon: 'fa-solid fa-play', label: 'Resume' },
          { icon: 'fa-solid fa-xmark', label: 'Close' },
          { icon: 'fa-solid fa-clock', label: 'Keep on hold' },
        ]
      }];
    }

    return {
      id: item.id,
      title: `${item.id} — ${item.title}`,
      desc: item.desc || item.notes?.slice(0, 120) || '',
      icon: iconMap[sectionKey] || 'fa-solid fa-circle',
      file: item.deliverable || '',
      source: item.source,
      assigner: item.assigner,
      deadline: item.deadline,
      notes: item.notes,
      context: ctxParts.join(''),
      questions,
    };
  }

  const dashSections = [];

  if (sections.decision.length > 0) {
    dashSections.push({
      key: 'decision',
      title: 'Needs Decision',
      icon: 'fa-solid fa-circle-exclamation',
      color: 'red',
      cardStyle: 'urgent',
      items: sections.decision.map(i => mapItem(i, 'decision')),
    });
  }

  if (sections.review.length > 0) {
    dashSections.push({
      key: 'review',
      title: 'Needs Review',
      icon: 'fa-solid fa-eye',
      color: 'amber',
      cardStyle: 'review',
      items: sections.review.map(i => mapItem(i, 'review')),
    });
  }

  if (sections.action.length > 0) {
    dashSections.push({
      key: 'action',
      title: 'In Progress',
      icon: 'fa-solid fa-bolt',
      color: 'purple',
      cardStyle: 'blocked',
      items: sections.action.map(i => mapItem(i, 'action')),
    });
  }

  if (sections.hold.length > 0) {
    dashSections.push({
      key: 'hold',
      title: 'On Hold',
      icon: 'fa-solid fa-pause',
      color: 'purple',
      cardStyle: 'blocked',
      items: sections.hold.map(i => mapItem(i, 'hold')),
    });
  }

  if (sections.done.length > 0) {
    dashSections.push({
      key: 'completed',
      title: 'Recently Completed',
      icon: 'fa-solid fa-circle-check',
      color: 'green',
      cardStyle: 'done',
      items: sections.done.map(i => mapItem(i, 'done')),
    });
  }

  return {
    project: '{AGENT_NAME} Review',
    lastUpdated: today,
    updatedBy: `review ${today}`,
    sections: dashSections,
  };
}

function escHtml(str) {
  return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

// ---------------------------------------------------------------------------
// Main
// ---------------------------------------------------------------------------
async function main() {
  console.log('Reading TODO.md...');
  const todoContent = await readFile(TODO_PATH, 'utf8');

  console.log('Parsing tasks...');
  const items = parseTodoMd(todoContent);
  console.log(`  Found ${items.length} items`);

  console.log('Categorizing...');
  const sections = categorize(items);
  console.log(`  Decision: ${sections.decision.length}, Review: ${sections.review.length}, Action: ${sections.action.length}, Hold: ${sections.hold.length}, Done: ${sections.done.length}`);

  const dashData = buildDashboardData(sections);

  console.log('Reading template...');
  let template = await readFile(TEMPLATE_PATH, 'utf8');

  // Inject data
  template = template.replace('/* __DASHBOARD_DATA__ */ {}', JSON.stringify(dashData));
  template = template.replace('/* __WS_PORT__ */ 0', String(wsPort));
  template = template.replace('/* __PROJECT_META__ */ {}', JSON.stringify({
    project: '{AGENT_NAME} Review',
    todoPath: TODO_PATH,
  }));

  console.log(`Writing ${OUTPUT_PATH}...`);
  await writeFile(OUTPUT_PATH, template, 'utf8');
  console.log('Done!');

  if (shouldOpen) {
    console.log('Opening in browser...');
    const cmd = process.platform === 'win32' ? `start "" "${OUTPUT_PATH}"`
      : process.platform === 'darwin' ? `open "${OUTPUT_PATH}"`
      : `xdg-open "${OUTPUT_PATH}"`;
    exec(cmd);
  }
}

main().catch(err => {
  console.error('Error:', err.message);
  process.exit(1);
});
