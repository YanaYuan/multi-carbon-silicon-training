#!/usr/bin/env node
/**
 * Scheduler CLI
 * 
 * Command-line interface for the scheduler service.
 * This script reads/writes to the same JSON file as SchedulerService.
 * 
 * Usage:
 *   scheduler remind <delay> <message>
 *   scheduler run-at <delay> <prompt>
 *   scheduler recurring <name> <interval|cron> <prompt>
 *   scheduler list
 *   scheduler cancel <task-id>
 *   scheduler status
 */

const fs = require('fs');
const http = require('http');
const path = require('path');
const { validateCronExpression, computeNextCronRunAtMs } = require('./cron-utils.js');

const HOME_DIR = process.env.HOME || process.env.USERPROFILE || '';
const CORTANA_HOME = path.join(HOME_DIR, '.{agent_name}');
const DAEMON_PORT = 11711;
const TOKEN_PATH = path.join(CORTANA_HOME, 'daemon.token');

// Store path (same as SchedulerService)
const STORE_DIR = path.join(CORTANA_HOME, 'teams-tasks');
const STORE_PATH = path.join(STORE_DIR, 'scheduled-tasks.json');

// ============================================================
// Utility functions
// ============================================================

/**
 * Extract --flag and --key=value options from args array.
 * Returns { flags, positional } where flags has parsed options
 * and positional has the remaining non-flag arguments.
 */
function parseFlags(args) {
  const flags = {};
  const positional = [];

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    if (arg === '--silent') {
      flags.silent = true;
    } else if (arg === '--lightweight') {
      flags.lightweight = true;
    } else if (arg === '--mcp-servers') {
      // Next arg is comma-separated server list
      i++;
      if (i < args.length) {
        flags.mcpServers = args[i].split(',').map(s => s.trim()).filter(Boolean);
      }
    } else if (arg.startsWith('--mcp-servers=')) {
      flags.mcpServers = arg.slice('--mcp-servers='.length).split(',').map(s => s.trim()).filter(Boolean);
    } else {
      positional.push(arg);
    }
  }

  return { flags, positional };
}

function readDaemonToken() {
  try {
    const token = fs.readFileSync(TOKEN_PATH, 'utf-8').trim();
    return token || null;
  } catch {
    return null;
  }
}

function apiRequest(method, apiPath, body) {
  return new Promise((resolve, reject) => {
    const token = readDaemonToken();
    if (!token) {
      const error = new Error('Daemon token unavailable');
      error.code = 'TOKEN_UNAVAILABLE';
      reject(error);
      return;
    }

    const bodyStr = body ? JSON.stringify(body) : undefined;
    const req = http.request({
      hostname: '127.0.0.1',
      port: DAEMON_PORT,
      path: apiPath,
      method,
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json',
        ...(bodyStr ? { 'Content-Length': Buffer.byteLength(bodyStr) } : {}),
      },
    }, (res) => {
      let data = '';
      res.on('data', (chunk) => {
        data += chunk.toString();
      });
      res.on('end', () => {
        try {
          resolve({ status: res.statusCode || 0, data: data ? JSON.parse(data) : {} });
        } catch {
          resolve({ status: res.statusCode || 0, data });
        }
      });
    });

    req.on('error', (error) => {
      reject(error);
    });

    req.setTimeout(5000, () => {
      const error = new Error('Daemon request timed out');
      error.code = 'ETIMEDOUT';
      req.destroy(error);
    });

    if (bodyStr) {
      req.write(bodyStr);
    }

    req.end();
  });
}

function isDaemonUnavailableError(error) {
  return error && (
    error.code === 'TOKEN_UNAVAILABLE' ||
    error.code === 'ECONNREFUSED' ||
    error.code === 'ECONNRESET' ||
    error.code === 'ETIMEDOUT'
  );
}

function extractApiError(response) {
  if (response && response.data && typeof response.data === 'object' && typeof response.data.error === 'string') {
    return response.data.error;
  }
  return `Daemon returned HTTP ${response?.status ?? 'unknown'}`;
}

async function getSchedulersViaDaemon() {
  const response = await apiRequest('GET', '/api/schedulers');
  if (response.status >= 200 && response.status < 300 && Array.isArray(response.data?.schedulers)) {
    return response.data.schedulers;
  }
  throw new Error(extractApiError(response));
}

async function deleteSchedulerViaDaemon(taskId) {
  const response = await apiRequest('DELETE', `/api/schedulers/${encodeURIComponent(taskId)}`);
  if (response.status >= 200 && response.status < 300) {
    return response.data;
  }
  throw new Error(extractApiError(response));
}

async function createTaskViaDaemon(taskInput) {
  try {
    const response = await apiRequest('POST', '/api/schedulers', taskInput);
    if (response.status >= 200 && response.status < 300 && response.data && response.data.scheduler) {
      return {
        backend: 'daemon',
        task: response.data.scheduler,
      };
    }

    const message = extractApiError(response);
    const error = new Error(message);
    error.code = 'DAEMON_REJECTED';
    error.status = response.status;
    throw error;
  } catch (error) {
    if (isDaemonUnavailableError(error)) {
      return null;
    }
    throw error;
  }
}

function materializeLocalTask(taskInput, now = Date.now()) {
  const id = `task-${now}-${Math.random().toString(36).slice(2, 8)}`;
  return {
    id,
    name: taskInput.name,
    ...(taskInput.description ? { description: taskInput.description } : {}),
    enabled: true,
    deleteAfterRun: taskInput.deleteAfterRun ?? (taskInput.schedule.kind === 'at'),
    ...(taskInput.silent ? { silent: true } : {}),
    ...(taskInput.lightweight ? { lightweight: true } : {}),
    ...(taskInput.mcpServers ? { mcpServers: taskInput.mcpServers } : {}),
    createdAtMs: now,
    updatedAtMs: now,
    schedule: taskInput.schedule,
    payload: taskInput.payload,
    state: {
      nextRunAtMs: taskInput.schedule.kind === 'at'
        ? taskInput.schedule.atMs
        : estimateNextRun(taskInput.schedule, now),
      runCount: 0,
    },
  };
}

async function createTask(taskInput) {
  const createdViaDaemon = await createTaskViaDaemon(taskInput);
  if (createdViaDaemon) {
    return createdViaDaemon;
  }

  const store = loadStore();
  const task = materializeLocalTask(taskInput);
  store.tasks.push(task);
  saveStore(store);

  return {
    backend: 'file',
    task,
    warning: 'Daemon unavailable; wrote directly to scheduler store.',
  };
}

function getTaskNextRunAtMs(task) {
  if (typeof task?.nextRun === 'number') {
    return task.nextRun;
  }
  if (typeof task?.state?.nextRunAtMs === 'number') {
    return task.state.nextRunAtMs;
  }
  if (task?.schedule?.kind === 'at' && typeof task.schedule.atMs === 'number') {
    return task.schedule.atMs;
  }
  return null;
}

function loadStore() {
  try {
    if (!fs.existsSync(STORE_PATH)) {
      return { version: 1, tasks: [] };
    }
    return JSON.parse(fs.readFileSync(STORE_PATH, 'utf-8'));
  } catch (e) {
    console.error(`Error loading store: ${e.message}`);
    return { version: 1, tasks: [] };
  }
}

function saveStore(store) {
  fs.mkdirSync(path.dirname(STORE_PATH), { recursive: true });
  const tmp = `${STORE_PATH}.${process.pid}.${Math.random().toString(16).slice(2)}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(store, null, 2), 'utf-8');
  fs.renameSync(tmp, STORE_PATH);
}

function parseDelay(input) {
  // 1. Relative delay: 10s, 5m, 2h, 1d
  const match = input.toLowerCase().match(/^(\d+)(s|m|h|d)$/);
  if (match) {
    const value = parseInt(match[1], 10);
    const unit = match[2];
    switch (unit) {
      case 's': return value * 1000;
      case 'm': return value * 60 * 1000;
      case 'h': return value * 60 * 60 * 1000;
      case 'd': return value * 24 * 60 * 60 * 1000;
      default: return null;
    }
  }

  // 2. Absolute time: ISO 8601 (2026-03-27T02:07:00) or HH:MM / HH:MM:SS
  const now = Date.now();
  let target = null;

  // Try HH:MM or HH:MM:SS (today or next occurrence)
  const timeMatch = input.match(/^(\d{1,2}):(\d{2})(?::(\d{2}))?$/);
  if (timeMatch) {
    const d = new Date();
    d.setHours(parseInt(timeMatch[1], 10), parseInt(timeMatch[2], 10), timeMatch[3] ? parseInt(timeMatch[3], 10) : 0, 0);
    target = d.getTime();
    // If the time already passed today, schedule for tomorrow
    if (target <= now) target += 24 * 60 * 60 * 1000;
  }

  // Try ISO 8601 or any Date-parseable string
  if (!target) {
    const parsed = new Date(input).getTime();
    if (!isNaN(parsed)) target = parsed;
  }

  if (target && target > now) {
    return target - now;
  }

  return null;
}

/**
 * Estimate next run time for CLI display purposes only.
 * The daemon (SchedulerService) validates and may recompute persisted tasks,
 * but the CLI still writes a concrete nextRunAtMs so tasks behave correctly
 * even before the daemon reloads the file.
 */
function estimateNextRun(schedule, fromMs) {
  if (schedule.kind === 'every') {
    return fromMs + schedule.everyMs;
  }
  return computeNextCronRunAtMs(schedule.expr, fromMs, { tz: schedule.tz });
}

function formatRelativeTime(ms) {
  const now = Date.now();
  const diff = ms - now;
  
  if (diff < 0) return 'now';
  
  const seconds = Math.floor(diff / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);
  
  if (days > 0) return `in ${days} day${days > 1 ? 's' : ''}`;
  if (hours > 0) return `in ${hours} hour${hours > 1 ? 's' : ''}`;
  if (minutes > 0) return `in ${minutes} minute${minutes > 1 ? 's' : ''}`;
  return `in ${seconds} second${seconds > 1 ? 's' : ''}`;
}

// ============================================================
// Commands
// ============================================================

async function cmdRemind(args) {
  if (args.length < 2) {
    console.error('Usage: scheduler remind <when> <message>');
    console.error('Examples: scheduler remind 10m "Call John"');
    console.error('          scheduler remind 14:30 "Call John"');
    process.exit(1);
  }

  const when = args[0];
  const message = args.slice(1).join(' ');
  const delayMs = parseDelay(when);

  if (!delayMs) {
    console.error(`Invalid time: ${when}`);
    console.error('Formats: 5m, 2h, 1d (relative) | 14:30 (clock) | 2026-03-27T14:30 (ISO)');
    process.exit(1);
  }
  
  const now = Date.now();
  const result = await createTask({
    name: `Reminder: ${message.slice(0, 30)}${message.length > 30 ? '...' : ''}`,
    schedule: { kind: 'at', atMs: now + delayMs },
    payload: { kind: 'message', text: message },
    deleteAfterRun: true,
  });
  const task = result.task;
  const nextRunAtMs = getTaskNextRunAtMs(task) ?? (now + delayMs);
  const triggerTime = new Date(nextRunAtMs);
  console.log(JSON.stringify({
    success: true,
    backend: result.backend,
    task: {
      id: task.id,
      name: task.name,
      triggerAt: triggerTime.toISOString(),
      relative: formatRelativeTime(nextRunAtMs),
    },
    ...(result.warning ? { warning: result.warning } : {}),
    message: `Reminder scheduled ${formatRelativeTime(nextRunAtMs)} at ${triggerTime.toLocaleTimeString()}`,
  }, null, 2));
}

async function cmdRecurring(args) {
  const { flags, positional } = parseFlags(args);

  if (positional.length < 3) {
    console.error('Usage: scheduler recurring <name> <interval|cron> <prompt> [--silent] [--lightweight] [--mcp-servers a,b]');
    console.error('Examples:');
    console.error('  scheduler recurring "inbox-check" 30m "Check my emails"');
    console.error('  scheduler recurring "daily-standup" "0 9 * * *" "Status report"');
    console.error('  scheduler recurring "keepalive" 5m "Check devbox" --silent --lightweight --mcp-servers devbox');
    process.exit(1);
  }

  const name = positional[0];
  const intervalOrCron = positional[1];
  const prompt = positional.slice(2).join(' ');

  try {
    const existingSchedulers = await getSchedulersViaDaemon();
    const existing = existingSchedulers.find(task => task.name === name);
    if (existing) {
      console.log(JSON.stringify({
        success: false,
        error: `A task named "${name}" already exists (${existing.id}). Cancel it first or use a different name.`,
      }, null, 2));
      process.exit(1);
    }
  } catch (error) {
    if (!isDaemonUnavailableError(error)) {
      throw error;
    }

    const store = loadStore();
    const existing = store.tasks.find(task => task.name === name);
    if (existing) {
      console.log(JSON.stringify({
        success: false,
        error: `A task named "${name}" already exists (${existing.id}). Cancel it first or use a different name.`,
      }, null, 2));
      process.exit(1);
    }
  }

  const now = Date.now();
  
  let schedule;
  const intervalMs = parseDelay(intervalOrCron);
  if (intervalMs !== null) {
    schedule = { kind: 'every', everyMs: intervalMs };
  } else {
    try {
      validateCronExpression(intervalOrCron);
    } catch (error) {
      console.error(error.message);
      console.error('Examples: "0 9 * * *", "*/15 * * * *", "0 9 1 * *", "@daily"');
      process.exit(1);
    }
    schedule = { kind: 'cron', expr: intervalOrCron };
  }
  
  const result = await createTask({
    name,
    schedule,
    payload: { kind: 'prompt', text: prompt },
    deleteAfterRun: false,
    ...(flags.silent ? { silent: true } : {}),
    ...(flags.lightweight ? { lightweight: true } : {}),
    ...(flags.mcpServers ? { mcpServers: flags.mcpServers } : {}),
  });
  const task = result.task;
  const nextRunAtMs = getTaskNextRunAtMs(task) ?? estimateNextRun(schedule, now);

  const scheduleDesc = schedule.kind === 'cron'
    ? `cron "${schedule.expr}"`
    : `every ${intervalOrCron}`;

  const flagsDesc = [
    flags.silent ? 'silent' : '',
    flags.lightweight ? 'lightweight' : '',
    flags.mcpServers ? `mcp:[${flags.mcpServers.join(',')}]` : '',
  ].filter(Boolean).join(', ');

  console.log(JSON.stringify({
    success: true,
    backend: result.backend,
    task: {
      id: task.id,
      name: task.name,
      schedule: task.schedule,
      ...(flags.silent ? { silent: true } : {}),
      ...(flags.lightweight ? { lightweight: true } : {}),
      ...(flags.mcpServers ? { mcpServers: flags.mcpServers } : {}),
      nextRunAt: new Date(nextRunAtMs).toISOString(),
      relative: formatRelativeTime(nextRunAtMs),
    },
    ...(result.warning ? { warning: result.warning } : {}),
    message: `Recurring task "${name}" scheduled (${scheduleDesc}${flagsDesc ? ', ' + flagsDesc : ''}). First run ${formatRelativeTime(nextRunAtMs)}.`,
  }, null, 2));
}

async function cmdList() {
  const tasks = await getSchedulersViaDaemon();
  const serialized = tasks.map(task => ({
    id: task.id,
    name: task.name,
    enabled: task.enabled,
    schedule: task.schedule,
    nextRunAt: task.nextRun ? new Date(task.nextRun).toISOString() : null,
    relative: task.nextRun ? formatRelativeTime(task.nextRun) : 'N/A',
    runCount: task.runCount,
    lastError: task.lastError,
    silent: !!task.silent,
    lightweight: !!task.lightweight,
    mcpServers: task.mcpServers || [],
    payloadKind: task.payloadKind,
  }));
  
  console.log(JSON.stringify({
    count: serialized.length,
    tasks: serialized,
  }, null, 2));
}

async function cmdRunAt(args) {
  const { flags, positional } = parseFlags(args);

  if (positional.length < 2) {
    console.error('Usage: scheduler run-at <when> <prompt> [--silent] [--lightweight] [--mcp-servers a,b]');
    console.error('Schedules a one-shot agent task (not a text-only reminder).');
    console.error('Examples: scheduler run-at 2h "Summarize transcripts"');
    console.error('          scheduler run-at 2h "Check dev box status" --silent --lightweight --mcp-servers devbox');
    console.error('          scheduler run-at 14:30 "Summarize transcripts"');
    console.error('          scheduler run-at 2026-03-27T14:30 "Summarize transcripts"');
    process.exit(1);
  }

  const when = positional[0];
  const prompt = positional.slice(1).join(' ');
  const delayMs = parseDelay(when);

  if (!delayMs) {
    console.error(`Invalid time: ${when}`);
    console.error('Formats: 5m, 2h, 1d (relative) | 14:30 (clock) | 2026-03-27T14:30 (ISO)');
    process.exit(1);
  }

  const now = Date.now();
  const result = await createTask({
    name: `Agent: ${prompt.slice(0, 30)}${prompt.length > 30 ? '...' : ''}`,
    schedule: { kind: 'at', atMs: now + delayMs },
    payload: { kind: 'prompt', text: prompt },
    deleteAfterRun: true,
    ...(flags.silent ? { silent: true } : {}),
    ...(flags.lightweight ? { lightweight: true } : {}),
    ...(flags.mcpServers ? { mcpServers: flags.mcpServers } : {}),
  });
  const task = result.task;

  const nextRunAtMs = getTaskNextRunAtMs(task) ?? (now + delayMs);
  const triggerTime = new Date(nextRunAtMs);
  console.log(JSON.stringify({
    success: true,
    backend: result.backend,
    task: {
      id: task.id,
      name: task.name,
      triggerAt: triggerTime.toISOString(),
      relative: formatRelativeTime(nextRunAtMs),
      silent: !!task.silent,
      lightweight: !!task.lightweight,
      mcpServers: task.mcpServers || [],
    },
    ...(result.warning ? { warning: result.warning } : {}),
    message: `Agent task scheduled ${formatRelativeTime(nextRunAtMs)} at ${triggerTime.toLocaleTimeString()}. Will run ${task.lightweight ? 'in lightweight mode' : 'with full tools'}.`,
  }, null, 2));
}

async function cmdCancel(args) {
  if (args.length < 1) {
    console.error('Usage: scheduler cancel <task-id>');
    process.exit(1);
  }
  
  const taskId = args[0];
  const tasks = await getSchedulersViaDaemon();
  const existing = tasks.find(task => task.id === taskId);
  if (!existing) {
    console.log(JSON.stringify({
      success: false,
      error: `Task not found: ${taskId}`,
    }, null, 2));
    process.exit(1);
  }

  await deleteSchedulerViaDaemon(taskId);
  
  console.log(JSON.stringify({
    success: true,
    removed: {
      id: existing.id,
      name: existing.name,
    },
    message: `Task "${existing.name}" cancelled.`,
  }, null, 2));
}

async function cmdStatus() {
  const tasks = await getSchedulersViaDaemon();
  const enabled = tasks.filter(task => task.enabled);
  const nextTask = enabled.length > 0
    ? enabled.reduce((min, task) => {
      if (typeof min.nextRun !== 'number') return task;
      if (typeof task.nextRun !== 'number') return min;
      return task.nextRun < min.nextRun ? task : min;
    })
    : null;
  
  console.log(JSON.stringify({
    taskCount: tasks.length,
    enabledCount: enabled.length,
    nextTask: nextTask ? {
      id: nextTask.id,
      name: nextTask.name,
      runAt: nextTask.nextRun ? new Date(nextTask.nextRun).toISOString() : null,
      relative: nextTask.nextRun ? formatRelativeTime(nextTask.nextRun) : 'N/A',
      silent: !!nextTask.silent,
      lightweight: !!nextTask.lightweight,
      mcpServers: nextTask.mcpServers || [],
    } : null,
  }, null, 2));
}

// ============================================================
// Main
// ============================================================

async function main() {
  const args = process.argv.slice(2);
  const command = args[0];

  switch (command) {
    case 'remind':
      await cmdRemind(args.slice(1));
      break;
    case 'run-at':
      await cmdRunAt(args.slice(1));
      break;
    case 'recurring':
      await cmdRecurring(args.slice(1));
      break;
    case 'list':
      await cmdList();
      break;
    case 'cancel':
      await cmdCancel(args.slice(1));
      break;
    case 'status':
      await cmdStatus();
      break;
    default:
      console.error('Scheduler CLI - Schedule reminders, agent tasks, and recurring tasks');
      console.error('');
      console.error('Commands:');
      console.error('  remind <when> <message>              Schedule a one-time reminder (text only)');
      console.error('  run-at <when> <prompt>               Schedule a one-time agent task');
      console.error('  recurring <name> <interval> <prompt>  Schedule a recurring agent task');
      console.error('  list                                  List all scheduled tasks');
      console.error('  cancel <task-id>                      Cancel a task');
      console.error('  status                                Show scheduler status');
      console.error('');
      console.error('<when> formats: 10s, 5m, 2h, 1d (relative) | 14:30 (clock) | 2026-03-27T02:07 (ISO)');
      console.error('Cron examples: "0 9 * * *", "*/15 * * * *", "0 9 1 * *", "@daily"');
      process.exit(1);
  }
}

main().catch((error) => {
  console.error(error instanceof Error ? error.message : String(error));
  process.exit(1);
});
