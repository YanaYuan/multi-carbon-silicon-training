---
name: autonomous-collaboration
description: "Give any Claude Code AI agent autonomous collaboration capabilities — proactive task execution via heartbeat, structured TODO management, help-seeking with people knowledge graph, communication level awareness, and thinking audit before decisions. Extracted from {AGENT_NAME} (AI co-PM) after 3 months of real-world iteration. Use this skill when building an AI agent that needs to: (1) autonomously manage and execute tasks, (2) collaborate with humans in group chats, (3) seek help from the right people, (4) communicate with appropriate quality and permission levels, or (5) make audited decisions."
---

# Autonomous Collaboration

> Real architecture from {AGENT_NAME} (AI co-PM), not a theoretical framework. Every rule comes from a real failure case.

## Quick Start

```bash
python scripts/init.py --agent-name MyAgent --owner-name Alice --home ~/.myagent
```

This generates all configured files and prints a CLAUDE.md snippet to paste.

## Architecture (3 layers)

| Layer | What | Files |
|-------|------|-------|
| **Permission** | What am I allowed to do (L0-L3) | [trust-levels.md](references/trust-levels.md) |
| **Capability** | How to collaborate + decision quality | [collaboration.md](references/collaboration.md) + [instincts.md](references/instincts.md) + [thinking-auditor.md](references/thinking-auditor.md) |
| **Scheduling** | Auto-wake and run tasks | [heartbeat_scheduler.py](scripts/heartbeat_scheduler.py) + [goal_engine.js](scripts/goal_engine.js) |

## 7 Behavior Modules

Details in [references/collaboration.md](references/collaboration.md). Each is independent — adopt what you need.

1. **Heartbeat System** — Auto-poll TODO, execute tasks back-to-back, stop when idle
2. **TODO Management** — `[G]` auto-execute / `[Y]` execute+review / `[R]` needs owner decision
3. **External Task Intake** — Detect assignments in group chat → confirm deliverable → record → execute
4. **Self-Commitment Tracking** — Said "I'll do X" → atomic write to TODO (not a separate step)
5. **Collaborative Task Follow-up & QA** — Track assigned tasks → remind before deadline → escalate if overdue → review deliverables → max 2 rounds feedback
6. **Thinking Audit** — 6 dimensions before major decisions → 🟢 GO / 🟡 EXPERIMENT / 🔴 STOP
7. **People Knowledge** — Expertise graph + help routing + communication levels, accumulated daily

## 9 Instincts

Details in [references/instincts.md](references/instincts.md). Auto-triggered at specific execution nodes.

| # | Rule | Prevents |
|---|------|----------|
| I1 | Post-send commitment check | Empty promises |
| I2 | Detect task assignments in chat | Missed tasks |
| I3 | Resume interrupted tasks | Forgotten WIP |
| I4 | Only track tasks assigned to owner | Wrong task attribution |
| I5 | Promise ≠ done | Premature task closure |
| I6 | Use machine clock, not prompt timestamp | Timezone bugs |
| I7 | Hit a wall → ask for help (context first → people.md → owner) | Producing garbage by brute force |
| I8 | Check audience before sending (quality × permission) | Inappropriate communication |
| I9 | Auto follow-up delegated tasks (remind → escalate → review deliverable) | Forgotten delegations |

## Thinking Auditor

Agent prompt in [references/thinking-auditor.md](references/thinking-auditor.md). Inline before `[G]` task execution.

6 steps: Knowledge → User Evidence → Data → Logic → Assumptions → Pre-mortem

## Key Design Decisions

- **Trust levels are the first gate** — L0 (read-only) → L1 (suggest) → L2 (execute) → L3 (autonomous). Defined in [references/trust-levels.md](references/trust-levels.md). All other rules operate within the current trust level.
- **Detection via AI semantic understanding** — not regex. The agent judges "is this a commitment?" contextually.
- **Thinking audit is an inline prompt** — not a separate script. Runs inside the heartbeat prompt.
- **TODO.md is the single source of truth** — no database needed.
- **People.md is a fallback** — always analyze current context first, then consult people.md for help routing.
- **Communication levels have 2 dimensions**: quality (日常/重要/关键) × permission (自由/审批/代笔). Default for unknowns: 重要+审批.

## File Structure

```
autonomous-collaboration/
├── SKILL.md                          ← This file
├── scripts/
│   ├── init.py                       ← One-click setup (creates everything)
│   ├── heartbeat_scheduler.py        ← Heartbeat daemon (python, calls claude -p)
│   └── goal_engine.js                ← Goal lifecycle (node CLI)
├── references/
│   ├── collaboration.md              ← 7 behavior modules (detailed)
│   ├── instincts.md                  ← 9 instincts (detailed, I1-I9)
│   ├── thinking-auditor.md           ← Thinking auditor prompt
│   └── trust-levels.md              ← PA trust levels (L0-L3)
├── assets/
│   ├── people.md.template            ← Team expertise graph template
│   └── todo.md.template              ← TODO.md initial template
├── templates/
│   ├── PLAN.md                       ← Goal planning template
│   ├── OUTWARD_GUARDRAILS.md         ← Communication guardrails
│   └── people.md                     ← Full people.md template with examples
├── skills/                           ← 9 skills (installed to {HOME}/teams-tasks/.claude/skills/)
│   ├── goal-engine/                  ← Goal CRUD & scheduling
│   ├── goal-heartbeat/               ← Heartbeat execution engine (incl. Step 1.5催办)
│   ├── heartbeat/                    ← Heartbeat dashboard
│   ├── meditate/                     ← Daily reflection & memory consolidation
│   ├── memory-search/                ← Semantic memory search
│   ├── review/                       ← Weekly review report generator
│   ├── state-backup/                 ← State file backup
│   ├── task-scheduler/               ← Cron-based task scheduling
│   └── todo-review/                  ← Daily TODO audit (灵魂拷问)
└── setup/
    ├── agent-heartbeat.bat           ← Windows Task Scheduler entry point
    └── heartbeat-runner.ps1          ← PowerShell heartbeat runner with business hours
```

## Requirements

- Python 3.8+ (`pip install markdown`)
- Node.js 16+ (no external deps)
- Claude Code CLI (`claude` command available)
