#!/usr/bin/env node
/**
 * Memory Search CLI - Thin HTTP client for VSCode Embedding Server
 * 
 * When VSCode is running: Uses embedding server for hybrid search (fast, accurate)
 * When offline: Falls back to direct Orama BM25 text search
 * 
 * Usage:
 *   node memory-search.js search "query" [--limit N] [--text-only]
 *   node memory-search.js stats
 *   node memory-search.js clear [--all]
 */

const fs = require('fs');
const path = require('path');
const http = require('http');
const zlib = require('zlib');
const { promisify } = require('util');

const gunzipAsync = promisify(zlib.gunzip);

const PORT = 11722;
const MEMORY_DIR = path.join(process.env.HOME || process.env.USERPROFILE || '', '.{agent_name}', 'memory');
const DB_PATH = path.join(MEMORY_DIR, 'daemon.orama.gz');
const DB_PATH_LEGACY = path.join(MEMORY_DIR, 'daemon.orama.json');
const FILES_PATH = path.join(MEMORY_DIR, 'indexed_files.json');
const CACHE_PATH = path.join(MEMORY_DIR, 'embedding_cache.gz');
const CACHE_PATH_LEGACY = path.join(MEMORY_DIR, 'embedding_cache.json');

// Orama modules location
const TEAMS_TASKS_NODE_MODULES = path.join(
  process.env.HOME || process.env.USERPROFILE || '', 
  '.{agent_name}', 'teams-tasks', 'node_modules'
);

// ═══════════════════════════════════════════════════════════════
// HTTP Client - Primary path when VSCode is running
// ═══════════════════════════════════════════════════════════════

function httpPost(endpoint, data) {
  return new Promise((resolve, reject) => {
    const postData = JSON.stringify(data);
    const req = http.request({
      hostname: '127.0.0.1',
      port: PORT,
      path: endpoint,
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(postData) },
      timeout: 30000
    }, (res) => {
      let body = '';
      res.on('data', chunk => body += chunk);
      res.on('end', () => {
        try {
          resolve({ status: res.statusCode, data: JSON.parse(body) });
        } catch { resolve({ status: res.statusCode, data: body }); }
      });
    });
    req.on('error', reject);
    req.on('timeout', () => { req.destroy(); reject(new Error('timeout')); });
    req.write(postData);
    req.end();
  });
}

function httpGet(endpoint) {
  return new Promise((resolve, reject) => {
    const req = http.request({
      hostname: '127.0.0.1',
      port: PORT,
      path: endpoint,
      method: 'GET',
      timeout: 5000
    }, (res) => {
      let body = '';
      res.on('data', chunk => body += chunk);
      res.on('end', () => {
        try {
          resolve({ status: res.statusCode, data: JSON.parse(body) });
        } catch { resolve({ status: res.statusCode, data: body }); }
      });
    });
    req.on('error', reject);
    req.on('timeout', () => { req.destroy(); reject(new Error('timeout')); });
    req.end();
  });
}

async function isServerRunning() {
  try {
    const res = await httpGet('/ping');
    return res.status === 200;
  } catch {
    return false;
  }
}

// ═══════════════════════════════════════════════════════════════
// Offline Fallback - Direct Orama BM25 search (text-only)
// ═══════════════════════════════════════════════════════════════

async function loadOrama() {
  try {
    const oramaPath = path.join(TEAMS_TASKS_NODE_MODULES, '@orama', 'orama');
    const orama = require(oramaPath);
    return orama;
  } catch {
    const orama = await import('@orama/orama');
    return orama;
  }
}

function loadMsgpack() {
  try {
    return require(path.join(TEAMS_TASKS_NODE_MODULES, '@msgpack', 'msgpack'));
  } catch {
    return null;
  }
}

async function offlineSearch(query, limit) {
  const { create, load, search: oramaSearch } = await loadOrama();
  const msgpack = loadMsgpack();

  if (!fs.existsSync(DB_PATH) && !fs.existsSync(DB_PATH_LEGACY)) {
    return { results: [], count: 0, mode: 'offline', error: 'Memory not initialized' };
  }

  // Schema matching memoryManager.ts
  const schema = {
    id: 'string', path: 'enum', source: 'enum', startLine: 'number',
    endLine: 'number', hash: 'string', model: 'string', text: 'string',
    updatedAt: 'number', embedding: 'vector[1536]',
  };

  let db;
  if (fs.existsSync(DB_PATH)) {
    const compressed = fs.readFileSync(DB_PATH);
    const decompressed = await gunzipAsync(compressed);

    // Try msgpack first (new format), fall back to JSON (legacy)
    let dbExport;
    if (msgpack) {
      try {
        dbExport = msgpack.decode(decompressed);
        db = create({ schema });
        load(db, dbExport);
      } catch {
        // Fall back to JSON
        dbExport = JSON.parse(decompressed.toString('utf-8'));
        db = create({ schema });
        load(db, dbExport);
      }
    } else {
      dbExport = JSON.parse(decompressed.toString('utf-8'));
      db = create({ schema });
      load(db, dbExport);
    }
  } else {
    const dbData = fs.readFileSync(DB_PATH_LEGACY, 'utf-8');
    const dbExport = JSON.parse(dbData);
    db = create({ schema });
    load(db, dbExport);
  }
  
  const results = await oramaSearch(db, {
    term: query,
    limit,
    properties: ['text'],
    threshold: 0
  });
  
  return {
    results: results.hits.map((h, _i, allHits) => {
      const score = h.score;
      // BM25 scores are unbounded (2-100+), normalize relative to top hit for meaningful confidence
      const maxScore = allHits[0]?.score || 1;
      const normalizedScore = score / maxScore;
      const confidence = normalizedScore >= 0.65 ? 'high' : normalizedScore >= 0.35 ? 'medium' : 'low';
      return {
        path: h.document.path,
        source: h.document.source,
        snippet: (h.document.text || '').slice(0, 300) + '...',
        score: score,
        confidence: confidence
      };
    }),
    count: results.count,
    mode: 'offline-bm25'
  };
}

async function offlineStats() {
  const { create, load, count } = await loadOrama();
  const msgpack = loadMsgpack();

  let dbFile;
  if (fs.existsSync(DB_PATH)) {
    dbFile = DB_PATH;
  } else if (fs.existsSync(DB_PATH_LEGACY)) {
    dbFile = DB_PATH_LEGACY;
  } else {
    return { error: 'Memory not initialized' };
  }

  const schema = {
    id: 'string', path: 'enum', source: 'enum', startLine: 'number',
    endLine: 'number', hash: 'string', model: 'string', text: 'string',
    updatedAt: 'number', embedding: 'vector[1536]',
  };

  let db;
  if (dbFile === DB_PATH) {
    const compressed = fs.readFileSync(dbFile);
    const decompressed = await gunzipAsync(compressed);
    let dbExport;
    if (msgpack) {
      try {
        dbExport = msgpack.decode(decompressed);
      } catch {
        dbExport = JSON.parse(decompressed.toString('utf-8'));
      }
    } else {
      dbExport = JSON.parse(decompressed.toString('utf-8'));
    }
    db = create({ schema });
    load(db, dbExport);
  } else {
    const dbData = fs.readFileSync(dbFile, 'utf-8');
    const dbExport = JSON.parse(dbData);
    db = create({ schema });
    load(db, dbExport);
  }

  const chunkCount = count(db);
  
  let fileCount = 0;
  if (fs.existsSync(FILES_PATH)) {
    fileCount = Object.keys(JSON.parse(fs.readFileSync(FILES_PATH, 'utf-8'))).length;
  }
  
  const sizeMB = (fs.statSync(dbFile).size / 1024 / 1024).toFixed(2);
  return { chunks: chunkCount, files: fileCount, sizeMB, mode: 'offline', format: dbFile.endsWith('.gz') ? 'gzip' : 'json' };
}

// ═══════════════════════════════════════════════════════════════
// Commands
// ═══════════════════════════════════════════════════════════════

async function search(query, limit, textOnly) {
  const serverUp = await isServerRunning();
  
  if (serverUp) {
    // Use embedding server (hybrid search)
    const res = await httpPost('/search', { query, limit, textOnly });
    // Add confidence labels to help agent avoid hallucination
    // Hybrid scores are 0-1 normalized — thresholds calibrated via 31-query sweep (2026-02-28)
    if (res.data && res.data.results) {
      res.data.results = res.data.results.map(r => ({
        ...r,
        confidence: r.score >= 0.65 ? 'high' : r.score >= 0.35 ? 'medium' : 'low'
      }));
    }
    return res.data;
  } else {
    // Offline fallback (BM25 only)
    return await offlineSearch(query, limit);
  }
}

async function stats() {
  const serverUp = await isServerRunning();
  
  if (serverUp) {
    const res = await httpGet('/stats');
    return { ...res.data, server: 'running' };
  } else {
    const offline = await offlineStats();
    return { ...offline, server: 'offline' };
  }
}

async function clearMemory(all = false) {
  const deleted = [];
  const errors = [];
  
  const filesToDelete = [DB_PATH, DB_PATH_LEGACY, FILES_PATH, ...(all ? [CACHE_PATH, CACHE_PATH_LEGACY] : [])];
  for (const file of filesToDelete) {
    if (fs.existsSync(file)) {
      try {
        fs.unlinkSync(file);
        deleted.push(path.basename(file));
      } catch (e) {
        errors.push({ file: path.basename(file), error: e.message });
      }
    }
  }
  
  return {
    message: 'Memory cleared. Restart VSCode to reindex.',
    deleted,
    errors: errors.length > 0 ? errors : undefined
  };
}

async function syncMemory() {
  const serverUp = await isServerRunning();
  if (!serverUp) {
    return { error: 'VSCode embedding server not running. Cannot sync.' };
  }
  const res = await httpPost('/sync', {});
  return res.data;
}

// ═══════════════════════════════════════════════════════════════
// Main
// ═══════════════════════════════════════════════════════════════

async function main() {
  const [cmd, ...args] = process.argv.slice(2);
  
  if (cmd === 'search') {
    let limit = 10, textOnly = false, queryParts = [];
    for (let i = 0; i < args.length; i++) {
      if (args[i] === '--limit') { limit = parseInt(args[++i]) || 10; }
      else if (args[i] === '--text-only') { textOnly = true; }
      else { queryParts.push(args[i]); }
    }
    const query = queryParts.join(' ');
    if (!query) { console.log(JSON.stringify({ error: 'Missing query' })); process.exit(1); }
    console.log(JSON.stringify(await search(query, limit, textOnly), null, 2));
  } 
  else if (cmd === 'stats') {
    console.log(JSON.stringify(await stats(), null, 2));
  }
  else if (cmd === 'clear') {
    console.log(JSON.stringify(await clearMemory(args.includes('--all')), null, 2));
  }
  else if (cmd === 'sync') {
    console.log(JSON.stringify(await syncMemory(), null, 2));
  }
  else {
    console.log(JSON.stringify({
      usage: 'node memory-search.js <command> [args]',
      commands: {
        'search "query" [--limit N] [--text-only]': 'Hybrid search (or text-only if offline)',
        'stats': 'Memory statistics',
        'sync': 'Re-sync daily notes & MEMORY.md into index',
        'clear [--all]': 'Clear memory (--all includes embedding cache)'
      },
      server: { port: PORT, status: await isServerRunning() ? 'running' : 'offline' }
    }));
    process.exit(1);
  }
}

main().catch(e => { console.error(JSON.stringify({ error: e.message })); process.exit(1); });
