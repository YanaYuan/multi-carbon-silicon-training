const { CronExpressionParser } = require('cron-parser');

function buildCronOptions(fromMs, options) {
  const parserOptions = {
    currentDate: new Date(fromMs),
  };

  if (options && options.tz) {
    parserOptions.tz = options.tz;
  }

  return parserOptions;
}

function validateCronExpression(expression, options) {
  CronExpressionParser.parse(expression, buildCronOptions(Date.now(), options));
}

function computeNextCronRunAtMs(expression, fromMs, options) {
  const interval = CronExpressionParser.parse(expression, buildCronOptions(fromMs, options));
  return interval.next().getTime();
}

module.exports = {
  validateCronExpression,
  computeNextCronRunAtMs,
};