---
name: task-scheduler
description: Schedule reminders, one-shot agent tasks, and recurring agent tasks via Teams self-chat. Use when user asks to "remind me", "do X in 2 hours", "check X every morning", "summarize Y at 6pm", or any time-delayed or periodic task automation request. Default to agent tasks (run-at, recurring) for anything requiring reasoning, tool use, or content generation. Only use remind for simple static text nudges.
---

# Task Scheduler

Schedule tasks via CLI. The daemon picks up changes via file watcher and executes them at the scheduled time.

## Task Types

| Type | payload.kind | Trigger behavior | Use for |
|------|-------------|------------------|---------|
| **Message** | `message` | Send static text to Teams | Simple nudges: "review PR", "take a break" |
| **Agent** | `prompt` | Run full Claude agent session (all tools), send result to Teams | Anything requiring reasoning or tools |

## CLI

Location: `node {HOME_DIR}/teams-tasks/.claude/skills/task-scheduler/scripts/scheduler.js`

### remind — Static text reminder (auto-deletes)

```bash
node scheduler.js remind <when> <message>
# when: 10s, 5m, 2h, 1d, 14:30, 2026-03-27T14:30:00
```

### run-at — One-shot agent task (auto-deletes)

```bash
node scheduler.js run-at <when> <prompt> [--silent] [--lightweight] [--mcp-servers server1,server2]
# when: 10s, 5m, 2h, 1d, 14:30, 2026-03-27T14:30:00
```

### recurring — Persistent agent task (runs until cancelled)

```bash
node scheduler.js recurring <name> <interval|cron> <prompt> [--silent] [--lightweight] [--mcp-servers server1,server2]
# interval: 30m, 2h, 1d
# cron: standard cron-parser syntax (5-field, optional seconds, aliases like @daily)
```

### list / cancel / status

```bash
node scheduler.js list
node scheduler.js cancel <task-id>
node scheduler.js status
```

`<when>` formats: `10s`, `5m`, `2h`, `1d` (relative) | `14:30` (clock time, wraps to tomorrow if past) | `2026-03-27T14:30:00` (absolute ISO).

Cron expressions are parsed with `cron-parser`, so the scheduler accepts standard cron syntax including:

- 5-field expressions like `"0 9 * * *"`
- step syntax like `"*/15 * * * *"`
- day-of-month / month / named month / named weekday fields like `"0 9 1 JAN MON-FRI"`
- predefined aliases like `@daily`, `@weekly`, `@monthly`

Invalid cron expressions are rejected at creation time with the parser's error message.

## Examples

```bash
node scheduler.js remind 10m "Call John"
node scheduler.js run-at 3h "Summarize today's MLADS meeting transcripts and save to ~/worklogs/summary.md"
node scheduler.js run-at 30m "Check my inbox for replies from Allen Sun and summarize" --silent
node scheduler.js recurring "standup" "0 9 * * *" "Generate status report from yesterday's git commits, emails, and meetings"
node scheduler.js recurring "billing-close" "0 9 1 * *" "Prepare the first-of-month finance summary"
node scheduler.js recurring "heartbeat" "*/15 * * * *" "Check service health and report exceptions"
node scheduler.js recurring "daily-brief" "@daily" "Summarize yesterday's priority emails and meetings"
node scheduler.js recurring "inbox" 30m "Summarize unread emails, flag anything from my manager"
node scheduler.js recurring "keepalive" 5m "Check dev box status" --silent --lightweight --mcp-servers devbox
```

## Task Options

These can be set on agent tasks via CLI flags (`run-at`, `recurring`) or by editing `{HOME_DIR}/scheduled-tasks.json` directly (top-level fields on the task object):

| Field | Type | Default | CLI Flag | Description |
|-------|------|---------|----------|-------------|
| `silent` | `boolean` | `false` | `--silent` | Suppress Teams message output. Task still executes fully, results just aren't sent to chat. Use for high-frequency tasks (e.g., keepalive every 5m) to avoid notification spam. |
| `lightweight` | `boolean` | `false` | `--lightweight` | Use minimal agent (cheaper model, fewer tools, single-line output). Good for simple check tasks. |
| `mcpServers` | `string[]` | all | `--mcp-servers a,b` | Whitelist of MCP servers to load for this task (e.g., `["devbox"]`). In lightweight mode this also trims tool schemas; in full mode it limits only MCP servers, not built-in tools. |
| `deleteAfterRun` | `boolean` | `false` | — | Auto-delete after first execution. Set automatically for `remind` and `run-at` tasks. |
| `timeoutMs` | `number` | `900000` | — | Max execution time in ms. Default: 15 min. Max: 2 hours. Set to `0` for no timeout (required for long-running tasks like meeting autopilot). Edit in `scheduled-tasks.json` directly. |

## Behavior

- **Reminders & run-at:** auto-delete after firing
- **Recurring:** persist until `cancel`
- **Missed tasks (<24h late):** run on startup catch-up
- **Missed tasks (>24h late):** skip, reschedule next occurrence
- **Concurrency:** tasks acquire agents from shared pool; wait if all busy
- **Storage:** `{HOME_DIR}/scheduled-tasks.json` (FileBackedStore, file watcher for CLI-daemon sync)

## Modifying Existing Tasks

> **Critical:** The daemon holds the authoritative copy of all tasks in memory. It periodically writes state back to `scheduled-tasks.json` (e.g., after each task run, keepalive cycles every 5 min). **Do NOT edit `scheduled-tasks.json` directly** — changes will be overwritten. Always use the daemon REST API.

### Daemon REST API (port 11711)

Auth: `Authorization: Bearer <token>` (token at `{HOME_DIR}/daemon.token`)

| Method | Endpoint | Purpose |
|--------|----------|---------|
| `GET` | `/api/schedulers` | List all tasks |
| `POST` | `/api/schedulers` | Create a new task (JSON body) |
| `PATCH` | `/api/schedulers/:id` | Update any task fields: `name`, `description`, `enabled`, `silent`, `lightweight`, `mcpServers`, `schedule`, `payload`, `timeoutMs` |
| `DELETE` | `/api/schedulers/:id` | Delete a task |
| `POST` | `/api/schedulers/:id/run` | Manually trigger a task |

### How to modify a task

Use `PATCH` with only the fields you want to change. Unspecified fields are left untouched.

```bash
TOKEN=$(cat {HOME_DIR}/daemon.token)

# Change timeout
curl -s -X PATCH -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  "http://127.0.0.1:11711/api/schedulers/<task-id>" \
  -d '{"timeoutMs": 1800000}'

# Change prompt — use "payload" with nested {kind, text}
# Both "text" and "prompt" are accepted as the text field
# ⚠️ On Windows, use Python to write the JSON file to avoid encoding issues with non-ASCII content
python3 -c "
import json, tempfile, os
patch = {'payload': {'kind': 'prompt', 'text': 'your new prompt here'}}
path = os.path.join(tempfile.gettempdir(), 'scheduler_patch.json')
with open(path, 'w', encoding='utf-8') as f:
    json.dump(patch, f, ensure_ascii=False)
print(path)
"
# Use the path printed above
curl -s -X PATCH -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json; charset=utf-8" \
  "http://127.0.0.1:11711/api/schedulers/<task-id>" \
  -d @/tmp/scheduler_patch.json

# ⚠️ Verification: The PATCH response and GET /api/schedulers list do NOT
# return the prompt text. Always verify by reading the storage file directly:
#   cat {HOME_DIR}/teams-tasks/scheduled-tasks.json | jq '.tasks[] | select(.id=="<task-id>") | .payload.text'

# Enable/disable
curl -s -X PATCH -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  "http://127.0.0.1:11711/api/schedulers/<task-id>" \
  -d '{"enabled": false}'
```
