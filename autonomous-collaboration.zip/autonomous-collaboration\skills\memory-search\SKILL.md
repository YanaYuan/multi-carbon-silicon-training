---
name: memory-search
description: Search past {AGENT_NAME} conversations using local semantic memory. Use when recalling previous discussions, finding what was decided, looking up information from earlier chats, or checking conversation history. Triggers on queries like "what did we discuss about X", "find previous conversation about Y", "search my memory for Z".
---

# Memory Search

Search {AGENT_NAME}'s layered memory for past conversations, daily notes, persistent facts, and external documents.

## Architecture

When VSCode is running, the CLI connects to a local embedding server for fast hybrid search. When offline, it falls back to BM25 text-only search.

```
VSCode running:  CLI → localhost:11722 → Hybrid (BM25 + vector)
VSCode offline:  CLI → Direct Orama → BM25 text-only
```

## Memory Layers

| Layer | Location | Source | What's Indexed |
|-------|----------|--------|----------------|
| **Sessions** | `~/.claude/projects/<project-hash>/` | `sessions` | Full conversation transcripts |
| **Daily Notes** | `{HOME_DIR}/memory/YYYY-MM-DD.md` | `memory` | Session summaries, decisions, action items |
| **Persistent Memory** | `{HOME_DIR}/MEMORY.md` | `memory` | Durable facts, preferences, project info |
| **External Dirs** | Configured paths | `files` | Obsidian vaults, project docs, notes |

## Quick Start

```bash
# Search all memory layers (hybrid when VSCode running)
node {HOME_DIR}/teams-tasks/.claude/skills/memory-search/scripts/memory-search.js search "project deadline" --limit 10

# Force text-only BM25 search (better for exact keyword matching)
node {HOME_DIR}/teams-tasks/.claude/skills/memory-search/scripts/memory-search.js search "Concordia causal graph" --limit 10 --text-only

# Re-sync modified daily notes into index without restarting VSCode
node {HOME_DIR}/teams-tasks/.claude/skills/memory-search/scripts/memory-search.js sync

# Check indexing stats
node {HOME_DIR}/teams-tasks/.claude/skills/memory-search/scripts/memory-search.js stats
```

## Search Strategy

**Always try `--text-only` if hybrid search returns poor results.** Hybrid mode can underrank exact keyword matches due to score normalization. Text-only (BM25) excels at finding specific terms, names, and phrases.

## Commands

| Command | Description |
|---------|-------------|
| `search "query" [--limit N] [--text-only]` | Search memory (hybrid by default) |
| `sync` | Re-sync daily notes & MEMORY.md into live index |
| `stats` | Show chunks indexed, files, server status |
| `clear` | Clear memory DB to trigger fresh reindex |
| `clear --all` | Clear all including embedding cache |

## Output Format

Search returns:
```json
{
  "results": [
    { "path": "session.jsonl", "source": "sessions", "snippet": "User: ...", "score": 0.89 }
  ],
  "count": 5,
  "mode": "hybrid"
}
```

**`mode` values:**
- `hybrid` — BM25 + vector search (VSCode server running)
- `fulltext` — BM25 only (`--text-only` flag)
- `offline-bm25` — BM25 fallback (VSCode not running)

## How It Works

- **Embedding server**: VSCode runs `localhost:11722` for CLI hybrid search
- **Auto-sync**: Sessions, daily notes, MEMORY.md, and external dirs index on startup
- **Hybrid search**: BM25 keyword + vector similarity (requires VSCode running)
- **Offline fallback**: BM25 text-only when VSCode not running
- **1000-token chunks** with 100-token overlap
- **Embeddings cached** to avoid recomputation

## Source Filter

Filter by memory layer:
```bash
# Sessions only
node {HOME_DIR}/teams-tasks/.claude/skills/memory-search/scripts/memory-search.js search "meeting notes" --source sessions

# Daily notes + MEMORY.md only  
node {HOME_DIR}/teams-tasks/.claude/skills/memory-search/scripts/memory-search.js search "preferences" --source memory

# External files only
node {HOME_DIR}/teams-tasks/.claude/skills/memory-search/scripts/memory-search.js search "design doc" --source files
```

## External Directories

Add external directories to index via VSCode settings:

```json
// settings.json
{
  "vswork.memory.externalDirs": [
    { "path": "~/Documents/Obsidian", "label": "notes" },
    { "path": "~/work/project-alpha/docs", "patterns": ["*.md"], "label": "project" }
  ]
}
```

**Options:**
| Option | Default | Description |
|--------|---------|-------------|
| `path` | required | Absolute path to directory |
| `patterns` | `["*.md", "*.txt"]` | File patterns to include |
| `recursive` | `true` | Search subdirectories |
| `label` | folder name | Label in search results |
| `enabled` | `true` | Enable/disable this directory |

**Use Cases:**
- **Obsidian vault**: Index your second brain for recall
- **Project docs**: Design docs, specs, README files
- **Meeting transcripts**: Exported recordings not from daemon
- **Shared folders**: OneDrive/SharePoint docs

## Anti-Hallucination Rules (CRITICAL)

Memory search returns chunks that **may or may not be relevant**. Follow these rules strictly:

1. **Check the score**: Each result has a `score` and `confidence` field.
   - `high` (≥0.7): Reliable — safe to cite directly
   - `medium` (0.4–0.7): Plausible — verify by cross-referencing or quoting exactly
   - `low` (<0.4): Noise — **DO NOT use these results**. Treat as irrelevant.

2. **Quote, don't interpret**: Copy the exact snippet when citing memory. Do NOT rephrase, infer, or extrapolate beyond what the snippet says.

3. **When results don't match the question**: If no result has high/medium confidence, say **"I don't have a clear memory of that"** instead of guessing. It's OK to not know.

4. **Don't conflate sources**: Each result is an independent chunk. Don't merge facts from different chunks into a single claim unless they clearly refer to the same thing.

5. **Prefer fewer, better results**: Use `--limit 3` for focused queries. More results = more noise = more hallucination risk.

6. **Verify surprising claims**: If a memory result seems unexpected or contradicts what you know, flag it: *"Memory suggests X, but this may be outdated or mismatched."*

## Epistemic Tag Retrieval Guards (CRITICAL)

MEMORY.md entries now carry epistemic tags: `[FACT]`, `[PLAN]`, `[DECISION]`, `[OPINION]`, `[DEPRECATED]`. When presenting memory results, you MUST respect these tags:

### Tag-Aware Presentation Rules

| Tag | How to Present | Example |
|-----|---------------|---------|
| `[FACT]` | Cite directly as ground truth | "{AGENT_NAME} uses Orama for local memory." |
| `[PLAN]` | **Always prefix with status qualifier** | "As of Feb 2, the **plan** was to migrate from Orama to pgvector. ⚠️ Current status unverified." |
| `[DECISION]` | Cite as decided, note execution unknown | "It was **decided** to use Work IQ + Brain synergy via CLI." |
| `[OPINION]` | Attribute to the person | "**Feng Sun believes** complexity management is the core moat." |
| `[DEPRECATED]` | **DO NOT cite**. Skip entirely. | *(omit from response)* |

### Inference Rules (for untagged entries)

If a memory result has no epistemic tag (e.g., from older sessions or daily notes), infer the type from language:

| Signal Words | Inferred Type | Treatment |
|-------------|---------------|-----------|
| "will", "plan to", "going to", "next step", "priorities", "needs to", "exploring" | → PLAN | Add "planned/intended" qualifier |
| "uses", "runs", "has", "is", "built with" | → FACT | Cite directly |
| "decided", "agreed", "chose", "strategy:" | → DECISION | Note as decided |
| "X thinks", "X believes", "X's insight", "thesis:" | → OPINION | Attribute to person |

### Staleness Detection

- **[PLAN] entries older than 30 days**: Flag as potentially stale: *"⚠️ This plan is from [date] — it may have been executed, changed, or abandoned."*
- **[DECISION] entries older than 60 days**: Note: *"This decision was made on [date]. Verify if still in effect."*
- **Conflicting entries**: If a [PLAN] and a [FACT] exist for the same topic, prefer the [FACT] and note the discrepancy.

### Critical Anti-Pattern

**NEVER DO THIS:**
> ❌ "David migrated from Orama to pgvector." (treating [PLAN] as [FACT])

**ALWAYS DO THIS:**
> ✅ "David currently uses Orama. There's a **plan** (from Feb 2) to migrate to pgvector, but this hasn't been confirmed as completed."

## Source Citation (REQUIRED)

When presenting information retrieved from memory, **always cite the source**. This builds trust and lets the user verify or revisit the original context.

**Citation format:**
- Include the **source type** (`sessions`, `memory`, or `files`)
- Include the **file path** or **date** (extract date from daily note filenames like `2026-01-28.md`, or session file names)
- **Quote the relevant snippet** from the result

**Examples:**
```
According to a past conversation (session: 2026-01-25T14-30.jsonl):
> "We decided to use Orama for local memory instead of a cloud vector DB."

From your daily notes (2026-01-28.md):
> "Action item: finalize the Teams integration polling interval."

From MEMORY.md:
> "David prefers TypeScript for all new code in src/."

From project docs (files: ~/Documents/Obsidian/project-alpha.md):
> "The deadline for Phase 2 is March 15, 2026."
```

**Rules:**
1. Never paraphrase memory results without attribution
2. If multiple sources confirm the same fact, cite the most authoritative one
3. If memory results are ambiguous or low-confidence (score < 0.5), say so explicitly
4. Use the `path` and `source` fields from search results to build citations

## Tips

- Use **specific keywords** for exact matching
- Use **natural language** for semantic search
- Memory grows over time with daemon usage
- Run `clear` after updates if old content pollutes results
- **Daily notes** are great for "what did we do yesterday?"
- **MEMORY.md** is great for "what are my preferences?"
- **Sessions** have full conversation context
- **External dirs** bring your existing knowledge

## File Locations

- DB: `{HOME_DIR}/memory/daemon.orama.gz` (gzip-compressed)
- Daily notes: `{HOME_DIR}/memory/YYYY-MM-DD.md`
- Persistent: `{HOME_DIR}/MEMORY.md`
- Sessions: `~/.claude/projects/<project-hash>/*.jsonl`
- External dirs config: `{HOME_DIR}/memory/external_dirs.json`

## See Also

- `memory-write` skill: How to write to daily notes and MEMORY.md
