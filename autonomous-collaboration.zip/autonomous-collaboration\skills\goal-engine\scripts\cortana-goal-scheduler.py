#!/usr/bin/env python3
"""
{AGENT_NAME} Goal Scheduler
======================
Runs goal heartbeats back-to-back via 'claude -p', like Yama.
Each heartbeat picks ONE task, executes it, updates state, then immediately starts the next.
Stops when: all tasks blocked (3 consecutive IDLEs), 2 consecutive failures, or 12h window expires.

Usage:
    python {agent_name}-goal-scheduler.py start <goalId>    # Start back-to-back heartbeats for a goal
    python {agent_name}-goal-scheduler.py stop               # Stop running scheduler
    python {agent_name}-goal-scheduler.py status              # Check current status
    python {agent_name}-goal-scheduler.py once <goalId>       # Run one heartbeat manually (for testing)
"""

import subprocess
import sys
import os
import json
import time
import signal
import io
import threading
from datetime import datetime, timedelta
from pathlib import Path

# Fix Windows UTF-8 output
if sys.platform == 'win32':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')

# Config
CORTANA_DIR = Path.home() / ".{agent_name}"
GOALS_FILE = CORTANA_DIR / "goals.json"
LOGS_DIR = CORTANA_DIR / "goal-logs"
STATE_FILE = CORTANA_DIR / "goal-logs" / "scheduler-state.json"
PID_FILE = CORTANA_DIR / "goal-logs" / "scheduler.pid"
GOALS_JS = Path.home() / ".{agent_name}" / "teams-tasks" / ".claude" / "skills" / "goal-engine" / "scripts" / "goals.js"
CLAUDE_CMD = "claude"
MAX_HEARTBEATS = 999
INTERVAL_SECONDS = 0  # back-to-back, like Yama
MAX_CONSECUTIVE_IDLE = 3
MAX_CONSECUTIVE_FAILURES = 2
MAX_HOURS = 12

# --- HTML Report Template ---
HTML_TEMPLATE = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{AGENT_NAME} Goal Heartbeat #{beat_number} — {goal_name}</title>
<style>
  * {{ margin: 0; padding: 0; box-sizing: border-box; }}
  body {{
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    line-height: 1.7; color: #1a1a1a; background: #f5f5f5; padding: 2rem;
  }}
  .container {{
    max-width: 820px; margin: 0 auto; background: #fff;
    border-radius: 12px; box-shadow: 0 2px 12px rgba(0,0,0,0.08); padding: 2.5rem 3rem;
  }}
  .header {{ border-bottom: 2px solid #e0e0e0; padding-bottom: 1rem; margin-bottom: 2rem; }}
  .header h1 {{ font-size: 1.5rem; color: #333; }}
  .meta {{ font-size: 0.85rem; color: #888; margin-top: 0.3rem; }}
  .meta .success {{ color: #2e7d32; font-weight: 600; }}
  .meta .fail {{ color: #c62828; font-weight: 600; }}
  h1 {{ font-size: 1.6rem; margin: 1.5rem 0 0.8rem; color: #222; }}
  h2 {{ font-size: 1.3rem; margin: 1.8rem 0 0.6rem; color: #333; border-bottom: 1px solid #eee; padding-bottom: 0.4rem; }}
  h3 {{ font-size: 1.1rem; margin: 1.2rem 0 0.5rem; color: #444; }}
  p {{ margin: 0.6rem 0; }}
  ul, ol {{ margin: 0.6rem 0 0.6rem 1.5rem; }}
  li {{ margin: 0.3rem 0; }}
  code {{ background: #f0f0f0; padding: 0.15rem 0.4rem; border-radius: 4px; font-size: 0.9em; }}
  pre {{ background: #1e1e1e; color: #d4d4d4; padding: 1rem 1.2rem; border-radius: 8px; overflow-x: auto; margin: 0.8rem 0; }}
  pre code {{ background: none; padding: 0; color: inherit; }}
  blockquote {{ border-left: 4px solid #4a90d9; padding: 0.5rem 1rem; margin: 0.8rem 0; background: #f8f9ff; color: #555; }}
  table {{ border-collapse: collapse; width: 100%; margin: 0.8rem 0; font-size: 0.92em; }}
  th, td {{ border: 1px solid #ddd; padding: 0.5rem 0.8rem; text-align: left; }}
  th {{ background: #f5f5f5; font-weight: 600; }}
  tr:nth-child(even) {{ background: #fafafa; }}
  a {{ color: #4a90d9; text-decoration: none; }}
  hr {{ border: none; border-top: 1px solid #e0e0e0; margin: 1.5rem 0; }}
  strong {{ color: #222; }}
</style>
</head>
<body>
<div class="container">
  <div class="header">
    <h1>🎯 {AGENT_NAME} Goal Heartbeat #{beat_number}</h1>
    <div class="meta">
      {goal_name} &nbsp;|&nbsp; {timestamp} &nbsp;|&nbsp; Exit code: <span class="{status_class}">{exit_code}</span>
    </div>
  </div>
  {content}
</div>
</body>
</html>
"""


def md_to_html(md_text, beat_number, goal_name, timestamp, exit_code):
    """Convert markdown output to styled HTML."""
    try:
        import markdown as md_lib
        html_body = md_lib.markdown(
            md_text,
            extensions=["tables", "fenced_code", "toc", "nl2br"],
        )
    except ImportError:
        # Fallback: wrap in <pre> if markdown not installed
        html_body = f"<pre>{md_text}</pre>"

    status_class = "success" if exit_code == 0 else "fail"
    return HTML_TEMPLATE.format(
        beat_number=beat_number,
        goal_name=goal_name,
        timestamp=timestamp,
        content=html_body,
        exit_code=exit_code,
        status_class=status_class,
    )


# --- Goal Loading ---

def load_goal(goal_id):
    """Load a specific goal from goals.json."""
    if not GOALS_FILE.exists():
        return None
    with open(GOALS_FILE, "r", encoding="utf-8") as f:
        data = json.load(f)
    for g in data.get("goals", []):
        if g["id"] == goal_id:
            return g
    return None


# --- Heartbeat Prompt ---

def build_heartbeat_prompt(goal, beat_number):
    """Build the heartbeat prompt for Claude, adapted from Yama."""

    # Calculate days remaining
    days_remaining = "no deadline"
    if goal.get("deadline"):
        try:
            deadline = datetime.fromisoformat(goal["deadline"].replace("Z", "+00:00"))
            days_remaining = f"{(deadline - datetime.now(deadline.tzinfo)).days} days"
        except:
            days_remaining = goal["deadline"]

    stats = goal.get("stats", {})
    goal_id = goal["id"]
    goal_name = goal["name"]
    todo_list = goal.get("todoListName", f"🎯 {goal_name}")
    project = goal.get("project", "General")

    prompt = f"""You are {AGENT_NAME}, executing a goal heartbeat. You have been woken up by the goal scheduler.

=== GOAL CONTEXT ===
Goal ID: {goal_id}
Goal: {goal["name"]}
Description: {goal.get("description", goal["name"])}
Success Metric: {goal.get("successMetric", "To be defined")}
Deadline: {goal.get("deadline", "None")} ({days_remaining} remaining)
Project: {project}
Heartbeat #{beat_number}
Tasks completed: {stats.get("tasksCompleted", 0)}/{stats.get("tasksTotal", 0)}
Consecutive idles: {stats.get("consecutiveIdles", 0)}

=== EXECUTE THE HEARTBEAT WORKFLOW ===

Step 1: READ CONTEXT
- Read the goal's MS To Do list: python ~/.claude/skills/ms-todo/script/get_tasks.py -l "{todo_list}"
- Search memory for this project/goal context
- Read the last 2 heartbeat logs in {HOME_DIR}/goal-logs/{goal_id}/ to avoid repeating work
- If a PLAN file exists at ~/Downloads/{project}/PLAN.md, read it for phase context

Step 2: SELECT EXACTLY 1 TASK
- Priority: unfinished [G] green tasks first → [Y] yellow tasks → [R] red = IDLE
- NEVER repeat the same task as the previous heartbeat
- If only [R] tasks remain, output "IDLE" as the FIRST WORD of your response and explain what's blocked

Step 3: THINKING AUDITOR (for [G] tasks only)
Before executing any [G] green task, answer these 6 questions HONESTLY:

1. 知识审计 — Do I have enough research to do this well? Am I an expert?
   Rating: 🟢 solid / 🟡 reasonable but unverified / 🔴 weak

2. 用户证据审计 — Is there real user/{OWNER_NAME}/team input supporting this approach?
   Rating: 🟢 / 🟡 / 🔴

3. 数据审计 — Are the numbers and facts I'll use credible and sourced?
   Rating: 🟢 / 🟡 / 🔴

4. 逻辑审计 — Is my reasoning chain complete? Any leaps?
   Rating: 🟢 / 🟡 / 🔴

5. 假设审计 — What am I assuming without evidence? Which assumptions are risky?
   Rating: 🟢 / 🟡 / 🔴

6. Pre-mortem — If this task fails or produces bad output, why?
   Rating: 🟢 / 🟡 / 🔴

VERDICT:
- All 🟢 → EXECUTE fully
- Any 🟡 → EXPERIMENT: do a smaller scoped version, mark output for review
- Any 🔴 → STOP: do NOT execute, add to /review queue

Step 4: EXECUTE THE TASK
- Focus on this ONE task only. Do not multitask.
- Save outputs to ~/Downloads/{project}/ or appropriate location
- [Y] tasks: save a copy of the output for {OWNER_NAME}'s review

Step 5: UPDATE STATE
- Complete the task: python ~/.claude/skills/ms-todo/script/complete_task.py ...
- If new sub-tasks discovered: python ~/.claude/skills/ms-todo/script/create_task.py ...
- Log the heartbeat: node {GOALS_JS} log {goal_id} --task "[task title]" --tier "G|Y|R" --outcome "completed|idle|failed" --audit-rating "green|yellow|red"

Step 6: OUTPUT REPORT
Format your output as:

## Heartbeat #{beat_number} — {{time}}

### Selected Task
[G/Y/R] Task title

### Thinking Auditor (if [G])
| Audit | Rating | Notes |
|-------|--------|-------|
| Knowledge | 🟢/🟡/🔴 | ... |
| User Evidence | 🟢/🟡/🔴 | ... |
| Data | 🟢/🟡/🔴 | ... |
| Logic | 🟢/🟡/🔴 | ... |
| Assumptions | 🟢/🟡/🔴 | ... |
| Pre-mortem | 🟢/🟡/🔴 | ... |
| **Verdict** | **EXECUTE/EXPERIMENT/STOP** | |

### Execution
[What was done, outputs produced]

### Skipped [R] Tasks
[List blocked tasks and why]

### Needs {OWNER_NAME}'s Attention
[Items for /review]

### Next Heartbeat Suggestion
[What should be done next]

### Files Changed
[List of files created/modified]

=== SAFETY RULES ===
- ONE task per heartbeat, no exceptions
- [R] tasks are NEVER auto-executed
- If consecutive idles reach {MAX_CONSECUTIVE_IDLE}, output "GOAL STALLED" prominently
- Budget: max 15 minutes of focused work per heartbeat
- Do NOT repeat work from previous heartbeat
- Research BEFORE action — become an expert first, then decide

Current time: {datetime.now().strftime("%Y-%m-%d %H:%M")}
"""
    return prompt


# --- State Management ---

def load_state():
    if STATE_FILE.exists():
        with open(STATE_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    return {"beats_today": 0, "start_time": None, "last_beat": None, "date": None, "goal_id": None}


def save_state(state):
    STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(STATE_FILE, "w", encoding="utf-8") as f:
        json.dump(state, f, indent=2, ensure_ascii=False)


# --- Heartbeat Execution ---

def run_heartbeat(goal, beat_number):
    """Execute one heartbeat with real-time output streaming."""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M")
    prompt = build_heartbeat_prompt(goal, beat_number)
    goal_id = goal["id"]
    goal_name = goal["name"]

    print(f"\n{'=' * 60}")
    print(f"[{timestamp}] 🎯 Goal Heartbeat #{beat_number} — {goal_name}")
    print(f"{'=' * 60}\n")

    try:
        escaped_prompt = prompt.replace('"', '\\"').replace('\n', '\\n')
        cmd = f'{CLAUDE_CMD} -p "{escaped_prompt}" --output-format text --max-turns 30 --dangerously-skip-permissions'

        process = subprocess.Popen(
            cmd,
            cwd=str(Path.home()),
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            encoding="utf-8",
            shell=True,
        )

        # Collect stderr in background
        stderr_lines = []
        def read_stderr():
            for line in process.stderr:
                stderr_lines.append(line)

        stderr_thread = threading.Thread(target=read_stderr, daemon=True)
        stderr_thread.start()

        # Stream stdout in real-time
        stdout_lines = []
        deadline = time.time() + 3300  # 55 min timeout

        for line in process.stdout:
            if time.time() > deadline:
                process.kill()
                print(f"\n[{timestamp}] Heartbeat #{beat_number} timed out (55 min)")
                break
            print(line, end="", flush=True)
            stdout_lines.append(line)

        process.wait()
        stderr_thread.join(timeout=5)

        output = "".join(stdout_lines)
        error = "".join(stderr_lines)
        exit_code = process.returncode

        # Save HTML report
        log_dir = LOGS_DIR / goal_id
        log_dir.mkdir(parents=True, exist_ok=True)

        file_ts = datetime.now().strftime('%Y-%m-%d-%H%M')
        html_content = md_to_html(output, beat_number, goal_name, timestamp, exit_code)
        html_log = log_dir / f"heartbeat-{file_ts}.html"
        with open(html_log, "w", encoding="utf-8") as f:
            f.write(html_content)

        # Save raw text backup
        raw_log = log_dir / f"heartbeat-{file_ts}-raw.txt"
        with open(raw_log, "w", encoding="utf-8") as f:
            f.write(f"=== Heartbeat #{beat_number} at {timestamp} ===\n")
            f.write(f"=== Goal: {goal_name} ({goal_id}) ===\n")
            f.write(f"=== Exit code: {exit_code} ===\n\n")
            f.write(output)
            if error:
                f.write("\n\n=== STDERR ===\n")
                f.write(error)

        end_ts = datetime.now().strftime("%Y-%m-%d %H:%M")
        print(f"\n{'=' * 60}")
        if exit_code == 0:
            print(f"[{end_ts}] ✅ Heartbeat #{beat_number} completed OK")
        else:
            print(f"[{end_ts}] ❌ Heartbeat #{beat_number} exited with code {exit_code}")
        print(f"Log: {html_log.name}")
        print(f"{'=' * 60}")

        # Detect IDLE (same logic as Yama)
        first_lines = "\n".join(output.strip().split("\n")[:5]).upper()
        is_idle = "IDLE" in first_lines

        return exit_code == 0, is_idle

    except Exception as e:
        print(f"\n[{timestamp}] ❌ Heartbeat #{beat_number} error: {e}")
        return False, False


# --- Commands ---

def cmd_start(goal_id):
    """Start back-to-back heartbeats for a goal."""
    LOGS_DIR.mkdir(parents=True, exist_ok=True)

    goal = load_goal(goal_id)
    if not goal:
        print(f"Goal not found: {goal_id}")
        sys.exit(1)

    if goal.get("status") != "active":
        print(f"Goal is not active (status: {goal.get('status')}). Use 'goals.js resume' first.")
        sys.exit(1)

    # Check if already running
    if PID_FILE.exists():
        try:
            pid = int(PID_FILE.read_text().strip())
            os.kill(pid, 0)
            print(f"Scheduler already running (PID: {pid}). Use 'stop' first.")
            return
        except (OSError, ValueError):
            PID_FILE.unlink(missing_ok=True)

    PID_FILE.write_text(str(os.getpid()))

    today = datetime.now().strftime("%Y-%m-%d")
    state = load_state()

    if state.get("date") != today or state.get("goal_id") != goal_id:
        state = {
            "beats_today": 0,
            "start_time": datetime.now().isoformat(),
            "last_beat": None,
            "date": today,
            "goal_id": goal_id,
        }

    start_time = datetime.now()
    end_time = start_time + timedelta(hours=MAX_HOURS)

    print("=" * 60)
    print(f"🎯 {AGENT_NAME} Goal Scheduler — {goal['name']}")
    print(f"Start:    {start_time.strftime('%Y-%m-%d %H:%M')}")
    print(f"End:      {end_time.strftime('%Y-%m-%d %H:%M')}")
    print(f"Mode:     Back-to-back (0s interval), 1 task per heartbeat")
    print(f"Stops:    {MAX_CONSECUTIVE_IDLE} consecutive IDLEs or {MAX_CONSECUTIVE_FAILURES} failures")
    print(f"Done today: {state['beats_today']} heartbeats")
    print("=" * 60)

    def handle_stop(signum, frame):
        print("\nStop signal received, exiting...")
        PID_FILE.unlink(missing_ok=True)
        sys.exit(0)

    signal.signal(signal.SIGTERM, handle_stop)
    signal.signal(signal.SIGINT, handle_stop)

    try:
        consecutive_failures = 0
        consecutive_idle = 0

        while datetime.now() < end_time and state["beats_today"] < MAX_HEARTBEATS:
            # Reload goal each heartbeat (state may have changed)
            goal = load_goal(goal_id)
            if not goal or goal.get("status") != "active":
                print(f"\nGoal is no longer active. Stopping.")
                break

            state["beats_today"] += 1
            beat_num = state["beats_today"]

            success, is_idle = run_heartbeat(goal, beat_num)

            state["last_beat"] = datetime.now().isoformat()
            state["last_beat_success"] = success
            save_state(state)

            if success:
                consecutive_failures = 0
            else:
                consecutive_failures += 1
                if consecutive_failures >= MAX_CONSECUTIVE_FAILURES:
                    print(f"\n❌ {MAX_CONSECUTIVE_FAILURES} consecutive failures. Stopping.")
                    break

            if is_idle:
                consecutive_idle += 1
                print(f"\n⏸️ [IDLE {consecutive_idle}/{MAX_CONSECUTIVE_IDLE}] All remaining tasks need {OWNER_NAME}'s decision.")
                if consecutive_idle >= MAX_CONSECUTIVE_IDLE:
                    print(f"\n🛑 {MAX_CONSECUTIVE_IDLE} consecutive idle heartbeats. All tasks blocked on {OWNER_NAME}.")
                    print(f"Run '/review' to unblock, then restart: python {agent_name}-goal-scheduler.py start {goal_id}")
                    break
            else:
                consecutive_idle = 0

            if state["beats_today"] >= MAX_HEARTBEATS:
                print(f"\nMax heartbeats reached ({MAX_HEARTBEATS}).")
                break

            if datetime.now() >= end_time:
                print(f"\n{MAX_HOURS}-hour window reached.")
                break

            # Back-to-back: start next immediately
            if INTERVAL_SECONDS > 0:
                next_beat = datetime.now() + timedelta(seconds=INTERVAL_SECONDS)
                if next_beat >= end_time:
                    break
                wait_seconds = (next_beat - datetime.now()).total_seconds()
                if wait_seconds > 0:
                    print(f"\nNext heartbeat in {int(wait_seconds)}s...")
                    while datetime.now() < next_beat:
                        remaining = (next_beat - datetime.now()).total_seconds()
                        time.sleep(min(remaining, 30))
            else:
                print(f"\nStarting next heartbeat immediately...")

    finally:
        PID_FILE.unlink(missing_ok=True)
        print(f"\n🏁 Scheduler stopped. {state['beats_today']} heartbeats for '{goal['name']}' today.")


def cmd_stop():
    """Stop running scheduler."""
    if not PID_FILE.exists():
        print("No scheduler running.")
        return
    try:
        pid = int(PID_FILE.read_text().strip())
        if sys.platform == 'win32':
            os.kill(pid, signal.SIGTERM)
        else:
            os.kill(pid, signal.SIGTERM)
        print(f"Stop signal sent (PID: {pid})")
        time.sleep(2)
        PID_FILE.unlink(missing_ok=True)
    except (OSError, ValueError) as e:
        print(f"Stop failed: {e}")
        PID_FILE.unlink(missing_ok=True)


def cmd_status():
    """Check current status."""
    state = load_state()
    print("=" * 50)
    print("🎯 {AGENT_NAME} Goal Scheduler Status")
    print("=" * 50)

    if PID_FILE.exists():
        try:
            pid = int(PID_FILE.read_text().strip())
            os.kill(pid, 0)
            print(f"Status: RUNNING (PID: {pid})")
        except (OSError, ValueError):
            print("Status: NOT RUNNING")
            PID_FILE.unlink(missing_ok=True)
    else:
        print("Status: NOT RUNNING")

    goal_id = state.get("goal_id", "N/A")
    goal = load_goal(goal_id) if goal_id != "N/A" else None

    print(f"Goal: {goal['name'] if goal else 'N/A'} ({goal_id})")
    print(f"Date: {state.get('date', 'N/A')}")
    print(f"Heartbeats today: {state.get('beats_today', 0)}")
    print(f"Start time: {state.get('start_time', 'N/A')}")
    print(f"Last heartbeat: {state.get('last_beat', 'N/A')}")
    print(f"Last success: {state.get('last_beat_success', 'N/A')}")

    if goal_id and goal_id != "N/A":
        log_dir = LOGS_DIR / goal_id
        if log_dir.exists():
            today = datetime.now().strftime("%Y-%m-%d")
            logs = sorted(log_dir.glob(f"heartbeat-{today}*.html"))
            if logs:
                print(f"\nToday's logs ({len(logs)}):")
                for log in logs[-5:]:  # Show last 5
                    print(f"  - {log.name}")
                if len(logs) > 5:
                    print(f"  ... and {len(logs) - 5} more")


def cmd_once(goal_id):
    """Run one heartbeat manually."""
    LOGS_DIR.mkdir(parents=True, exist_ok=True)

    goal = load_goal(goal_id)
    if not goal:
        print(f"Goal not found: {goal_id}")
        sys.exit(1)

    state = load_state()
    today = datetime.now().strftime("%Y-%m-%d")
    if state.get("date") != today or state.get("goal_id") != goal_id:
        state = {
            "beats_today": 0,
            "start_time": datetime.now().isoformat(),
            "last_beat": None,
            "date": today,
            "goal_id": goal_id,
        }

    state["beats_today"] += 1
    success, is_idle = run_heartbeat(goal, state["beats_today"])
    state["last_beat"] = datetime.now().isoformat()
    state["last_beat_success"] = success
    save_state(state)

    if is_idle:
        print(f"\n⏸️ [IDLE] All remaining tasks need {OWNER_NAME}'s decision. Run '/review' to unblock.")


# --- Main ---

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)

    cmd = sys.argv[1]
    if cmd == "start":
        if len(sys.argv) < 3:
            print("Usage: python {agent_name}-goal-scheduler.py start <goalId>")
            sys.exit(1)
        cmd_start(sys.argv[2])
    elif cmd == "stop":
        cmd_stop()
    elif cmd == "status":
        cmd_status()
    elif cmd == "once":
        if len(sys.argv) < 3:
            print("Usage: python {agent_name}-goal-scheduler.py once <goalId>")
            sys.exit(1)
        cmd_once(sys.argv[2])
    else:
        print(f"Unknown command: {cmd}")
        print(__doc__)
        sys.exit(1)
