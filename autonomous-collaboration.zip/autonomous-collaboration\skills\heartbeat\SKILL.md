---
name: heartbeat
description: Unified view of everything {AGENT_NAME} is doing autonomously — long-term goals, scheduled tasks, chat monitors, action queue stats, and learned instincts. Use when user asks "what are you watching?", "what's running?", "/heartbeat", "/status", "show me your heartbeat", or wants to see all proactive systems at a glance.
---

# Heartbeat — {AGENT_NAME}'s Autonomous Activity Dashboard

Shows a unified, scannable view of all proactive systems in one place.

## Usage

```bash
node {HOME_DIR}/teams-tasks/.claude/skills/heartbeat/scripts/heartbeat.js
```

No arguments needed. Reads all state files and produces a formatted report.

### Options

```bash
node heartbeat.js --json     # Output raw JSON instead of formatted text
node heartbeat.js --section goals|tasks|monitors|queue|instincts  # Show one section only
```

## What It Aggregates

| Source | State File | Data |
|--------|-----------|------|
| Goals | `{HOME_DIR}/goals.json` | Active/paused goals, step progress, next heartbeat |
| Scheduled Tasks | `{HOME_DIR}/teams-tasks/scheduled-tasks.json` | 8 tasks, cron schedules, last/next run |
| Chat Monitors | `{HOME_DIR}/teams-tasks/monitors.json` | 3/10 monitors, poll intervals, failures |
| Action Queue | `{HOME_DIR}/action-queue.json` | Pending/completed proposals, approval rates |
| Instincts | `{HOME_DIR}/INSTINCT.md` | Learned preferences from proposal outcomes |

## Output Format

The script outputs a structured report. Present it to the user as-is — do NOT reformat or summarize.

## When to Invoke

- User asks what {AGENT_NAME} is doing autonomously
- User wants to debug a missed scheduled task
- User wants to see all monitors
- User asks "what are you tracking?"
- User says `/heartbeat` or `/status`
