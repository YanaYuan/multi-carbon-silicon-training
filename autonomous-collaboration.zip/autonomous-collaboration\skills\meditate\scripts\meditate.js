#!/usr/bin/env node
/**
 * Meditate — {AGENT_NAME}'s self-improvement cycle.
 *
 * SOUL (identity) → INSTINCT (reflexes) → MEDITATE (deliberate growth)
 *
 * Five phases: Diagnose → Reflect → Memory Hygiene → Memory Triage → Propose → Log
 *
 * Usage:
 *   node meditate.js                    # Full cycle
 *   node meditate.js --phase diagnose   # Single phase
 *   node meditate.js --dry-run          # Show what would happen
 *   node meditate.js --json             # Raw JSON output
 */

const fs = require('fs');
const path = require('path');
const os = require('os');
const { execSync } = require('child_process');

// --- Paths ---
const CORTANA_HOME = path.join(os.homedir(), '.{agent_name}');
const TASKS_FILE = path.join(CORTANA_HOME, 'teams-tasks', 'scheduled-tasks.json');
const MONITORS_FILE = path.join(CORTANA_HOME, 'teams-tasks', 'monitors.json');
const ACTION_QUEUE_FILE = path.join(CORTANA_HOME, 'action-queue.json');
const INSTINCT_FILE = path.join(CORTANA_HOME, 'INSTINCT.md');
const MEMORY_FILE = path.join(CORTANA_HOME, 'MEMORY.md');
const OUTCOMES_FILE = path.join(CORTANA_HOME, 'proposal-outcomes.jsonl');
const MEDITATION_LOG = path.join(CORTANA_HOME, 'meditation-log.md');
const EXTRACTED_DIR = path.join(CORTANA_HOME, 'memory', 'extracted');
const TOPICS_DIR = path.join(CORTANA_HOME, 'memory', 'topics');
const HEARTBEAT_SCRIPT = path.join(CORTANA_HOME, 'teams-tasks', '.claude', 'skills', 'heartbeat', 'scripts', 'heartbeat.js');
const SIGNALS_DIR = path.join(CORTANA_HOME, 'signals');
const EXTERNAL_DIRS_CONFIG = path.join(CORTANA_HOME, 'memory', 'external_dirs.json');
const ENTITIES_DIR = path.join(CORTANA_HOME, 'knowledge-graph', 'entities');
const INGEST_CHECKPOINT = path.join(CORTANA_HOME, 'knowledge-graph', 'ingest-checkpoint.json');
const KG_PORT = 11718;

// --- Helpers ---

/**
 * Make an HTTP request to the local KG server via a subprocess.
 * Writes the payload to a temp file to avoid Windows command-line length limits (~8191 chars).
 * Falls back to inline payload for small data that fits safely.
 */
function kgHttpRequest(endpoint, method, payload, timeoutMs = 30000) {
  const payloadStr = typeof payload === 'string' ? payload : JSON.stringify(payload);

  // Use temp files to avoid Windows cmd line length limit
  const tmpId = `{agent_name}-kg-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
  const tmpDataFile = path.join(os.tmpdir(), `${tmpId}.json`);
  const tmpScriptFile = path.join(os.tmpdir(), `${tmpId}.js`);
  try {
    fs.writeFileSync(tmpDataFile, payloadStr);
    const script = `const http=require('http');const fs=require('fs');const d=fs.readFileSync(${JSON.stringify(tmpDataFile)},'utf8');const r=http.request({hostname:'127.0.0.1',port:${KG_PORT},path:'${endpoint}',method:'${method}',headers:{'Content-Type':'application/json','Content-Length':Buffer.byteLength(d)},timeout:${timeoutMs}},res=>{let b='';res.on('data',c=>b+=c);res.on('end',()=>{console.log(b);process.exit(0)})});r.on('error',e=>{console.log(JSON.stringify({error:e.message}));process.exit(1)});r.write(d);r.end()`;
    fs.writeFileSync(tmpScriptFile, script);
    const result = execSync(
      `node "${tmpScriptFile}"`,
      { encoding: 'utf8', timeout: timeoutMs + 60000, windowsHide: true }
    ).trim();
    return JSON.parse(result || '{}');
  } finally {
    try { fs.unlinkSync(tmpDataFile); } catch { /* ignore */ }
    try { fs.unlinkSync(tmpScriptFile); } catch { /* ignore */ }
  }
}

/**
 * Health-check the KG server. Small inline payload (no temp file needed).
 */
function kgHealthCheck() {
  try {
    const result = execSync(
      `node -e "const http=require('http');const r=http.get('http://127.0.0.1:${KG_PORT}/health',res=>{let d='';res.on('data',c=>d+=c);res.on('end',()=>{console.log(d);process.exit(0)})});r.on('error',()=>{console.log('{}');process.exit(1)});r.setTimeout(3000,()=>{r.destroy();console.log('{}');process.exit(1)})"`,
      { encoding: 'utf8', timeout: 5000, windowsHide: true }
    ).trim();
    const health = JSON.parse(result || '{}');
    return health.status === 'ok';
  } catch {
    return false;
  }
}

function readJSON(filePath) {
  try { return JSON.parse(fs.readFileSync(filePath, 'utf8')); } catch { return null; }
}
function readText(filePath) {
  try { return fs.readFileSync(filePath, 'utf8'); } catch { return null; }
}
function readJSONL(filePath) {
  try {
    return fs.readFileSync(filePath, 'utf8').trim().split('\n').filter(Boolean).map(line => {
      try { return JSON.parse(line); } catch { return null; }
    }).filter(Boolean);
  } catch { return []; }
}
function daysAgo(dateStr) {
  if (!dateStr) return Infinity;
  const d = new Date(dateStr);
  if (isNaN(d)) return Infinity;
  return Math.floor((Date.now() - d.getTime()) / 86400000);
}
function formatDate(d) {
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}

// --- State file paths (new) ---
const HYGIENE_STATE_FILE = path.join(CORTANA_HOME, 'meditation-hygiene-state.json');
const PROPOSALS_TRACKER_FILE = path.join(CORTANA_HOME, 'meditation-proposals-tracker.json');

// --- LLM configuration ---
const LLM_ENDPOINT = process.env.CORTANA_LLM_ENDPOINT || 'http://localhost:23333/api/openai/v1/chat/completions';
const LLM_MODEL = process.env.CORTANA_LLM_MODEL || 'claude-haiku-4.5';
const LLM_TIMEOUT = parseInt(process.env.CORTANA_LLM_TIMEOUT || '30000');

/**
 * Simple djb2 hash for stable content identity.
 */
function simpleHash(str) {
  let hash = 5381;
  for (let i = 0; i < str.length; i++) {
    hash = ((hash << 5) + hash) + str.charCodeAt(i);
    hash = hash & hash; // Convert to 32-bit
  }
  return Math.abs(hash).toString(36);
}

/**
 * Strip bracket-prefix tags from a MEMORY.md line for stable hashing.
 */
function stripTags(line) {
  return line.replace(/\[(TODO|PLAN|FACT|ARCHIVED[^\]]*|DEPRECATED[^\]]*|\d{4}-\d{2}-\d{2})\]\s*/g, '').trim();
}

/**
 * Write JSON atomically: write to temp file, then rename over target.
 */
function writeJSONAtomic(filePath, data) {
  const tmpPath = filePath + '.tmp.' + Date.now();
  fs.writeFileSync(tmpPath, JSON.stringify(data, null, 2), 'utf8');
  fs.renameSync(tmpPath, filePath);
}

/**
 * Call an LLM via the Copilot Proxy (sync subprocess, same pattern as kgHttpRequest).
 * Returns the response text, or null on any error.
 */
function callLLM(prompt, maxTokens = 1024) {
  const tmpId = `{agent_name}-llm-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
  const tmpDataFile = path.join(os.tmpdir(), `${tmpId}.json`);
  const tmpScriptFile = path.join(os.tmpdir(), `${tmpId}.js`);
  try {
    const payload = JSON.stringify({
      model: LLM_MODEL,
      messages: [{ role: 'user', content: prompt }],
      max_tokens: maxTokens,
    });
    fs.writeFileSync(tmpDataFile, payload);

    // Parse endpoint URL
    const url = new URL(LLM_ENDPOINT);
    const isHttps = url.protocol === 'https:';
    const port = url.port || (isHttps ? 443 : 80);
    const fullPath = url.pathname + (url.search || '');
    const script = `const net=require(${isHttps ? "'https'" : "'http'"});const fs=require('fs');const d=fs.readFileSync(${JSON.stringify(tmpDataFile)},'utf8');const r=net.request({hostname:${JSON.stringify(url.hostname)},port:${port},path:${JSON.stringify(fullPath)},method:'POST',headers:{'Content-Type':'application/json','Content-Length':Buffer.byteLength(d)},timeout:${LLM_TIMEOUT}},res=>{let b='';res.on('data',c=>b+=c);res.on('end',()=>{console.log(JSON.stringify({status:res.statusCode,body:b}));process.exit(0)})});r.on('error',e=>{console.log(JSON.stringify({error:e.message}));process.exit(1)});r.on('timeout',()=>{r.destroy();console.log(JSON.stringify({error:'timeout'}));process.exit(1)});r.write(d);r.end()`;
    fs.writeFileSync(tmpScriptFile, script);

    const result = execSync(
      `node "${tmpScriptFile}"`,
      { encoding: 'utf8', timeout: LLM_TIMEOUT + 10000, windowsHide: true }
    ).trim();
    const wrapper = JSON.parse(result || '{}');
    if (wrapper.error || wrapper.status !== 200) return null;
    const parsed = JSON.parse(wrapper.body || '{}');
    const content = parsed.choices?.[0]?.message?.content;
    return typeof content === 'string' ? content : null;
  } catch {
    return null;
  } finally {
    try { fs.unlinkSync(tmpDataFile); } catch { /* ignore */ }
    try { fs.unlinkSync(tmpScriptFile); } catch { /* ignore */ }
  }
}

/**
 * Deep reflect: use LLM to analyze approved vs denied proposal patterns.
 * Returns array of deep-pattern insights with concrete RULE/SKIP pairs.
 */
function reflectDeep(uniqueOutcomes, byAction) {
  const deepInsights = [];
  let llmUnavailable = false;

  // Sort buckets by total volume descending, cap at 5
  const buckets = Object.entries(byAction)
    .map(([key, data]) => {
      const approved = data.approved || [];
      const denied = [...(data.denied || []), ...(data.skipped || [])];
      return { key, approved, denied, total: approved.length + denied.length };
    })
    .filter(b => b.approved.length >= 3 && b.denied.length >= 5)
    .sort((a, b) => b.total - a.total)
    .slice(0, 5);

  for (const bucket of buckets) {
    const [actionType, signalSource] = bucket.key.split(':');

    // Build truncated lists with total budget ~3000 chars
    const APPROVED_BUDGET = 1000;
    const DENIED_BUDGET = 1800;

    let approvedUsed = 0;
    const approvedLines = [];
    for (const o of bucket.approved.slice(-10)) {
      const line = `  - ${(o.actionSummary || '').slice(0, 150)}`;
      if (approvedUsed + line.length > APPROVED_BUDGET) break;
      approvedLines.push(line);
      approvedUsed += line.length;
    }
    const approvedList = approvedLines.join('\n');

    let deniedUsed = 0;
    const deniedLines = [];
    for (const o of bucket.denied.slice(-15)) {
      const summary = (o.actionSummary || '').slice(0, 150);
      const reason = (o.dismissalNote || o.dismissalReason || '').slice(0, 200);
      const line = `  - ${summary}${reason ? ` [reason: ${reason}]` : ''}`;
      if (deniedUsed + line.length > DENIED_BUDGET) break;
      deniedLines.push(line);
      deniedUsed += line.length;
    }
    const deniedList = deniedLines.join('\n');

    const prompt = `You are analyzing a user's proposal approval/denial patterns for an AI assistant.
Action type: "${actionType}" from signal source: "${signalSource}"

APPROVED proposals (user wanted these):
${approvedList}

DENIED proposals (user did NOT want these):
${deniedList}

What specific patterns distinguish approved from denied?
Output exactly 1-3 rules, each on its own line, in this format:
RULE: <when to propose> | SKIP: <when to skip>

Be concrete — name specific meeting series, senders, topics, or keywords. Do not be generic.`;

    const response = callLLM(prompt, 512);
    if (response === null) {
      if (!llmUnavailable) llmUnavailable = true;
      continue;
    }

    // Parse RULE/SKIP lines
    const rulePattern = /^RULE:\s*(.+?)\s*\|\s*SKIP:\s*(.+)$/gm;
    let match;
    let ruleCount = 0;
    while ((match = rulePattern.exec(response)) !== null && ruleCount < 3) {
      deepInsights.push({
        type: 'deep-pattern',
        actionType,
        signalSource,
        rule: match[1].trim(),
        skip: match[2].trim(),
        msg: `${actionType} from ${signalSource}: RULE: ${match[1].trim()} | SKIP: ${match[2].trim()}`,
      });
      ruleCount++;
    }
    if (ruleCount === 0 && response.trim().length > 0) {
      console.log(`[meditate] Deep reflect: LLM returned unparseable output for ${actionType}:${signalSource}`);
    }
  }

  if (llmUnavailable && deepInsights.length === 0) {
    console.log('[meditate] Deep analysis unavailable — LLM endpoint not reachable');
  }

  return { deepInsights, llmUnavailable: llmUnavailable && deepInsights.length === 0 };
}

// ============================================================
// PHASE 1: DIAGNOSE — Read heartbeat, compute health metrics
// ============================================================
function diagnose() {
  const findings = [];
  let healthScore = 10;

  // -- Scheduled Tasks --
  const tasksData = readJSON(TASKS_FILE);
  if (tasksData?.tasks) {
    const tasks = tasksData.tasks;
    const enabled = tasks.filter(t => t.enabled);
    const paused = tasks.filter(t => !t.enabled);
    const now = Date.now();

    for (const t of tasks) {
      // Overdue check
      if (t.enabled && t.state?.nextRunAtMs && t.state.nextRunAtMs < now - 3600000) {
        findings.push({ severity: 'warn', system: 'tasks', msg: `"${t.name}" is overdue by ${Math.floor((now - t.state.nextRunAtMs) / 3600000)}h` });
        healthScore -= 0.5;
      }
      // Long-paused check
      if (!t.enabled && t.state?.lastRunAtMs) {
        const pausedDays = Math.floor((now - t.state.lastRunAtMs) / 86400000);
        if (pausedDays > 3) {
          findings.push({ severity: 'info', system: 'tasks', msg: `"${t.name}" paused for ${pausedDays}d — still needed?` });
        }
      }
      // Error check
      if (t.state?.lastError) {
        findings.push({ severity: 'error', system: 'tasks', msg: `"${t.name}" last run had error: ${t.state.lastError}` });
        healthScore -= 1;
      }
    }
    findings.push({ severity: 'ok', system: 'tasks', msg: `${enabled.length}/${tasks.length} active, ${paused.length} paused` });
  }

  // -- Chat Monitors --
  const monitorsData = readJSON(MONITORS_FILE);
  if (monitorsData?.monitors) {
    const monitors = monitorsData.monitors;
    const active = monitors.filter(m => m.enabled);
    const failing = monitors.filter(m => (m.consecutiveFailures || 0) > 2);
    const maxSlots = monitorsData.maxMonitors || 10;
    const freeSlots = maxSlots - active.length;

    if (failing.length > 0) {
      for (const m of failing) {
        findings.push({ severity: 'warn', system: 'monitors', msg: `"${m.chatName}" has ${m.consecutiveFailures} consecutive failures` });
        healthScore -= 1;
      }
    }
    findings.push({ severity: 'ok', system: 'monitors', msg: `${active.length}/${maxSlots} slots used, ${freeSlots} free, ${failing.length} failing` });
  }

  // -- Action Queue --
  const queueData = readJSON(ACTION_QUEUE_FILE);
  if (queueData?.proposals) {
    const proposals = queueData.proposals;
    const pending = proposals.filter(p => p.status === 'pending').length;
    const failed = proposals.filter(p => p.status === 'failed').length;

    const oneDayAgo = Date.now() - 86400000;
    const recent = proposals.filter(p => new Date(p.createdAt).getTime() > oneDayAgo);
    const recentApproved = recent.filter(p => ['approved', 'completed'].includes(p.status)).length;
    const recentDenied = recent.filter(p => ['denied', 'skipped'].includes(p.status)).length;
    const rate = (recentApproved + recentDenied) > 0 ? Math.round(recentApproved / (recentApproved + recentDenied) * 100) : null;

    if (rate !== null && rate < 10) {
      findings.push({ severity: 'warn', system: 'queue', msg: `24h approval rate is ${rate}% — proposals may not be useful right now` });
    }
    if (failed > 2) {
      findings.push({ severity: 'warn', system: 'queue', msg: `${failed} failed proposals in queue — execution issues?` });
      healthScore -= 0.5;
    }
    findings.push({ severity: 'ok', system: 'queue', msg: `${proposals.length} total, ${pending} pending, 24h rate: ${rate ?? 'N/A'}%` });
  }

  // -- Disk --
  try {
    const queueSize = fs.existsSync(ACTION_QUEUE_FILE) ? fs.statSync(ACTION_QUEUE_FILE).size : 0;
    const outcomesSize = fs.existsSync(OUTCOMES_FILE) ? fs.statSync(OUTCOMES_FILE).size : 0;
    const totalMB = ((queueSize + outcomesSize) / 1048576).toFixed(1);
    if (parseFloat(totalMB) > 5) {
      findings.push({ severity: 'warn', system: 'disk', msg: `Proactive state files are ${totalMB}MB — consider cleanup` });
      healthScore -= 0.5;
    }
  } catch {}

  return { healthScore: Math.max(0, Math.min(10, Math.round(healthScore))), findings };
}

// ============================================================
// PHASE 2: REFLECT — Analyze patterns in proposal outcomes
// ============================================================
function reflect() {
  const insights = [];
  const outcomes = readJSONL(OUTCOMES_FILE);
  if (outcomes.length === 0) return { insights, deepInsights: [], uniqueCount: 0, rawCount: 0 };

  // -- Duplicate detection --
  const idCounts = {};
  for (const o of outcomes) {
    idCounts[o.proposalId] = (idCounts[o.proposalId] || 0) + 1;
  }
  const dupes = Object.entries(idCounts).filter(([, c]) => c > 1);
  if (dupes.length > 0) {
    const totalDupes = dupes.reduce((sum, [, c]) => sum + c, 0);
    insights.push({
      type: 'data-quality',
      msg: `Duplicate entries in outcomes log: ${dupes.length} proposalIds × avg ${(totalDupes / dupes.length).toFixed(1)} copies = ${outcomes.length} total lines (should be ~${Object.keys(idCounts).length})`,
      actionable: true,
      safe: true,
    });
  }

  // -- Deduplicate for analysis --
  const seen = new Set();
  const uniqueOutcomes = outcomes.filter(o => {
    const key = o.proposalId + o.decision;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });

  // -- Temporal patterns --
  const leaveStart = new Date('2026-02-24');
  const leaveEnd = new Date('2026-03-09');
  const now = new Date();
  const isOnLeave = now >= leaveStart && now <= leaveEnd;

  if (isOnLeave) {
    const priorOutcomes = uniqueOutcomes.filter(o => new Date(o.decidedAt || o.proposedAt) < leaveStart);
    const leaveOutcomes = uniqueOutcomes.filter(o => new Date(o.decidedAt || o.proposedAt) >= leaveStart);

    const priorApproval = priorOutcomes.filter(o => o.decision === 'approved').length;
    const priorTotal = priorOutcomes.filter(o => ['approved', 'denied', 'skipped'].includes(o.decision)).length;
    const priorRate = priorTotal > 0 ? Math.round(priorApproval / priorTotal * 100) : null;

    const leaveApproval = leaveOutcomes.filter(o => o.decision === 'approved').length;
    const leaveTotal = leaveOutcomes.filter(o => ['approved', 'denied', 'skipped'].includes(o.decision)).length;
    const leaveRate = leaveTotal > 0 ? Math.round(leaveApproval / leaveTotal * 100) : null;

    if (priorRate !== null && leaveRate !== null && priorRate - leaveRate > 15) {
      insights.push({
        type: 'temporal',
        msg: `Approval rate dropped ${priorRate}% → ${leaveRate}% since leave started (2/24). This is expected — user is less engaged during paternity leave.`,
        actionable: true,
        safe: false,
        proposal: 'Add context-aware instinct: suppress low-value proposals during leave period (2/24–3/9)'
      });
    }
  }

  // -- Per-action-type analysis with context --
  const byAction = {};
  for (const o of uniqueOutcomes) {
    const key = `${o.actionType}:${o.signalSource}`;
    if (!byAction[key]) byAction[key] = { approved: [], denied: [], skipped: [], failed: [] };
    const bucket = o.decision;
    if (byAction[key][bucket]) byAction[key][bucket].push(o);
  }

  for (const [key, data] of Object.entries(byAction)) {
    const [action, source] = key.split(':');
    const approved = data.approved || [];
    const denied = [...(data.denied || []), ...(data.skipped || [])];
    const total = approved.length + denied.length;
    if (total < 3) continue;

    // Find what approved ones had in common
    if (approved.length > 0 && denied.length > 0) {
      const approvedSummaries = approved.map(o => o.actionSummary || '').join(' ');
      const deniedNotes = denied.map(o => o.dismissalNote || o.dismissalReason || '').filter(Boolean);

      // Check if approved ones share a pattern (keyword overlap)
      if (approved.length >= 2) {
        insights.push({
          type: 'pattern',
          msg: `"${action}" from ${source}: ${approved.length}/${total} approved. Approved proposals: "${approved.slice(0, 3).map(o => o.actionSummary).join('", "')}". Look for what these have in common.`,
          actionable: false,
        });
      }
    }
  }

  // -- Instinct staleness --
  const instinctText = readText(INSTINCT_FILE);
  if (instinctText) {
    const dateMatch = instinctText.match(/auto-updated (\d{4}-\d{2}-\d{2})/);
    if (dateMatch) {
      const age = daysAgo(dateMatch[1]);
      if (age > 7) {
        insights.push({
          type: 'staleness',
          msg: `INSTINCT.md last updated ${age} days ago — may not reflect recent behavior`,
          actionable: true,
          safe: false,
          proposal: 'Trigger ProposalReflector re-evaluation'
        });
      }
    }
  }

  // -- Deep LLM-powered analysis --
  const deepResult = reflectDeep(uniqueOutcomes, byAction);
  if (deepResult.llmUnavailable) {
    insights.push({
      type: 'info',
      msg: 'Deep analysis unavailable — LLM endpoint not reachable',
      actionable: false,
    });
  }

  return { insights, deepInsights: deepResult.deepInsights, uniqueCount: uniqueOutcomes.length, rawCount: outcomes.length };
}

// ============================================================
// PHASE 3: MEMORY HYGIENE — Scan MEMORY.md for issues
// ============================================================
function memoryHygiene(dryRun) {
  const issues = [];
  const archiveActions = [];
  const memory = readText(MEMORY_FILE);
  if (!memory) return { issues, archiveActions };

  // Load escalation state
  const hygieneState = readJSON(HYGIENE_STATE_FILE) || { items: {}, lastPruned: null };
  const today = new Date().toISOString().slice(0, 10);

  // Prune old tier-3+ entries weekly
  if (!hygieneState.lastPruned || daysAgo(hygieneState.lastPruned) > 7) {
    for (const [hash, entry] of Object.entries(hygieneState.items)) {
      if (entry.tier >= 3 && entry.lastFlagged && daysAgo(entry.lastFlagged) > 30) {
        delete hygieneState.items[hash];
      }
    }
    hygieneState.lastPruned = today;
  }

  const lines = memory.split('\n');
  const now = new Date();

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];

    // Skip already-archived lines
    if (line.includes('[ARCHIVED')) continue;

    // Extract date from tagged entries
    const dateMatch = line.match(/\[(\d{4}-\d{2}-\d{2})\]/);
    const entryDate = dateMatch ? dateMatch[1] : null;
    const age = entryDate ? daysAgo(entryDate) : null;

    let issue = null;

    // Stale TODOs
    if (line.includes('[TODO]') && age !== null && age > 14) {
      issue = {
        type: 'stale-todo',
        severity: 'warn',
        line: i + 1,
        msg: `TODO from ${entryDate} (${age}d ago) — still relevant?`,
        snippet: line.trim().substring(0, 120),
        safe: false,
      };
    }

    // Plans past implied dates
    if (!issue && line.includes('[PLAN]') && age !== null && age > 30) {
      issue = {
        type: 'stale-plan',
        severity: 'info',
        line: i + 1,
        msg: `Plan from ${entryDate} (${age}d ago) — executed or still pending?`,
        snippet: line.trim().substring(0, 120),
        safe: false,
      };
    }

    // Deadline detection in entry text
    if (!issue) {
      const deadlineMatch = line.match(/by\s+(March|February|January|April|May)\s+(\d{1,2})/i);
      if (deadlineMatch) {
        const monthMap = { january: 0, february: 1, march: 2, april: 3, may: 4 };
        const month = monthMap[deadlineMatch[1].toLowerCase()];
        const day = parseInt(deadlineMatch[2]);
        if (month !== undefined) {
          const deadline = new Date(2026, month, day);
          const daysUntil = Math.floor((deadline - now) / 86400000);
          if (daysUntil >= 0 && daysUntil <= 7) {
            issue = {
              type: 'approaching-deadline',
              severity: 'warn',
              line: i + 1,
              msg: `Deadline in ${daysUntil} days (${deadlineMatch[0]})`,
              snippet: line.trim().substring(0, 120),
              safe: false,
            };
          } else if (daysUntil < 0 && daysUntil > -30) {
            issue = {
              type: 'past-deadline',
              severity: 'warn',
              line: i + 1,
              msg: `Deadline passed ${-daysUntil}d ago (${deadlineMatch[0]})`,
              snippet: line.trim().substring(0, 120),
              safe: false,
            };
          }
        }
      }
    }

    // Facts with old dates
    if (!issue && line.includes('[FACT]') && age !== null && age > 60) {
      issue = {
        type: 'stale-fact',
        severity: 'info',
        line: i + 1,
        msg: `Fact from ${entryDate} (${age}d) — still accurate?`,
        snippet: line.trim().substring(0, 120),
        safe: false,
      };
    }

    // Apply escalation tiers
    if (issue) {
      const contentHash = simpleHash((entryDate || '') + '|' + stripTags(line).slice(0, 60));
      const state = hygieneState.items[contentHash] || {
        firstFlagged: today,
        lastFlagged: today,
        timesReported: 0,
        tier: 0,
        lineContent: line,
      };
      state.timesReported++;
      state.lastFlagged = today;

      if (state.timesReported === 1) {
        // Tier 0: first time — flag normally
        state.tier = 0;
        issues.push(issue);
      } else if (state.timesReported === 2) {
        // Tier 1: repeated — emphasize
        state.tier = 1;
        issue.msg = `[Repeated] ${issue.msg}`;
        issue.severity = 'warn';
        issues.push(issue);
      } else if (state.timesReported === 3) {
        // Tier 2: auto-archive
        state.tier = 2;
        archiveActions.push({
          type: 'archive-stale-memory',
          safe: true,
          description: `Archive stale ${issue.type.replace('stale-', '')} from ${entryDate || 'unknown'} (flagged 3 nights): "${stripTags(line).slice(0, 60)}"`,
          execute: () => archiveMemoryLine(state.lineContent),
        });
      } else {
        // Tier 3+: silently skip
        state.tier = 3;
      }

      hygieneState.items[contentHash] = state;
    }
  }

  // Leave awareness
  const leaveMatch = memory.match(/leave\s+(\d+\/\d+)[–-](\d+\/\d+)/i);
  if (leaveMatch) {
    const endParts = leaveMatch[2].split('/');
    const leaveEnd = new Date(2026, parseInt(endParts[0]) - 1, parseInt(endParts[1]));
    const daysUntilBack = Math.floor((leaveEnd - now) / 86400000);
    if (daysUntilBack > 0 && daysUntilBack <= 3) {
      issues.push({
        type: 'leave-ending',
        severity: 'info',
        line: 0,
        msg: `Leave ends in ${daysUntilBack} days — consider preparing return-to-work items`,
        safe: false,
      });
    } else if (daysUntilBack <= 0 && daysUntilBack > -3) {
      issues.push({
        type: 'leave-ended',
        severity: 'warn',
        line: 0,
        msg: `Leave ended ${-daysUntilBack}d ago — update MEMORY.md, re-enable paused tasks?`,
        safe: false,
      });
    }
  }

  // Persist escalation state
  if (!dryRun) {
    writeJSONAtomic(HYGIENE_STATE_FILE, hygieneState);
  }

  return { issues, archiveActions };
}

/**
 * Archive a stale line in MEMORY.md by prepending [ARCHIVED yyyy-mm-dd].
 * Uses exact content match for safety. Idempotent.
 */
function archiveMemoryLine(originalLine) {
  const memory = readText(MEMORY_FILE);
  if (!memory) return { archived: false, reason: 'file-not-found' };

  // Check if already archived
  if (originalLine.includes('[ARCHIVED')) {
    return { archived: false, reason: 'already-archived' };
  }

  const idx = memory.indexOf(originalLine);
  if (idx === -1) {
    console.log(`[meditate] Archive: line not found in MEMORY.md (may have been edited)`);
    return { archived: false, reason: 'line-not-found' };
  }

  const today = new Date().toISOString().slice(0, 10);
  const archived = memory.substring(0, idx) + `[ARCHIVED ${today}] ` + memory.substring(idx);
  fs.writeFileSync(MEMORY_FILE, archived, 'utf8');
  return { archived: true };
}

// ============================================================
// PHASE 3b: MEMORY TRIAGE — Route extracted JSONL entries to topic files
// ============================================================

/**
 * Read topic file list for LLM context.
 * Returns array of { fileName, name, description }.
 */
function listTopicFilesForTriage() {
  if (!fs.existsSync(TOPICS_DIR)) return [];
  const ALLOWED_SUBDIRS = ['projects', 'reference'];
  const topics = [];

  // Root-level .md files
  const rootEntries = fs.readdirSync(TOPICS_DIR, { withFileTypes: true });
  for (const entry of rootEntries) {
    if (!entry.isFile() || !entry.name.endsWith('.md') || entry.name.startsWith('.')) continue;
    const meta = parseTopicFrontmatter(path.join(TOPICS_DIR, entry.name), entry.name);
    if (meta) topics.push(meta);
  }

  // Allowed subdirectories
  for (const subdir of ALLOWED_SUBDIRS) {
    const subdirPath = path.join(TOPICS_DIR, subdir);
    if (!fs.existsSync(subdirPath)) continue;
    const subEntries = fs.readdirSync(subdirPath, { withFileTypes: true });
    for (const entry of subEntries) {
      if (!entry.isFile() || !entry.name.endsWith('.md') || entry.name.startsWith('.')) continue;
      const relativeName = `${subdir}/${entry.name}`;
      const meta = parseTopicFrontmatter(path.join(subdirPath, entry.name), relativeName);
      if (meta) topics.push(meta);
    }
  }

  return topics;
}

/**
 * Parse YAML frontmatter from a topic file (minimal parser).
 */
function parseTopicFrontmatter(fullPath, relativeName) {
  try {
    const content = fs.readFileSync(fullPath, 'utf8');
    const fmMatch = content.match(/^---\n([\s\S]*?)\n---/);
    if (!fmMatch) return { fileName: relativeName, name: relativeName, description: '' };
    const fm = fmMatch[1];
    const name = (fm.match(/^name:\s*(.+)$/m) || [])[1] || relativeName;
    const description = (fm.match(/^description:\s*(.+)$/m) || [])[1] || '';
    return { fileName: relativeName, name: name.trim(), description: description.trim() };
  } catch {
    return null;
  }
}

/**
 * Normalize a fact for dedup comparison (mirrors isDuplicateFact in layeredMemory.ts).
 */
function normalizeFact(s) {
  return s.replace(/^-\s*\[\d{4}-\d{2}-\d{2}\]\s*/, '')
    .toLowerCase()
    .replace(/[^a-z0-9\u4e00-\u9fff\s]/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}

/**
 * Check if a fact is a near-duplicate of an existing entry in file content.
 * Uses normalized trigram similarity (≥70% overlap = duplicate), matching layeredMemory.ts.
 */
function isDuplicateFactForTriage(fact, content) {
  const trigramsOf = (s) => {
    const t = new Set();
    for (let i = 0; i <= s.length - 3; i++) t.add(s.slice(i, i + 3));
    return t;
  };
  const similarity = (a, b) => {
    if (a.size === 0 || b.size === 0) return 0;
    let overlap = 0;
    for (const t of a) { if (b.has(t)) overlap++; }
    return overlap / Math.min(a.size, b.size);
  };

  const target = normalizeFact(fact);
  if (target.length < 10) return false;
  const targetTrigrams = trigramsOf(target);

  return content.split('\n')
    .filter(line => line.startsWith('- '))
    .some(line => {
      const lineNorm = normalizeFact(line);
      if (lineNorm.length < 10) return false;
      if (target === lineNorm) return true;
      return similarity(targetTrigrams, trigramsOf(lineNorm)) >= 0.70;
    });
}

/**
 * Append a fact to a topic file (mirrors progressiveMemory.ts appendToTopicFile).
 * Returns { status: 'appended' | 'duplicate' | 'failed' }.
 * Only appends to existing topic files — does NOT create new ones.
 */
function appendFactToTopicFile(fileName, fact) {
  const fullPath = path.join(TOPICS_DIR, fileName);
  const dateStr = new Date().toISOString().slice(0, 10);
  const entry = `- [${dateStr}] ${fact}`;

  try {
    if (!fs.existsSync(fullPath)) {
      console.log(`[meditate] Topic file does not exist: ${fileName}`);
      return { status: 'failed' };
    }
    const content = fs.readFileSync(fullPath, 'utf8');
    if (isDuplicateFactForTriage(fact, content)) return { status: 'duplicate' };
    const updated = content.trimEnd() + '\n' + entry + '\n';
    const tmpPath = fullPath + '.tmp.' + Date.now();
    fs.writeFileSync(tmpPath, updated, 'utf8');
    fs.renameSync(tmpPath, fullPath);
    return { status: 'appended' };
  } catch (e) {
    console.log(`[meditate] Failed to append to topic file ${fileName}: ${e.message}`);
    return { status: 'failed' };
  }
}

/**
 * Mark a JSONL entry as triaged by rewriting the daily file.
 */
function markEntryTriaged(filePath, entryId) {
  try {
    const content = fs.readFileSync(filePath, 'utf8');
    const lines = content.split('\n').filter(l => l.trim());
    let found = false;
    const updated = [];
    for (const line of lines) {
      try {
        const entry = JSON.parse(line);
        if (entry.id === entryId) {
          entry.triaged = true;
          found = true;
          updated.push(JSON.stringify(entry));
        } else {
          updated.push(line);
        }
      } catch {
        updated.push(line);
      }
    }
    if (found) {
      const tmpPath = filePath + '.tmp.' + Date.now();
      fs.writeFileSync(tmpPath, updated.join('\n') + '\n', 'utf8');
      fs.renameSync(tmpPath, filePath);
    }
    return found;
  } catch {
    return false;
  }
}

/**
 * Extract top keywords from topic file content (mirrors progressiveMemory.ts extractKeywords).
 */
function extractTopicKeywords(name, description, content, maxKeywords = 6) {
  const STOP_WORDS = new Set([
    'the', 'and', 'for', 'are', 'but', 'not', 'you', 'all', 'can', 'had',
    'her', 'was', 'one', 'our', 'out', 'has', 'have', 'been', 'from', 'will',
    'with', 'they', 'this', 'that', 'what', 'when', 'make', 'like', 'each',
    'does', 'then', 'them', 'than', 'into', 'also', 'just', 'more', 'some',
    'very', 'about', 'which', 'their', 'would', 'there', 'could', 'other',
    'should', 'after', 'before', 'being', 'between', 'through', 'during',
    'prefer', 'prefers', 'preferred', 'uses', 'using', 'used', 'based',
    'such', 'over', 'most', 'only', 'work', 'works', 'working',
  ]);

  let text = content;
  text = text.replace(/\[(\d{4}-\d{2}-\d{2})\]/g, '');
  text = text.replace(/\b\d{4}-\d{2}-\d{2}\b/g, '');
  text = text.replace(/\b(today|tomorrow|yesterday|tonight|weekend)\b/gi, '');
  text = text.replace(/\*\*([^*]+)\*\*/g, '$1');
  text = text.replace(/\[([^\]]+)\]\([^)]+\)/g, '$1');
  text = text.replace(/^-\s+/gm, '');
  text = text.replace(/`[^`]+`/g, '');
  text = text.replace(/#+\s*/g, '');

  const tokenize = (s) => s.toLowerCase().split(/[\s,;:!?()\[\]{}"'`/\\-]+/).filter(w => w.length > 3);
  const excludeWords = new Set(tokenize(`${name} ${description}`));

  const words = tokenize(text);
  const freq = new Map();
  for (const w of words) {
    if (STOP_WORDS.has(w)) continue;
    if (excludeWords.has(w)) continue;
    if (/^\d+$/.test(w)) continue;
    freq.set(w, (freq.get(w) || 0) + 1);
  }

  return [...freq.entries()]
    .sort((a, b) => b[1] - a[1])
    .slice(0, maxKeywords)
    .map(([w]) => w);
}

/**
 * Rebuild MEMORY.md index from topic files (mirrors progressiveMemory.ts rebuildIndex).
 * Ensures MEMORY.md reflects newly-routed facts after triage.
 */
function rebuildMemoryIndex() {
  const topics = listTopicFilesForTriage();
  if (topics.length === 0) return;

  const displayBase = '{HOME_DIR}/memory/topics';

  const rootTopics = [];
  const projectTopics = [];
  const referenceTopics = [];

  for (const t of topics) {
    const normalized = t.fileName.replace(/\\/g, '/');
    if (normalized.startsWith('projects/')) projectTopics.push(t);
    else if (normalized.startsWith('reference/')) referenceTopics.push(t);
    else rootTopics.push(t);
  }

  rootTopics.sort((a, b) => a.name.localeCompare(b.name));
  projectTopics.sort((a, b) => a.name.localeCompare(b.name));
  referenceTopics.sort((a, b) => a.name.localeCompare(b.name));

  const formatLine = (t) => {
    // Read file content for keyword extraction
    let keywords = [];
    try {
      const fullPath = path.join(TOPICS_DIR, t.fileName);
      const content = fs.readFileSync(fullPath, 'utf8');
      // Strip frontmatter before extracting keywords
      const body = content.replace(/^---\n[\s\S]*?\n---\n?/, '');
      keywords = extractTopicKeywords(t.name, t.description, body);
    } catch { /* ignore */ }
    const tagSuffix = keywords.length > 0 ? ` \`[${keywords.join(', ')}]\`` : '';
    const normalized = t.fileName.replace(/\\/g, '/');
    return `- [${t.name}](${displayBase}/${normalized}) — ${t.description}${tagSuffix}`;
  };

  const lines = [
    '# Memory',
    '',
    'USER.md is loaded automatically — identity, role, key preferences.',
    '',
  ];

  if (rootTopics.length > 0) {
    lines.push('## Topics');
    for (const t of rootTopics) lines.push(formatLine(t));
  }
  if (projectTopics.length > 0) {
    lines.push('## Projects');
    for (const t of projectTopics) lines.push(formatLine(t));
  }
  if (referenceTopics.length > 0) {
    lines.push('## Reference');
    for (const t of referenceTopics) lines.push(formatLine(t));
  }
  lines.push('');

  try {
    const tmpPath = MEMORY_FILE + '.tmp.' + Date.now();
    fs.writeFileSync(tmpPath, lines.join('\n'), 'utf8');
    fs.renameSync(tmpPath, MEMORY_FILE);
    console.log('[meditate] Rebuilt MEMORY.md index after triage');
  } catch (e) {
    console.log(`[meditate] Failed to rebuild MEMORY.md: ${e.message}`);
  }
}

/**
 * Memory Triage: route un-triaged extracted entries to progressive memory topic files.
 * Uses LLM to determine the best topic for each entry.
 */
function memoryTriage(dryRun) {
  const results = { triaged: 0, skipped: 0, failed: 0, llmUnavailable: false };
  const FALLBACK_TOPIC = 'reference/_general.md';

  if (!fs.existsSync(EXTRACTED_DIR)) return results;

  // 1. Collect un-triaged entries from last 7 days
  const now = Date.now();
  const SEVEN_DAYS = 7 * 86400000;
  const entries = [];

  try {
    const files = fs.readdirSync(EXTRACTED_DIR).filter(f => f.endsWith('.jsonl')).sort().reverse();
    for (const file of files) {
      const dateStr = file.replace('.jsonl', '');
      const fileDate = new Date(dateStr + 'T12:00:00').getTime(); // noon to avoid timezone issues
      if (isNaN(fileDate) || now - fileDate > SEVEN_DAYS) continue;

      const filePath = path.join(EXTRACTED_DIR, file);
      const lines = fs.readFileSync(filePath, 'utf8').trim().split('\n').filter(Boolean);
      for (const line of lines) {
        try {
          const entry = JSON.parse(line);
          if (!entry.triaged && entry.content) {
            entries.push({ ...entry, _filePath: filePath, _dateStr: dateStr });
          }
        } catch { /* skip malformed */ }
      }
    }
  } catch (e) {
    console.log(`[meditate] Memory triage: failed to scan extracted dir: ${e.message}`);
    return results;
  }

  if (entries.length === 0) return results;

  // 2. Build topic list for LLM context
  const topics = listTopicFilesForTriage();
  if (topics.length === 0) {
    console.log('[meditate] Memory triage: no topic files found, skipping');
    return results;
  }

  const topicListStr = topics.map(t => `- ${t.fileName}: ${t.name} — ${t.description}`).join('\n');

  // 3. Process entries in batches of 10 (LLM can route multiple at once)
  const BATCH_SIZE = 10;
  for (let i = 0; i < entries.length; i += BATCH_SIZE) {
    const batch = entries.slice(i, i + BATCH_SIZE);
    const entriesStr = batch.map((e, idx) => `${idx + 1}. [${e.extracted_at}] ${e.content}`).join('\n');

    // Check for topic:hints in tags
    const hintsMap = {};
    for (let j = 0; j < batch.length; j++) {
      const tags = batch[j].tags || [];
      const topicTag = tags.find(t => t.startsWith('topic:'));
      if (topicTag) hintsMap[j + 1] = topicTag.slice(6);
    }

    const hintStr = Object.keys(hintsMap).length > 0
      ? `\nSome entries have topic hints from extraction:\n${Object.entries(hintsMap).map(([idx, hint]) => `Entry ${idx} → ${hint}`).join('\n')}\nUse these hints if the topic file exists, but override if a better match exists.\n`
      : '';

    const prompt = `You are triaging extracted memory entries into topic files for a personal knowledge system.

Available topic files:
${topicListStr}
${hintStr}
Entries to route:
${entriesStr}

For each entry, output a line in this exact format:
<number>: <topic_filename>

Rules:
- Use exact filenames from the list above
- Use ${FALLBACK_TOPIC} only if no topic is remotely relevant
- If an entry is too vague or low-value to keep, output: <number>: SKIP
- Do NOT create new topic files — only use existing ones

Output only the routing lines, nothing else.`;

    const response = callLLM(prompt, 256);
    if (response === null) {
      results.llmUnavailable = true;
      results.skipped += batch.length;
      continue;
    }

    // Parse routing decisions
    const routingLines = response.trim().split('\n');
    for (const routingLine of routingLines) {
      const match = routingLine.match(/^(\d+):\s*(.+)$/);
      if (!match) continue;
      const idx = parseInt(match[1]) - 1;
      const topicFile = match[2].trim();
      if (idx < 0 || idx >= batch.length) continue;

      const entry = batch[idx];

      if (topicFile === 'SKIP') {
        // Mark as triaged but don't route — entry is low-value
        const marked = dryRun ? true : markEntryTriaged(entry._filePath, entry.id);
        if (marked) results.skipped++;
        else results.failed++;
        continue;
      }

      // Validate topic file exists in our list
      const validTopic = topics.some(t => t.fileName === topicFile);
      if (!validTopic) {
        console.log(`[meditate] Memory triage: LLM suggested unknown topic "${topicFile}" for entry ${entry.id}, using ${FALLBACK_TOPIC}`);
      }
      const targetFile = validTopic ? topicFile : FALLBACK_TOPIC;

      if (!dryRun) {
        const result = appendFactToTopicFile(targetFile, entry.content);
        if (result.status === 'appended') {
          const marked = markEntryTriaged(entry._filePath, entry.id);
          if (marked) {
            results.triaged++;
          } else {
            results.failed++;
          }
        } else if (result.status === 'duplicate') {
          const marked = markEntryTriaged(entry._filePath, entry.id);
          if (marked) results.skipped++;
          else results.failed++;
        } else {
          results.failed++;
        }
      } else {
        results.triaged++;
      }
    }
  }

  return results;
}

// ============================================================
// PHASE 4: PROPOSE — Generate self-improvement actions
// ============================================================
function propose(diagnosis, reflection, hygiene) {
  const actions = [];

  // Safe: Deduplicate outcomes log
  if (reflection.rawCount && reflection.uniqueCount && reflection.rawCount > reflection.uniqueCount * 1.5) {
    actions.push({
      type: 'cleanup',
      safe: true,
      description: `Deduplicate proposal-outcomes.jsonl: ${reflection.rawCount} → ~${reflection.uniqueCount} entries`,
      execute: () => deduplicateOutcomes(),
    });
  }

  // Safe: Memory hygiene archive actions (from escalation tiers)
  for (const archiveAction of (hygiene.archiveActions || [])) {
    actions.push(archiveAction);
  }

  // Risky: Context-aware instinct proposals
  for (const insight of (reflection.insights || [])) {
    if (insight.actionable && insight.proposal) {
      actions.push({
        type: 'instinct-update',
        safe: insight.safe || false,
        description: insight.proposal,
        source: insight.msg,
        trackingKey: `instinct-update:${simpleHash(insight.proposal.slice(0, 40))}`,
      });
    }
  }

  // Risky: Memory hygiene proposals
  for (const issue of (hygiene.issues || [])) {
    if (issue.type === 'approaching-deadline') {
      actions.push({
        type: 'deadline-alert',
        safe: false,
        description: `Surface in morning briefing: ${issue.msg}`,
        source: issue.snippet,
        trackingKey: `deadline-alert:${issue.snippet ? simpleHash(issue.snippet.slice(0, 40)) : issue.msg}`,
      });
    }
    if (issue.type === 'leave-ending' || issue.type === 'leave-ended') {
      actions.push({
        type: 'lifecycle',
        safe: false,
        description: issue.msg,
        trackingKey: `lifecycle:${issue.type}`,
      });
    }
  }

  // Risky: Re-enable paused tasks suggestion
  for (const finding of (diagnosis.findings || [])) {
    if (finding.system === 'tasks' && finding.severity === 'info' && finding.msg.includes('paused')) {
      // Extract task name for stable key
      const nameMatch = finding.msg.match(/"([^"]+)"/);
      const taskName = nameMatch ? nameMatch[1] : 'unknown';
      actions.push({
        type: 'task-review',
        safe: false,
        description: finding.msg,
        trackingKey: `task-review:${taskName}`,
      });
    }
  }

  return actions;
}

// ============================================================
// PHASE 5: ACT — Execute safe actions, log everything
// ============================================================
function act(actions, dryRun) {
  const results = [];

  for (const action of actions) {
    if (action.safe && action.execute && !dryRun) {
      try {
        const result = action.execute();
        results.push({ ...action, status: 'executed', result });
      } catch (err) {
        results.push({ ...action, status: 'failed', error: err.message });
      }
    } else if (action.safe && action.execute && dryRun) {
      results.push({ ...action, status: 'dry-run' });
    } else {
      results.push({ ...action, status: 'queued-for-review' });
    }
  }

  return results;
}

// --- Safe action implementations ---
function deduplicateOutcomes() {
  const outcomes = readJSONL(OUTCOMES_FILE);
  const seen = new Set();
  const unique = outcomes.filter(o => {
    const key = `${o.proposalId}:${o.decision}:${o.decidedAt}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });

  const before = outcomes.length;
  fs.writeFileSync(OUTCOMES_FILE, unique.map(o => JSON.stringify(o)).join('\n') + '\n', 'utf8');
  return { before, after: unique.length, removed: before - unique.length };
}

/**
 * Write deep meditation insights to a separate section in INSTINCT.md.
 * Uses distinct markers from ProposalReflector's learned-preferences section.
 */
function writeDeepInstincts(deepInsights, dryRun) {
  if (dryRun) return;

  const MEDITATION_SECTION_START = '<!-- meditation-insights-start -->';
  const MEDITATION_SECTION_END = '<!-- meditation-insights-end -->';
  const today = new Date().toISOString().slice(0, 10);
  const hasInsights = deepInsights.length > 0;
  const calibratedSuffix = hasInsights ? ', meditation-calibrated' : '';

  const sectionLines = [
    MEDITATION_SECTION_START,
    `## Meditation Insights (deep-analysis ${today}${calibratedSuffix})`,
    '',
    ...deepInsights.map(i => `- [MEDITATION-INSIGHT] ${i.actionType} from ${i.signalSource}: RULE: ${i.rule} | SKIP: ${i.skip}`),
    '',
    MEDITATION_SECTION_END,
  ];
  const sectionBlock = sectionLines.join('\n');

  let content = '';
  if (fs.existsSync(INSTINCT_FILE)) {
    content = fs.readFileSync(INSTINCT_FILE, 'utf8');
  } else {
    content = '# INSTINCT.md\n\nProactive agent instincts — learned preferences, signal tuning, and behavioral rules.\n\n';
  }

  const startIdx = content.indexOf(MEDITATION_SECTION_START);
  const endIdx = content.indexOf(MEDITATION_SECTION_END);
  if (startIdx !== -1 && endIdx !== -1) {
    content = content.substring(0, startIdx) + sectionBlock + content.substring(endIdx + MEDITATION_SECTION_END.length);
  } else {
    content = content.trimEnd() + '\n\n' + sectionBlock + '\n';
  }

  // Atomic write
  const tmpPath = INSTINCT_FILE + '.tmp.' + Date.now();
  fs.writeFileSync(tmpPath, content, 'utf8');
  fs.renameSync(tmpPath, INSTINCT_FILE);

  if (hasInsights) {
    console.log(`[meditate] Wrote ${deepInsights.length} deep insight(s) to INSTINCT.md`);
  }
}

/**
 * Track proposal-for-review repetition. Returns updated actions with stale annotations.
 */
function trackProposals(actions, dryRun) {
  const tracker = readJSON(PROPOSALS_TRACKER_FILE) || { proposals: {} };
  const today = new Date().toISOString().slice(0, 10);
  const updatedActions = [];
  const archivedDescriptions = [];

  for (const action of actions) {
    if (action.safe) {
      updatedActions.push(action);
      continue;
    }

    // Build stable tracking key
    const trackingKey = action.trackingKey || `${action.type}:${simpleHash(action.description.slice(0, 40))}`;
    const existing = tracker.proposals[trackingKey];

    if (!existing) {
      tracker.proposals[trackingKey] = {
        description: action.description.slice(0, 120),
        firstProposed: today,
        lastProposed: today,
        timesProposed: 1,
        status: 'active',
      };
      updatedActions.push(action);
    } else if (existing.status === 'archived') {
      // Already archived — don't propose
      continue;
    } else {
      existing.timesProposed++;
      existing.lastProposed = today;

      if (existing.timesProposed >= 5) {
        // Archive — stop proposing
        existing.status = 'archived';
        archivedDescriptions.push(action.description.slice(0, 80));
      } else if (existing.timesProposed >= 3) {
        // Stale — annotate
        action.description = `[STALE-PROPOSAL] ${action.description}`;
        updatedActions.push(action);
      } else {
        updatedActions.push(action);
      }
    }
  }

  if (archivedDescriptions.length > 0) {
    for (const desc of archivedDescriptions) {
      console.log(`[meditate] 🗑️ Archived stale proposal (5+ nights): "${desc}"`);
    }
  }

  if (!dryRun) {
    writeJSONAtomic(PROPOSALS_TRACKER_FILE, tracker);
  }

  return updatedActions;
}

// ============================================================
// SELF-HEAL — Detect and fix {AGENT_NAME} infrastructure issues
// ============================================================

/**
 * Check HTTP health of a local service (sync subprocess).
 * Returns { ok, status?, error? }.
 */
function checkServiceHealth(port, path = '/api/health') {
  try {
    const result = execSync(
      `node -e "const http=require('http');const r=http.get('http://127.0.0.1:${port}${path}',{timeout:5000},res=>{let d='';res.on('data',c=>d+=c);res.on('end',()=>{console.log(JSON.stringify({ok:res.statusCode===200,status:res.statusCode}));process.exit(0)})});r.on('error',e=>{console.log(JSON.stringify({ok:false,error:e.message}));process.exit(0)});r.on('timeout',()=>{r.destroy();console.log(JSON.stringify({ok:false,error:'timeout'}));process.exit(0)})"`,
      { encoding: 'utf8', timeout: 8000, windowsHide: true }
    ).trim();
    return JSON.parse(result || '{"ok":false,"error":"empty"}');
  } catch {
    return { ok: false, error: 'subprocess-failed' };
  }
}

/**
 * Self-heal: detect infrastructure issues and apply safe fixes.
 * Returns { checks, actions }.
 *
 * Safety: NEVER creates/cancels tasks, NEVER sends messages, NEVER modifies SOUL.md.
 * All fixes are local file operations (rotation, cleanup).
 */
function selfHeal(dryRun) {
  const checks = [];
  const actions = [];

  // 1. Daemon health (port 11711)
  const daemonHealth = checkServiceHealth(11711);
  checks.push({
    system: 'daemon',
    ok: daemonHealth.ok,
    msg: daemonHealth.ok ? 'Daemon healthy (port 11711)' : `Daemon unreachable: ${daemonHealth.error || 'status ' + daemonHealth.status}`,
  });

  // 2. Copilot Proxy health (port 23333)
  const proxyHealth = checkServiceHealth(23333);
  checks.push({
    system: 'proxy',
    ok: proxyHealth.ok,
    msg: proxyHealth.ok ? 'Copilot Proxy healthy (port 23333)' : `Copilot Proxy unreachable: ${proxyHealth.error || 'status ' + proxyHealth.status}`,
  });

  // 3. Outcomes file rotation (archive if >1MB, keep last 500 entries in active file)
  try {
    if (fs.existsSync(OUTCOMES_FILE)) {
      const stat = fs.statSync(OUTCOMES_FILE);
      const sizeMB = (stat.size / 1048576).toFixed(2);
      if (stat.size > 1048576) {
        checks.push({ system: 'outcomes', ok: false, msg: `proposal-outcomes.jsonl is ${sizeMB}MB — rotating` });
        if (!dryRun) {
          const outcomes = readJSONL(OUTCOMES_FILE);
          // Archive older entries
          const archivePath = OUTCOMES_FILE.replace('.jsonl', `-archive-${new Date().toISOString().slice(0, 10)}.jsonl`);
          if (outcomes.length > 500) {
            const toArchive = outcomes.slice(0, outcomes.length - 500);
            const toKeep = outcomes.slice(-500);
            // Append to archive (don't overwrite previous archives)
            fs.appendFileSync(archivePath, toArchive.map(o => JSON.stringify(o)).join('\n') + '\n', 'utf8');
            fs.writeFileSync(OUTCOMES_FILE, toKeep.map(o => JSON.stringify(o)).join('\n') + '\n', 'utf8');
            actions.push({ system: 'outcomes', msg: `Rotated: archived ${toArchive.length} entries to ${path.basename(archivePath)}, kept ${toKeep.length} active` });
          }
        } else {
          actions.push({ system: 'outcomes', msg: `[dry-run] Would rotate outcomes (${sizeMB}MB)` });
        }
      } else {
        checks.push({ system: 'outcomes', ok: true, msg: `proposal-outcomes.jsonl is ${sizeMB}MB` });
      }
    }
  } catch (e) {
    checks.push({ system: 'outcomes', ok: false, msg: `Failed to check outcomes: ${e.message}` });
  }

  // 4. Meditation log rotation (archive if >500KB)
  try {
    if (fs.existsSync(MEDITATION_LOG)) {
      const stat = fs.statSync(MEDITATION_LOG);
      const sizeKB = (stat.size / 1024).toFixed(0);
      if (stat.size > 512000) {
        checks.push({ system: 'meditation-log', ok: false, msg: `meditation-log.md is ${sizeKB}KB — rotating` });
        if (!dryRun) {
          const content = fs.readFileSync(MEDITATION_LOG, 'utf8');
          const entries = content.split(/^---$/m);
          if (entries.length > 30) {
            const header = entries[0]; // "# Meditation Log\n..." preamble
            const archivePath = MEDITATION_LOG.replace('.md', `-archive-${new Date().toISOString().slice(0, 10)}.md`);
            const toArchive = entries.slice(0, entries.length - 30);
            const toKeep = entries.slice(-30);
            fs.appendFileSync(archivePath, toArchive.join('---') + '\n', 'utf8');
            fs.writeFileSync(MEDITATION_LOG, header + '---' + toKeep.join('---'), 'utf8');
            actions.push({ system: 'meditation-log', msg: `Rotated: archived ${toArchive.length - 1} entries, kept last 30` });
          }
        } else {
          actions.push({ system: 'meditation-log', msg: `[dry-run] Would rotate meditation log (${sizeKB}KB)` });
        }
      } else {
        checks.push({ system: 'meditation-log', ok: true, msg: `meditation-log.md is ${sizeKB}KB` });
      }
    }
  } catch (e) {
    checks.push({ system: 'meditation-log', ok: false, msg: `Failed to check meditation log: ${e.message}` });
  }

  // 5. Stale background sessions (detection only — SessionCleaner handles cleanup)
  try {
    const bgSessionsDir = path.join(CORTANA_HOME, 'sessions', 'background');
    if (fs.existsSync(bgSessionsDir)) {
      const files = fs.readdirSync(bgSessionsDir).filter(f => f.endsWith('.jsonl'));
      const thirtyDaysAgo = Date.now() - 30 * 86400000;
      const stale = files.filter(f => {
        try { return fs.statSync(path.join(bgSessionsDir, f)).mtimeMs < thirtyDaysAgo; } catch { return false; }
      });
      if (stale.length > 10) {
        checks.push({ system: 'sessions', ok: false, msg: `${stale.length} background sessions older than 30d (SessionCleaner should handle)` });
      } else {
        checks.push({ system: 'sessions', ok: true, msg: `${files.length} background sessions, ${stale.length} stale` });
      }
    }
  } catch { /* skip */ }

  // 6. Scheduler reports GC check (detection only — reportStore handles cleanup)
  try {
    const reportsDir = path.join(CORTANA_HOME, 'teams-tasks', 'reports');
    if (fs.existsSync(reportsDir)) {
      const files = fs.readdirSync(reportsDir).filter(f => f.endsWith('.json'));
      const thirtyDaysAgo = Date.now() - 30 * 86400000;
      const stale = files.filter(f => {
        try { return fs.statSync(path.join(reportsDir, f)).mtimeMs < thirtyDaysAgo; } catch { return false; }
      });
      if (stale.length > 20) {
        checks.push({ system: 'reports', ok: false, msg: `${stale.length} scheduler reports older than 30d (reportStore should GC)` });
      } else {
        checks.push({ system: 'reports', ok: true, msg: `${files.length} reports, ${stale.length} older than 30d` });
      }
    }
  } catch { /* skip */ }

  // 7. Monitor consecutive failures (detection — log for awareness)
  try {
    const monitorsData = readJSON(MONITORS_FILE);
    if (monitorsData?.monitors) {
      const failing = monitorsData.monitors.filter(m => (m.consecutiveFailures || 0) > 5);
      for (const m of failing) {
        checks.push({ system: 'monitors', ok: false, msg: `Monitor "${m.chatName}" has ${m.consecutiveFailures} consecutive failures — may need restart` });
      }
    }
  } catch { /* skip */ }

  // 8. KG server health
  const kgOk = kgHealthCheck();
  checks.push({
    system: 'knowledge-graph',
    ok: kgOk,
    msg: kgOk ? 'KG server healthy' : 'KG server unreachable',
  });

  return { checks, actions };
}

// ============================================================
// LOG — Append meditation entry
// ============================================================
function logMeditation(diagnosis, reflection, hygiene, triage, actionResults, selfHealing, dryRun) {
  const now = new Date();
  const dateStr = now.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  const timeStr = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false });

  const lines = [];
  lines.push(`---`);
  lines.push(`## 🧘 Meditation — ${dateStr} ${timeStr}${dryRun ? ' (DRY RUN)' : ''}`);
  lines.push('');
  lines.push(`### Health Score: ${diagnosis.healthScore}/10`);
  lines.push('');

  // Diagnose
  lines.push('### Diagnose');
  for (const f of diagnosis.findings) {
    const icon = { ok: '✅', warn: '⚠️', error: '❌', info: 'ℹ️' }[f.severity] || '•';
    lines.push(`- ${icon} [${f.system}] ${f.msg}`);
  }
  lines.push('');

  // Reflect
  if (reflection.insights && reflection.insights.length > 0) {
    lines.push('### Reflect');
    for (const i of reflection.insights) {
      const icon = { temporal: '📈', pattern: '🔍', 'data-quality': '🔄', staleness: '📅' }[i.type] || '💡';
      lines.push(`- ${icon} ${i.msg}`);
    }
    lines.push('');
  }

  // Deep Patterns (LLM-analyzed)
  if (reflection.deepInsights && reflection.deepInsights.length > 0) {
    lines.push('### Deep Patterns');
    for (const i of reflection.deepInsights) {
      lines.push(`- 🧠 **${i.actionType}** from ${i.signalSource}:`);
      lines.push(`  - RULE: ${i.rule}`);
      lines.push(`  - SKIP: ${i.skip}`);
    }
    lines.push('');
  }

  // Memory Hygiene
  if (hygiene.issues && hygiene.issues.length > 0) {
    lines.push('### Memory Hygiene');
    for (const i of hygiene.issues) {
      const icon = { warn: '⚠️', info: 'ℹ️' }[i.severity] || '📋';
      lines.push(`- ${icon} ${i.msg}`);
      if (i.snippet) lines.push(`  > ${i.snippet}`);
    }
    lines.push('');
  }

  // Memory Triage
  if (triage && (triage.triaged > 0 || triage.skipped > 0 || triage.failed > 0)) {
    lines.push('### Memory Triage');
    lines.push(`- 📥 Routed ${triage.triaged} extracted entries to topic files`);
    if (triage.skipped > 0) lines.push(`- ⏭️ Skipped ${triage.skipped} entries (low-value or dedup)`);
    if (triage.failed > 0) lines.push(`- ❌ Failed to route ${triage.failed} entries`);
    if (triage.llmUnavailable) lines.push(`- ⚠️ LLM unavailable — some entries deferred`);
    lines.push('');
  }

  // Self-Healing
  if (selfHealing) {
    const failedChecks = selfHealing.checks.filter(c => !c.ok);
    const passedChecks = selfHealing.checks.filter(c => c.ok);
    if (failedChecks.length > 0 || selfHealing.actions.length > 0) {
      lines.push('### Self-Healing');
      for (const c of failedChecks) {
        lines.push(`- ❌ [${c.system}] ${c.msg}`);
      }
      for (const a of selfHealing.actions) {
        lines.push(`- 🔧 [${a.system}] ${a.msg}`);
      }
      if (passedChecks.length > 0) {
        lines.push(`- ✅ ${passedChecks.length} system(s) healthy: ${passedChecks.map(c => c.system).join(', ')}`);
      }
      lines.push('');
    }
  }

  // Actions
  const executed = actionResults.filter(a => a.status === 'executed');
  const queued = actionResults.filter(a => a.status === 'queued-for-review');
  const dryRunActions = actionResults.filter(a => a.status === 'dry-run');

  if (executed.length > 0) {
    lines.push('### Actions Taken (safe)');
    for (const a of executed) {
      lines.push(`- 🧹 ${a.description}${a.result ? ` → ${JSON.stringify(a.result)}` : ''}`);
    }
    lines.push('');
  }

  if (dryRunActions.length > 0) {
    lines.push('### Actions (dry-run, would execute)');
    for (const a of dryRunActions) {
      lines.push(`- 🔍 ${a.description}`);
    }
    lines.push('');
  }

  if (queued.length > 0) {
    lines.push('### Proposals for Review');
    for (const a of queued) {
      lines.push(`- 💡 ${a.description}`);
      if (a.source) lines.push(`  _Reason: ${a.source}_`);
    }
    lines.push('');
  }

  if (actionResults.length === 0) {
    lines.push('### Actions');
    lines.push('- ✨ Nothing to do — all systems nominal');
    lines.push('');
  }

  const entry = lines.join('\n');

  if (!dryRun) {
    // Append to meditation log
    const existing = fs.existsSync(MEDITATION_LOG) ? fs.readFileSync(MEDITATION_LOG, 'utf8') : '# Meditation Log\n\n{AGENT_NAME}\'s self-improvement journal.\n\n';
    fs.writeFileSync(MEDITATION_LOG, existing + entry + '\n', 'utf8');
  }

  return entry;
}

// ============================================================
// KNOWLEDGE GRAPH NIGHTLY INGESTION
// ============================================================

/**
 * Simple file finder for external directories (mirrors externalDirIndexer.ts logic).
 */
function findExternalFiles(dirPath, patterns, recursive) {
  const files = [];
  const IGNORE = new Set(['.git', 'node_modules', '__pycache__', 'venv', '.obsidian']);

  const walk = (dir) => {
    try {
      const entries = fs.readdirSync(dir, { withFileTypes: true });
      for (const entry of entries) {
        const fullPath = path.join(dir, entry.name);
        if (entry.isDirectory()) {
          if (recursive && !entry.name.startsWith('.') && !IGNORE.has(entry.name)) {
            walk(fullPath);
          }
        } else if (entry.isFile()) {
          const matches = patterns.some(p => {
            if (p.startsWith('*.')) return entry.name.endsWith(p.slice(1));
            return entry.name === p;
          });
          if (matches) files.push(fullPath);
        }
      }
    } catch { /* skip inaccessible dirs */ }
  };

  walk(dirPath);
  return files;
}

/**
 * Invoke nightly KG ingest via the {AGENT_NAME} daemon (port 11711).
 *
 * The daemon runs the full adapter lifecycle (hydrate → cleanse → chunk)
 * and ingests episodes via /api/ingest/content. This is the only KG
 * ingestion path — meditate.js no longer has a local fallback.
 *
 * Returns the result object or null if daemon unavailable.
 */
function daemonKgIngest() {
  const tokenPath = path.join(CORTANA_HOME, 'daemon.token');

  if (!fs.existsSync(tokenPath)) {
    return null; // Daemon not running
  }

  const token = fs.readFileSync(tokenPath, 'utf8').trim();
  if (!token) return null;

  try {
    const result = execSync(
      `node -e "const http=require('http');const r=http.request({hostname:'127.0.0.1',port:11711,path:'/api/kg/nightly-ingest',method:'POST',headers:{'Content-Type':'application/json','Authorization':'Bearer ${token}','Content-Length':2},timeout:120000},res=>{let d='';res.on('data',c=>d+=c);res.on('end',()=>{console.log(d);process.exit(0)})});r.on('error',()=>{console.log('null');process.exit(1)});r.write('{}');r.end()"`,
      { encoding: 'utf8', timeout: 130000, windowsHide: true }
    ).trim();
    if (result && result !== 'null') {
      const parsed = JSON.parse(result);
      if (parsed && typeof parsed.ingested === 'number') {
        return parsed;
      }
    }
  } catch {
    // Daemon not available
  }
  return null;
}

/**
 * Generate entity pages from the Knowledge Graph.
 * Calls POST /api/entity_pages on the KG server.
 * Returns { generated, errors } or null on failure.
 */
function kgGenerateEntityPages() {
  try {
    const payload = { output_dir: ENTITIES_DIR, max_entities: 50 };
    return kgHttpRequest('/api/entity_pages', 'POST', payload, 120000);
  } catch (e) {
    return { generated: 0, errors: [e.message || String(e)] };
  }
}

// ============================================================
// KNOWLEDGE GRAPH BACKFILL (first-enable bootstrap)
// ============================================================

const SESSIONS_INDEX = path.join(CORTANA_HOME, 'sessions-index.json');

/**
 * Backfill historical data into the Knowledge Graph on first enable.
 * Sources:
 * 1. Signal buffer — last 7 days of {HOME_DIR}/signals/*.jsonl
 * 2. Session conversations — last 30 days from sessions-index.json
 * 3. External directories — full initial scan (ignoring delta state)
 *
 * Posts all episodes to /api/ingest in batches of 20.
 */
function kgBackfill() {
  // Health check
  if (!kgHealthCheck()) {
    return { ingested: 0, reason: 'KG server not ready' };
  }

  // Local batch key helper (used only by backfill)
  function batchKey(signal, dateStr) {
    const source = signal.source || 'unknown';
    const data = signal.data || {};
    switch (source) {
      case 'email': return `email-${data.threadId || data.conversationId || signal.id}`;
      case 'teams-chat': return `chat-${data.threadId || signal.id}`;
      case 'teams-meetings': return `meeting-${data.eventId || signal.id}`;
      case 'calendar': return `calendar-${dateStr}`;
      case 'teams-activity': return `activity-${data.threadId || dateStr}`;
      default: return `${source}-${dateStr}`;
    }
  }

  // Check if memory bootstrap already fed the KG — skip signal/session sections
  const bootstrapProgressPath = path.join(CORTANA_HOME, 'memory', 'bootstrap-progress.json');
  let bootstrapFedKg = false;
  try {
    if (fs.existsSync(bootstrapProgressPath)) {
      const bp = JSON.parse(fs.readFileSync(bootstrapProgressPath, 'utf8'));
      bootstrapFedKg = bp?.kg?.backfillMarkerWritten === true;
    }
  } catch { /* ignore */ }

  if (bootstrapFedKg) {
    console.log('Memory bootstrap already fed KG. Skipping signal/session backfill, only scanning external dirs.');
  }

  const episodes = [];
  const now = Date.now();
  const SEVEN_DAYS = 7 * 86400000;
  const THIRTY_DAYS = 30 * 86400000;

  // 1. Signal buffer — last 7 days (skip if bootstrap already handled)
  if (!bootstrapFedKg) {
    try {
      if (fs.existsSync(SIGNALS_DIR)) {
        const files = fs.readdirSync(SIGNALS_DIR).filter(f => f.endsWith('.jsonl')).sort();
        for (const file of files) {
          const dateStr = file.replace('.jsonl', '');
          const fileDate = new Date(dateStr).getTime();
          if (isNaN(fileDate) || now - fileDate > SEVEN_DAYS) continue;

          const lines = fs.readFileSync(path.join(SIGNALS_DIR, file), 'utf8').trim().split('\n').filter(Boolean);
          const byBoundary = {};
          for (const line of lines) {
            try {
              const signal = JSON.parse(line);
              const key = batchKey(signal, dateStr);
              if (!byBoundary[key]) byBoundary[key] = [];
              byBoundary[key].push(signal);
            } catch { /* skip */ }
          }

          for (const [key, signals] of Object.entries(byBoundary)) {
            const content = signals.map(s => {
              const ts = s.timestamp ? `[${s.timestamp}] ` : '';
              return `${ts}${s.summary || ''}\n${s.data ? JSON.stringify(s.data) : ''}`;
            }).join('\n---\n');
            const sourceType = key.startsWith('chat-') ? 'message' : 'text';
            episodes.push({
              name: `backfill-signal-${key}-${dateStr}`,
              content: content.slice(0, 50000),
              source_description: `Backfill signal: ${key} (${dateStr})`,
              source_type: sourceType,
              reference_time: new Date(fileDate).toISOString(),
              group_id: 'personal',
            });
          }
        }
      }
    } catch (e) {
      console.warn(`⚠️ Backfill signal scan failed: ${e.message || e}`);
    }

    // 2. Session conversations — last 30 days (skip if bootstrap already handled)
    try {
      if (fs.existsSync(SESSIONS_INDEX)) {
        const index = JSON.parse(fs.readFileSync(SESSIONS_INDEX, 'utf8'));
        const entries = index.entries || [];
        for (const session of entries) {
          const modified = new Date(session.modified || session.fileMtime).getTime();
          if (isNaN(modified) || now - modified > THIRTY_DAYS) continue;
          if (!session.fullPath || !fs.existsSync(session.fullPath)) continue;

          try {
            const content = fs.readFileSync(session.fullPath, 'utf8');
            if (!content.trim()) continue;
            episodes.push({
              name: `backfill-session-${session.sessionId || 'unknown'}`,
              content: content.slice(0, 50000),
              source_description: `Conversation: ${session.firstPrompt || 'untitled'}`,
              source_type: 'text',
              reference_time: new Date(modified).toISOString(),
              group_id: 'personal',
            });
          } catch { /* skip unreadable sessions */ }
        }
      }
    } catch (e) {
      console.warn(`⚠️ Backfill session scan failed: ${e.message || e}`);
    }
  } // end if (!bootstrapFedKg)

  // 3. External directories — full scan
  try {
    if (fs.existsSync(EXTERNAL_DIRS_CONFIG)) {
      const externalDirs = JSON.parse(fs.readFileSync(EXTERNAL_DIRS_CONFIG, 'utf8'));
      const DEFAULT_PATTERNS = ['*.md', '*.txt', '*.markdown'];

      for (const dir of externalDirs) {
        if (dir.enabled === false || !dir.path || !fs.existsSync(dir.path)) continue;
        const patterns = dir.patterns || DEFAULT_PATTERNS;
        const files = findExternalFiles(dir.path, patterns, dir.recursive !== false);

        for (const filePath of files) {
          try {
            const content = fs.readFileSync(filePath, 'utf8');
            if (!content.trim()) continue;
            const stat = fs.statSync(filePath);
            const relPath = path.relative(dir.path, filePath);
            const label = dir.label || path.basename(dir.path);
            episodes.push({
              name: `backfill-ext-${Buffer.from(filePath).toString('base64').slice(0, 16)}`,
              content: content.slice(0, 50000),
              source_description: `External (${label}): ${relPath}`,
              source_type: 'text',
              reference_time: new Date(stat.mtimeMs).toISOString(),
              group_id: 'personal',
            });
          } catch { /* skip */ }
        }
      }
    }
  } catch (e) {
    console.warn(`⚠️ Backfill external dir scan failed: ${e.message || e}`);
  }

  if (episodes.length === 0) {
    return { ingested: 0, reason: 'No historical data to backfill' };
  }

  console.log(`🔄 Backfill: found ${episodes.length} episodes to ingest`);

  // Ingest in batches of 12 (server parallelizes within each batch —
  // each episode triggers LLM extraction via Haiku, ~10s per episode with 3x concurrency)
  const BATCH_SIZE = 12;
  let totalIngested = 0;
  let totalFailed = 0;

  for (let i = 0; i < episodes.length; i += BATCH_SIZE) {
    const batch = episodes.slice(i, i + BATCH_SIZE);
    try {
      const payload = JSON.stringify({ episodes: batch });
      const resp = kgHttpRequest('/api/ingest', 'POST', payload, 300000);
      totalIngested += resp.ingested || 0;
      totalFailed += resp.failed || 0;
      console.log(`  Batch ${Math.floor(i / BATCH_SIZE) + 1}: ${resp.ingested || 0} ingested`);
    } catch (e) {
      totalFailed += batch.length;
      console.warn(`  Batch ${Math.floor(i / BATCH_SIZE) + 1} failed: ${e.message || e}`);
    }
  }

  return { ingested: totalIngested, failed: totalFailed, total: episodes.length };
}

// ============================================================
// MAIN
// ============================================================
function main() {
  const args = process.argv.slice(2);
  const dryRun = args.includes('--dry-run');
  const isJson = args.includes('--json');
  const phaseIdx = args.indexOf('--phase');
  const singlePhase = phaseIdx !== -1 ? args[phaseIdx + 1] : null;

  // Phase: Backfill (standalone, triggered by knowledgeGraphServer.ts on first enable)
  if (singlePhase === 'backfill') {
    try {
      const result = kgBackfill();
      if (result.ingested > 0) {
        console.log(`🔄 Backfill complete: ${result.ingested} episode(s) ingested`);
      } else {
        console.log(`🔄 Backfill: ${result.reason || 'nothing to ingest'}`);
      }
      if (isJson) {
        console.log(JSON.stringify({ backfill: result }, null, 2));
      }
    } catch (e) {
      console.warn(`⚠️ Backfill failed: ${e.message || e}`);
    }
    return;
  }

  // Phase 0: Pre-meditation baseline snapshot (rollback safety net)
  if (!dryRun && !singlePhase) {
    try {
      const backupScript = path.join(__dirname, '..', '..', 'state-backup', 'scripts', 'backup.js');
      if (fs.existsSync(backupScript)) {
        const result = execSync(`node "${backupScript}" snapshot`, { encoding: 'utf8', timeout: 15000 });
        const changed = result.match(/(\d+) changed file/);
        if (changed) {
          console.log(`📸 Pre-meditation baseline: ${changed[1]} file(s) snapshotted\n`);
        }
      }
    } catch (e) {
      console.warn(`⚠️ Pre-meditation backup failed (continuing): ${e.message || e}\n`);
    }
  }

  // Phase 1: Diagnose
  const diagnosis = (!singlePhase || singlePhase === 'diagnose') ? diagnose() : { healthScore: null, findings: [] };

  // Phase 1b: Self-Heal (runs after diagnose, before reflect)
  const selfHealing = (!singlePhase || singlePhase === 'self-heal') ? selfHeal(dryRun) : null;

  // Phase 2: Reflect
  const reflection = (!singlePhase || singlePhase === 'reflect') ? reflect() : { insights: [] };

  // Phase 3: Memory Hygiene
  const hygiene = (!singlePhase || singlePhase === 'hygiene') ? memoryHygiene(dryRun) : { issues: [], archiveActions: [] };

  // Phase 3b: Memory Triage (route extracted JSONL entries to topic files)
  const triage = (!singlePhase || singlePhase === 'triage') ? memoryTriage(dryRun) : { triaged: 0, skipped: 0, failed: 0 };

  // Rebuild MEMORY.md index if any entries were triaged into topic files
  if (!dryRun && triage.triaged > 0) {
    rebuildMemoryIndex();
  }

  // Phase 4: Propose
  const actions = (!singlePhase || singlePhase === 'propose') ? propose(diagnosis, reflection, hygiene) : [];

  // Phase 5: Act + Write Deep Instincts + Track Proposals + Log
  const actionResults = act(actions, dryRun);

  // Write deep insights to INSTINCT.md (always called — clears marker when no insights)
  if (!singlePhase || singlePhase === 'reflect') {
    writeDeepInstincts(reflection.deepInsights || [], dryRun);
  }

  // Track proposal repetition and escalation
  if (!singlePhase || singlePhase === 'propose') {
    trackProposals(actionResults.filter(a => a.status === 'queued-for-review'), dryRun);
  }

  const logEntry = logMeditation(diagnosis, reflection, hygiene, triage, actionResults, selfHealing, dryRun);

  // Phase 6: Knowledge Graph nightly ingestion
  // Handled by the TS daemon's scheduled task (__kg-nightly-ingest).
  // meditate.js only calls the daemon endpoint — no local fallback.
  let kgResult = null;
  if (!dryRun && (!singlePhase || singlePhase === 'kg-ingest')) {
    try {
      kgResult = daemonKgIngest();
      if (kgResult) {
        if (kgResult.ingested > 0) {
          console.log(`🧠 KG Ingestion: ${kgResult.ingested} episode(s) ingested, ${kgResult.failed || 0} failed, ${kgResult.skipped || 0} skipped`);
        } else if (kgResult.reason) {
          console.log(`🧠 KG Ingestion skipped: ${kgResult.reason}`);
        }
      } else {
        console.log('🧠 KG Ingestion skipped: daemon not available (KG ingest requires the daemon)');
      }
    } catch (e) {
      console.warn(`⚠️ KG ingestion failed (non-fatal): ${e.message || e}`);
    }
  }

  // Phase 7: Entity page generation
  let entityResult = null;
  if (!dryRun && (!singlePhase || singlePhase === 'entity-pages') && kgResult && kgResult.ingested > 0) {
    try {
      entityResult = kgGenerateEntityPages();
      if (entityResult.generated > 0) {
        console.log(`📄 Entity Pages: ${entityResult.generated} page(s) generated`);
      }
    } catch (e) {
      console.warn(`⚠️ Entity page generation failed (non-fatal): ${e.message || e}`);
    }
  }

  // Phase 5b: Snapshot state after meditation (backup all state files)
  if (!dryRun && !singlePhase) {
    try {
      const backupScript = path.join(__dirname, '..', '..', 'state-backup', 'scripts', 'backup.js');
      if (fs.existsSync(backupScript)) {
        const result = execSync(`node "${backupScript}" snapshot`, { encoding: 'utf8', timeout: 15000 });
        const changed = result.match(/(\d+) changed file/);
        if (changed) {
          console.log(`\n📸 Post-meditation snapshot: ${changed[1]} file(s) backed up`);
        } else if (result.includes('No changes')) {
          console.log(`\n📸 Post-meditation snapshot: no changes`);
        }
      }
    } catch (e) {
      console.warn(`⚠️ State backup failed: ${e.message || e}`);
    }
  }

  if (isJson) {
    console.log(JSON.stringify({ diagnosis, reflection, hygiene, triage, selfHealing, actions: actionResults, kgIngestion: kgResult, entityPages: entityResult }, null, 2));
  } else {
    console.log(logEntry);
  }
}

main();
