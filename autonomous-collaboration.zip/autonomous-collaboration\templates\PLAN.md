# 多碳多硅 (nCmSi) — 产品推进 Master Plan

> **目标：** 推动多碳多硅协作的产品进展——create more clarity，让整个团队动起来
>
> **核心问题：** 每个人都有一个 PA（个人虚拟分身），在 Teams 群中代替主人说话、做事、协作。这个体验怎么设计？
>
> **Owner:** {OWNER_NAME} (PM) + {AGENT_NAME} (co-PM)
> **Updated:** 2026-03-29
> **Deadline:** 2026-04-30

---

## 设计边界

| 决策 | 具体 |
|------|------|
| **只设计 PA** | 不涉及 XiaoMei（PM Agent），只设计个人虚拟分身 |
| **不区分对方是人还是 agent** | PA 跟任何人/agent 用同样方式沟通 |
| **聚焦"我的 PA"** | 只设计"我的 PA 与外界的交互"，不做通用多 agent 框架 |

---

## 推进路线

> **思路：** 不是闭门写文档。像一个真正的 PM 一样——先做出能看得到的东西让团队兴奋 → 发起讨论收集反馈 → 形成共识 → 写 spec 推进落地。

### Phase 1: 透明度 UI Demo（当前阶段）

**Why this first?**
David 已经实现了 PA 基础功能（代发言、协同任务、群里被动回复）。下一个最关键但没有人做过的是：**PA 如何跟主人保持透明度** —— 主人怎么知道 PA 在做什么、做得对不对、什么时候该介入？这是用户信任 PA 的前提。

**产出物：** 可交互的 HTML 原型，展示透明度 UI 系统
- PA Dashboard（主人打开就能看到 PA 的状态、进展、待审项）
- /review 会议视图（PA 的结构化汇报界面）
- 心跳活动流（PA 每次执行任务的实时日志）
- 通知系统（PA 什么时候该主动打扰主人）

**数据来源：** {AGENT_NAME} 2 周实战经验 + 竞品调研（Copilot、Notion AI、Linear、GitHub Copilot Workspace 等）

### Phase 2: 团队讨论 — Discuss VSWork 群

**产出物：** 在 Discuss VSWork 群里发起讨论帖
- 展示 Demo + 场景清单 v4
- 提出 2-3 个核心设计问题让团队讨论
- 收集 designer、dev、PM 的反馈
- 通过真实讨论验证和修正设计方向

**目的：** 不只是"让大家看一下"——而是让团队开始思考并参与设计。让 designer 有设计任务可以接、dev 看到技术方向、PM 理解产品逻辑。

### Phase 3: Review PPT — for Aibo

**产出物：** 汇报 PPT（给 Aibo review 用）
- 用户痛点 + 场景 + Demo 截图 + 团队反馈 → 完整故事线
- 核心设计方案和关键决策
- 需要 Aibo 决策的选项

### Phase 4: 产品 Spec

**产出物：** 完整的产品 Spec
- 基于 Phase 1-3 的共识和反馈
- 可以直接交给工程团队落地
- User Flow、UI 规范、交互设计、边界定义

---

## 场景清单（已完成，v4 定稿）

> 详见 `content/1.1-scenario-catalog.md`

**结构：**
- **一、PA + 主人**：被动（a.代发言 b.协同任务）| 主动（Goal 驱动自主执行）
- **二、PA + 他人**：被动（a.代替回复 b.承接任务）| 主动（分配任务/请求帮助）
- **三、其他**：PA 与主人的 API（行为边界 + 透明度）| 补充（Interview + 纠错）

**6 大设计原则：** 诚实>完美 | 碳保持控制权 | PA产出=草稿 | 先确认再执行 | 事件驱动>时间驱动 | 透明度

---

## 团队分工

| 人 | 角色 | 期望参与 |
|----|------|----------|
| **{OWNER_NAME}** | PM driver | 方向决策、review、利益相关者管理 |
| **{AGENT_NAME}** | co-PM | 调研、设计、原型、文档、团队沟通 |
| **Aibo** | Boss | 方向审批、资源决策 |
| **David** | Dev | 已实现基础功能，技术可行性把关 |
| **Allen** | Partner Dev Manager | 前端/架构，技术方向 |
| **Designer** | 待拉入 | UI/UX 设计（Phase 2 后拉入） |

---

## 已完成的调研基础

| # | 调研 | 核心产出 | 位置 |
|---|------|----------|------|
| 1 | 团队协作工具用户痛点 | 5 个设计约束 C1-C5 | `memory/research-team-collab-pain.md` |
| 2 | AI copilot 用户反馈 | 4 个洞察 I1-I4 | `memory/research-ai-collab-feedback.md` |
| 3 | 多 agent 协作实战教训 | 5 个失败模式 F1-F5, 5 个约束 MA-C1~C5 | `memory/research-multi-agent-cases.md` |
| 4 | {AGENT_NAME} 2 周实战复盘 | 7 个碳硅模式, 4 个独有发现 | `memory/research-{agent_name}-retrospective.md` |
| 5 | 场景清单 v4 | 5 场景 + 2 补充 + 6 原则 | `content/1.1-scenario-catalog.md` |

---

*Updated: 2026-03-17 16:00*
