#!/usr/bin/env python3
"""
Autonomous Collaboration Skill — One-click Setup

Replaces the 5-step manual install. Run:
    python scripts/init.py --agent-name MyAgent --owner-name Alice --home ~/.myagent

This script:
1. Creates the agent home directory structure
2. Copies and configures all behavior files
3. Installs 9 skills to teams-tasks/.claude/skills/
4. Installs heartbeat runner scripts
5. Generates TODO.md and people.md
6. Prints the CLAUDE.md snippet to paste
"""

import argparse
import os
import shutil
import sys

SKILL_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def replace_in_file(filepath, replacements):
    """Read a file, apply all replacements, write back."""
    with open(filepath, "r", encoding="utf-8") as f:
        content = f.read()
    for old, new in replacements:
        content = content.replace(old, new)
    with open(filepath, "w", encoding="utf-8") as f:
        f.write(content)
    return content


def main():
    parser = argparse.ArgumentParser(description="Initialize autonomous collaboration for an AI agent")
    parser.add_argument("--agent-name", required=True, help="Agent name (e.g. XiaoMei)")
    parser.add_argument("--owner-name", required=True, help="Owner/user name (e.g. Alice)")
    parser.add_argument("--home", required=True, help="Agent home directory (e.g. ~/.myagent)")
    parser.add_argument("--dry-run", action="store_true", help="Show what would be done without writing files")
    args = parser.parse_args()

    agent_name = args.agent_name
    owner_name = args.owner_name
    home = os.path.expanduser(args.home)
    dry = args.dry_run

    people_file = os.path.join(home, "people.md")
    todo_file = os.path.join(home, "TODO.md")
    skills_dst = os.path.join(home, "teams-tasks", ".claude", "skills")

    # Standard placeholder replacements
    replacements = [
        ("{AGENT_NAME}", agent_name),
        ("{OWNER_NAME}", owner_name),
        ("{OWNER_FULL_NAME}", owner_name),
        ("{OWNER_ALIAS}", owner_name.lower().replace(" ", "")),
        ("{PEOPLE_FILE}", people_file),
        ("{TODO_FILE}", todo_file),
        ("{HOME_DIR}", home),
        ("{AGENT_HOME}", home),
        ("{agent_name}", agent_name.lower().replace(" ", "")),
    ]

    # ── 1. Create directories ──────────────────────────────────
    dirs = [
        home,
        os.path.join(home, "heartbeat-logs"),
        os.path.join(home, "goal-logs"),
        os.path.join(home, "memory"),
        os.path.join(home, "memory", "topics"),
        skills_dst,
    ]
    for d in dirs:
        if dry:
            print(f"  [dry] mkdir {d}")
        else:
            os.makedirs(d, exist_ok=True)
    print(f"✓ Created directory structure at {home}")

    # ── 2. Copy & configure behavior files ─────────────────────
    refs_dir = os.path.join(SKILL_DIR, "references")
    assets_dir = os.path.join(SKILL_DIR, "assets")
    scripts_dir = os.path.join(SKILL_DIR, "scripts")

    behavior_files = [
        ("references/collaboration.md", "COLLABORATION.md"),
        ("references/instincts.md", "INSTINCT.md"),
        ("references/thinking-auditor.md", "thinking-auditor.md"),
    ]
    for src_rel, dst_name in behavior_files:
        src = os.path.join(SKILL_DIR, src_rel)
        dst = os.path.join(home, dst_name)
        if dry:
            print(f"  [dry] {src_rel} → {dst_name}")
            continue
        shutil.copy2(src, dst)
        replace_in_file(dst, replacements)
        print(f"✓ {dst_name}")

    # ── 3. Templates → configured files ────────────────────────
    template_files = [
        ("assets/people.md.template", people_file),
        ("assets/todo.md.template", todo_file),
    ]
    for src_rel, dst in template_files:
        src = os.path.join(SKILL_DIR, src_rel)
        name = os.path.basename(dst)
        if dry:
            print(f"  [dry] {src_rel} → {name}")
            continue
        shutil.copy2(src, dst)
        replace_in_file(dst, replacements)
        print(f"✓ {name}")

    # ── 4. Copy additional templates (PLAN, GUARDRAILS) ────────
    templates_dir = os.path.join(SKILL_DIR, "templates")
    if os.path.isdir(templates_dir):
        for fname in os.listdir(templates_dir):
            if fname in ("people.md", "TODO.md"):
                continue  # already handled above
            src = os.path.join(templates_dir, fname)
            dst = os.path.join(home, fname)
            if dry:
                print(f"  [dry] templates/{fname} → {home}/{fname}")
                continue
            shutil.copy2(src, dst)
            replace_in_file(dst, replacements)
            print(f"✓ {fname}")

    # ── 5. Install execution scripts ───────────────────────────
    script_files = [
        ("scripts/heartbeat_scheduler.py", os.path.join(home, "heartbeat_scheduler.py")),
        ("scripts/goal_engine.js", os.path.join(home, "goal_engine.js")),
    ]
    for src_rel, dst in script_files:
        src = os.path.join(SKILL_DIR, src_rel)
        name = os.path.basename(dst)
        if dry:
            print(f"  [dry] {src_rel} → {name}")
            continue
        shutil.copy2(src, dst)
        # Extra config patching for heartbeat_scheduler
        r = replacements + [
            ('AGENT_NAME = "{AGENT_NAME}"', f'AGENT_NAME = "{agent_name}"'),
            ('OWNER_NAME = "{OWNER_NAME}"', f'OWNER_NAME = "{owner_name}"'),
            ('TODO_FILE = "{TODO_FILE}"', f'TODO_FILE = "{todo_file}"'),
            ('STATE_DIR = "{STATE_DIR}"', f'STATE_DIR = "{os.path.join(home, "heartbeat-logs")}"'),
        ]
        replace_in_file(dst, r)
        print(f"✓ {name}")

    # ── 6. Install 9 skills ────────────────────────────────────
    skills_src = os.path.join(SKILL_DIR, "skills")
    installed_skills = []
    if os.path.isdir(skills_src):
        for skill_name in sorted(os.listdir(skills_src)):
            skill_src_dir = os.path.join(skills_src, skill_name)
            if not os.path.isdir(skill_src_dir):
                continue
            skill_dst_dir = os.path.join(skills_dst, skill_name)
            if dry:
                print(f"  [dry] skills/{skill_name}/ → {skill_dst_dir}/")
                installed_skills.append(skill_name)
                continue
            if os.path.exists(skill_dst_dir):
                shutil.rmtree(skill_dst_dir)
            shutil.copytree(skill_src_dir, skill_dst_dir)
            # Templatize all text files in the skill
            for root, dirs, files in os.walk(skill_dst_dir):
                for fname in files:
                    if fname.endswith(('.md', '.py', '.js', '.mjs', '.html', '.bat', '.ps1')):
                        try:
                            replace_in_file(os.path.join(root, fname), replacements)
                        except (UnicodeDecodeError, PermissionError):
                            pass
            installed_skills.append(skill_name)
            print(f"✓ skill: {skill_name}")

    # ── 7. Install setup scripts (heartbeat runner) ────────────
    setup_src = os.path.join(SKILL_DIR, "setup")
    if os.path.isdir(setup_src):
        setup_dst = os.path.join(home, "setup")
        if not dry:
            os.makedirs(setup_dst, exist_ok=True)
        for fname in os.listdir(setup_src):
            src = os.path.join(setup_src, fname)
            dst = os.path.join(setup_dst, fname)
            if dry:
                print(f"  [dry] setup/{fname} → setup/{fname}")
                continue
            shutil.copy2(src, dst)
            replace_in_file(dst, replacements)
            print(f"✓ setup/{fname}")

    # ── 8. Install npm dependencies if needed ──────────────────
    task_sched_dir = os.path.join(skills_dst, "task-scheduler", "scripts")
    pkg_json = os.path.join(task_sched_dir, "package.json")
    if os.path.exists(pkg_json) and not dry:
        print("\n📦 Installing task-scheduler npm dependencies...")
        import subprocess
        result = subprocess.run(["npm", "install"], cwd=task_sched_dir, capture_output=True, text=True)
        if result.returncode == 0:
            print("✓ npm install complete")
        else:
            print(f"⚠ npm install failed (non-critical): {result.stderr[:200]}")

    # ── 9. Print summary & CLAUDE.md snippet ───────────────────
    sched_dst = os.path.join(home, "heartbeat_scheduler.py")
    ge_dst = os.path.join(home, "goal_engine.js")

    print(f"""
{'='*60}
  ✅ Setup complete!

  Home:   {home}
  Skills: {len(installed_skills)} installed → {skills_dst}
  Files:  COLLABORATION.md, INSTINCT.md, thinking-auditor.md,
          TODO.md, people.md, PLAN.md, OUTWARD_GUARDRAILS.md
{'='*60}

  Add this to your CLAUDE.md:

{'─'*60}
## Autonomous Collaboration

I follow these behavior specs:
- [{home}/COLLABORATION.md]({home}/COLLABORATION.md) — 7 collaboration modules
- [{home}/INSTINCT.md]({home}/INSTINCT.md) — 9 auto-trigger instincts (I1-I9)

Before major decisions, run the 6-step thinking audit in [{home}/thinking-auditor.md]({home}/thinking-auditor.md).

### Task Management
- TODO file: `{todo_file}`
- People knowledge: `{people_file}`

### Heartbeat
`python {sched_dst} start` — auto-reads TODO.md, executes tasks back-to-back
`python {sched_dst} stop` — stop heartbeat

### Goals
`node {ge_dst} list` — list active goals
`node {ge_dst} create --name "..." --deadline "..." --project "..."`

### Skills (auto-installed at {skills_dst})
{chr(10).join(f"- {s}" for s in installed_skills)}
{'─'*60}

⚠️  Dependencies: Python 3.8+, Node.js 16+, pip install markdown
{'='*60}
""")


if __name__ == "__main__":
    main()
