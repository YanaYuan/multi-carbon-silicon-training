#!/usr/bin/env node
/**
 * State Backup — Git-based version control for {AGENT_NAME} state files.
 *
 * Commands:
 *   snapshot  — Copy state files + git commit with timestamp
 *   log       — Show recent commit history
 *   diff      — Show changes since last snapshot
 *   restore   — Restore a file from a past snapshot
 *   stats     — Show file sizes and growth
 *   init      — Initialize the backup repo (auto-run on first snapshot)
 */

const fs = require('fs');
const path = require('path');
const os = require('os');
const { execSync } = require('child_process');

// --- Config ---
const CORTANA_HOME = path.join(os.homedir(), '.{agent_name}');
const SNAPSHOT_DIR = path.join(CORTANA_HOME, 'state-snapshots');
const TEAMS_TASKS = path.join(CORTANA_HOME, 'teams-tasks');

/**
 * Files to track. Paths relative to CORTANA_HOME.
 * Format: { source: absolute path, snapshotName: filename in snapshot dir }
 */
const MEMORY_DIR = path.join(CORTANA_HOME, 'memory');
const SIGNALS_DIR = path.join(CORTANA_HOME, 'signals');

/**
 * Static files — always tracked individually.
 */
const TRACKED_FILES = [
  // Core identity & config
  { source: path.join(CORTANA_HOME, 'MEMORY.md'), name: 'MEMORY.md' },
  { source: path.join(CORTANA_HOME, 'INSTINCT.md'), name: 'INSTINCT.md' },
  { source: path.join(TEAMS_TASKS, 'SOUL.md'), name: 'SOUL.md' },

  // Proactive pipeline state
  { source: path.join(CORTANA_HOME, 'action-queue.json'), name: 'action-queue.json' },
  { source: path.join(CORTANA_HOME, 'proposal-outcomes.jsonl'), name: 'proposal-outcomes.jsonl' },
  { source: path.join(TEAMS_TASKS, 'scheduled-tasks.json'), name: 'scheduled-tasks.json' },
  { source: path.join(TEAMS_TASKS, 'monitors.json'), name: 'monitors.json' },
  { source: path.join(CORTANA_HOME, 'meditation-log.md'), name: 'meditation-log.md' },

  // Watermarks & cursors (small but critical — losing these causes reprocessing storms)
  { source: path.join(CORTANA_HOME, 'proactive-chat-watermarks.json'), name: 'watermarks/proactive-chat.json' },
  { source: path.join(CORTANA_HOME, 'seen-signals.json'), name: 'watermarks/seen-signals.json' },
  { source: path.join(SIGNALS_DIR, 'dedup-state.json'), name: 'watermarks/signal-dedup.json' },
  { source: path.join(SIGNALS_DIR, 'trigger-watermarks.json'), name: 'watermarks/signal-triggers.json' },
  { source: path.join(CORTANA_HOME, 'meeting-monitor-state.json'), name: 'watermarks/meeting-monitor.json' },

  // Memory extraction metadata (NOT the Orama DB — that's regenerable)
  { source: path.join(MEMORY_DIR, 'extraction-audit.jsonl'), name: 'memory/extraction-audit.jsonl' },
  { source: path.join(MEMORY_DIR, 'indexed_files.json'), name: 'memory/indexed_files.json' },
  { source: path.join(MEMORY_DIR, 'bootstrap-progress.json'), name: 'memory/bootstrap-progress.json' },
  { source: path.join(MEMORY_DIR, 'memory_meta.json'), name: 'memory/memory_meta.json' },

  // Session index (growing — tracks all conversation metadata)
  { source: path.join(CORTANA_HOME, 'sessions-index.json'), name: 'sessions-index.json' },
];

/**
 * Glob-based tracked directories — all .jsonl files in these dirs get snapshotted.
 * These are extracted memories from emails/Teams/meetings — irreplaceable context.
 */
const TRACKED_DIRS = [
  { sourceDir: path.join(MEMORY_DIR, 'extracted'), snapshotSubdir: 'memory/extracted', pattern: /\.jsonl$/ },
  { sourceDir: path.join(MEMORY_DIR, 'onenote'), snapshotSubdir: 'memory/onenote', pattern: /\.(md|json)$/ },
];

// --- Helpers ---
function git(args, opts = {}) {
  const cwd = opts.cwd || SNAPSHOT_DIR;
  try {
    return execSync(`git ${args}`, { cwd, encoding: 'utf8', timeout: 10000 }).trim();
  } catch (err) {
    if (opts.silent) return '';
    throw err;
  }
}

function fileSize(filePath) {
  try {
    return fs.statSync(filePath).size;
  } catch {
    return 0;
  }
}

function formatBytes(bytes) {
  if (bytes < 1024) return `${bytes}B`;
  if (bytes < 1048576) return `${(bytes / 1024).toFixed(1)}KB`;
  return `${(bytes / 1048576).toFixed(1)}MB`;
}

// --- Commands ---

function init() {
  if (!fs.existsSync(SNAPSHOT_DIR)) {
    fs.mkdirSync(SNAPSHOT_DIR, { recursive: true });
  }

  if (!fs.existsSync(path.join(SNAPSHOT_DIR, '.git'))) {
    git('init', { cwd: SNAPSHOT_DIR });
    // Configure git for this repo
    git('config user.name "{AGENT_NAME}"');
    git('config user.email "{agent_name}@local"');
    // Create .gitignore
    fs.writeFileSync(path.join(SNAPSHOT_DIR, '.gitignore'), '*.tmp\n', 'utf8');
    git('add .gitignore');
    git('commit -m "init: state backup repo"');
    console.log('✅ Initialized state backup repo at', SNAPSHOT_DIR);
    return true;
  }
  return false;
}

function snapshot() {
  init(); // Ensure repo exists

  let copied = 0;
  let skipped = 0;
  const changes = [];

  // 1. Copy static tracked files
  for (const f of TRACKED_FILES) {
    const dest = path.join(SNAPSHOT_DIR, f.name);
    const destDir = path.dirname(dest);
    if (!fs.existsSync(destDir)) fs.mkdirSync(destDir, { recursive: true });

    if (fs.existsSync(f.source)) {
      fs.copyFileSync(f.source, dest);
      copied++;
    } else {
      skipped++;
    }
  }

  // 2. Copy tracked directories (glob-based)
  for (const d of TRACKED_DIRS) {
    if (!fs.existsSync(d.sourceDir)) continue;
    const destDir = path.join(SNAPSHOT_DIR, d.snapshotSubdir);
    if (!fs.existsSync(destDir)) fs.mkdirSync(destDir, { recursive: true });

    const files = fs.readdirSync(d.sourceDir).filter(f => d.pattern.test(f));
    for (const file of files) {
      fs.copyFileSync(path.join(d.sourceDir, file), path.join(destDir, file));
      copied++;
    }
  }

  // 3. Detect what actually changed
  const status = git('status --porcelain', { silent: true });
  if (!status) {
    console.log('✨ No changes since last snapshot');
    return { copied, skipped, changes: [] };
  }

  for (const line of status.split('\n').filter(Boolean)) {
    const filename = line.substring(3).trim().replace(/"/g, '');
    changes.push(filename);
  }

  // Stage and commit
  git('add -A');
  const now = new Date();
  const timestamp = now.toISOString().replace('T', ' ').substring(0, 19);
  const msg = `snapshot ${timestamp} — ${changes.length} file(s)`;
  git(`commit -m "${msg}"`);

  console.log(`✅ Snapshot saved: ${changes.length} changed file(s)`);
  for (const c of changes) {
    const size = formatBytes(fileSize(path.join(SNAPSHOT_DIR, c)));
    console.log(`   📄 ${c} (${size})`);
  }

  return { copied, skipped, changes };
}

function log(limit = 20) {
  init();
  const output = git(`log --oneline -${limit} --format="%h %s"`, { silent: true });
  if (!output) {
    console.log('No snapshots yet');
    return;
  }
  console.log('# State Backup History\n');
  console.log('| Hash | Description |');
  console.log('|------|-------------|');
  for (const line of output.split('\n')) {
    const [hash, ...rest] = line.split(' ');
    console.log(`| \`${hash}\` | ${rest.join(' ')} |`);
  }
}

function diff() {
  init();
  // Copy current state to snapshot dir first (without committing)
  for (const f of TRACKED_FILES) {
    const dest = path.join(SNAPSHOT_DIR, f.name);
    const destDir = path.dirname(dest);
    if (!fs.existsSync(destDir)) fs.mkdirSync(destDir, { recursive: true });
    if (fs.existsSync(f.source)) {
      fs.copyFileSync(f.source, dest);
    }
  }
  for (const d of TRACKED_DIRS) {
    if (!fs.existsSync(d.sourceDir)) continue;
    const destDir = path.join(SNAPSHOT_DIR, d.snapshotSubdir);
    if (!fs.existsSync(destDir)) fs.mkdirSync(destDir, { recursive: true });
    const files = fs.readdirSync(d.sourceDir).filter(f => d.pattern.test(f));
    for (const file of files) {
      fs.copyFileSync(path.join(d.sourceDir, file), path.join(destDir, file));
    }
  }

  const output = git('diff --stat', { silent: true });
  if (!output) {
    console.log('✨ No changes since last snapshot');
    return;
  }

  console.log('# Changes Since Last Snapshot\n');
  console.log('```');
  console.log(output);
  console.log('```');

  // Show content diff for .md files only (most readable)
  for (const f of TRACKED_FILES) {
    if (f.name.endsWith('.md')) {
      const fileDiff = git(`diff "${f.name}"`, { silent: true });
      if (fileDiff) {
        console.log(`\n## ${f.name}\n`);
        // Show only added/removed lines, limit output
        const lines = fileDiff.split('\n').filter(l => l.startsWith('+') || l.startsWith('-'));
        const trimmed = lines.slice(0, 30);
        console.log('```diff');
        console.log(trimmed.join('\n'));
        if (lines.length > 30) console.log(`... (${lines.length - 30} more lines)`);
        console.log('```');
      }
    }
  }

  // Reset the working tree (don't leave uncommitted copies)
  git('checkout -- .', { silent: true });
}

function restore(commitHash, filename) {
  if (!commitHash || !filename) {
    console.error('Usage: node backup.js restore <commit-hash> <filename>');
    console.error('Example: node backup.js restore abc1234 MEMORY.md');
    console.error('Example: node backup.js restore abc1234 memory/extracted/2026-02-05.jsonl');
    process.exit(1);
  }

  init();

  // Find matching tracked file or dir file
  const tracked = TRACKED_FILES.find(f => f.name === filename);
  let sourcePath;
  if (tracked) {
    sourcePath = tracked.source;
  } else {
    // Check if it's inside a tracked dir
    for (const d of TRACKED_DIRS) {
      if (filename.startsWith(d.snapshotSubdir + '/')) {
        const basename = path.basename(filename);
        sourcePath = path.join(d.sourceDir, basename);
        break;
      }
    }
  }
  if (!sourcePath) {
    console.error(`Unknown file: ${filename}`);
    console.error(`Tracked files: ${TRACKED_FILES.map(f => f.name).join(', ')}`);
    console.error(`Tracked dirs: ${TRACKED_DIRS.map(d => d.snapshotSubdir + '/').join(', ')}`);
    process.exit(1);
  }

  // Get the file content at that commit
  let content;
  try {
    content = git(`show ${commitHash}:${filename}`);
  } catch {
    console.error(`Could not find ${filename} at commit ${commitHash}`);
    process.exit(1);
  }

  // Show what would change
  const current = fs.existsSync(sourcePath)
    ? fs.readFileSync(sourcePath, 'utf8')
    : '(file does not exist)';

  const currentLines = current.split('\n').length;
  const restoreLines = content.split('\n').length;

  console.log(`# Restore Preview\n`);
  console.log(`- **File:** ${filename}`);
  console.log(`- **From commit:** ${commitHash}`);
  console.log(`- **Current:** ${currentLines} lines, ${formatBytes(Buffer.byteLength(current, 'utf8'))}`);
  console.log(`- **Restore to:** ${restoreLines} lines, ${formatBytes(Buffer.byteLength(content, 'utf8'))}`);
  console.log(`\n⚠️ To apply: write the restored content to \`${sourcePath}\``);

  // Write to a .restore file for the agent to review
  const restorePath = sourcePath + '.restore';
  fs.writeFileSync(restorePath, content, 'utf8');
  console.log(`\n📄 Restored version saved to: ${restorePath}`);
  console.log(`Review it, then rename to replace the current file.`);
}

function stats() {
  init();

  console.log('# State File Stats\n');
  console.log('| File | Live Size | Snapshot Size | Exists |');
  console.log('|------|-----------|---------------|--------|');

  let totalLive = 0;
  let totalSnapshot = 0;

  for (const f of TRACKED_FILES) {
    const liveSize = fileSize(f.source);
    const snapSize = fileSize(path.join(SNAPSHOT_DIR, f.name));
    totalLive += liveSize;
    totalSnapshot += snapSize;
    const exists = fs.existsSync(f.source) ? '✅' : '❌';
    console.log(`| ${f.name} | ${formatBytes(liveSize)} | ${formatBytes(snapSize)} | ${exists} |`);
  }

  // Tracked directories
  for (const d of TRACKED_DIRS) {
    let dirLive = 0;
    let dirSnap = 0;
    let fileCount = 0;
    if (fs.existsSync(d.sourceDir)) {
      const files = fs.readdirSync(d.sourceDir).filter(f => d.pattern.test(f));
      fileCount = files.length;
      for (const f of files) {
        dirLive += fileSize(path.join(d.sourceDir, f));
        dirSnap += fileSize(path.join(SNAPSHOT_DIR, d.snapshotSubdir, f));
      }
    }
    totalLive += dirLive;
    totalSnapshot += dirSnap;
    const exists = fileCount > 0 ? `✅ (${fileCount})` : '❌';
    console.log(`| ${d.snapshotSubdir}/ | ${formatBytes(dirLive)} | ${formatBytes(dirSnap)} | ${exists} |`);
  }

  console.log(`| **Total** | **${formatBytes(totalLive)}** | **${formatBytes(totalSnapshot)}** | |`);

  // Git repo stats
  const commitCount = git('rev-list --count HEAD', { silent: true }) || '0';
  const repoSize = formatBytes(fileSize(path.join(SNAPSHOT_DIR, '.git')));
  console.log(`\n- **Snapshots:** ${commitCount} commits`);
  console.log(`- **Repo size:** ${repoSize}`);
}

// --- Main ---
function main() {
  const [command, ...args] = process.argv.slice(2);

  switch (command) {
    case 'snapshot':
      snapshot();
      break;
    case 'log':
      log(parseInt(args[0]) || 20);
      break;
    case 'diff':
      diff();
      break;
    case 'restore':
      restore(args[0], args[1]);
      break;
    case 'stats':
      stats();
      break;
    case 'init':
      init();
      break;
    default:
      console.log('Usage: node backup.js <command>');
      console.log('');
      console.log('Commands:');
      console.log('  snapshot  — Save current state (git commit)');
      console.log('  log       — Show snapshot history');
      console.log('  diff      — Show changes since last snapshot');
      console.log('  restore   — Restore file from past snapshot');
      console.log('  stats     — Show file sizes and growth');
      console.log('  init      — Initialize backup repo');
  }
}

main();
