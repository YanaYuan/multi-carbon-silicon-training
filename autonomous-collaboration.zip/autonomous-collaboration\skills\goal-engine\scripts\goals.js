#!/usr/bin/env node
/**
 * Goal Engine CLI — Manage goals in {HOME_DIR}/goals.json
 *
 * Commands:
 *   create --name "..." --description "..." --metric "..." --deadline "YYYY-MM-DD" --project "..." [--schedule "cron"]
 *   list
 *   show <goalId>
 *   pause <goalId>
 *   resume <goalId>
 *   complete <goalId>
 *   log <goalId> --task "..." --tier "G|Y|R" --outcome "..." [--audit-rating "green|yellow|red"]
 *   update-stats <goalId> --field <field> --value <value>
 *   add-decision <goalId> --decision "..." --rationale "..."
 */

const fs = require('fs');
const path = require('path');
const os = require('os');

// Paths
const GOALS_FILE = path.join(os.homedir(), '.{agent_name}', 'goals.json');
const LOGS_DIR = path.join(os.homedir(), '.{agent_name}', 'goal-logs');

// --- State management ---

function loadStore() {
  try {
    const data = fs.readFileSync(GOALS_FILE, 'utf-8');
    return JSON.parse(data);
  } catch (e) {
    return { version: 1, goals: [] };
  }
}

function saveStore(store) {
  const dir = path.dirname(GOALS_FILE);
  fs.mkdirSync(dir, { recursive: true });
  const tmp = GOALS_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(store, null, 2), 'utf-8');
  fs.renameSync(tmp, GOALS_FILE);
}

function generateId() {
  const ts = Date.now();
  const hex = Math.random().toString(16).slice(2, 6);
  return `goal-${ts}-${hex}`;
}

function findGoal(store, goalId) {
  return store.goals.find(g => g.id === goalId);
}

function out(obj) {
  console.log(JSON.stringify(obj, null, 2));
}

// --- Argument parsing ---

function parseArgs(args) {
  const result = { _: [] };
  let i = 0;
  while (i < args.length) {
    if (args[i].startsWith('--')) {
      const key = args[i].slice(2);
      const val = (i + 1 < args.length && !args[i + 1].startsWith('--')) ? args[++i] : true;
      result[key] = val;
    } else {
      result._.push(args[i]);
    }
    i++;
  }
  return result;
}

// --- Commands ---

function cmdCreate(args) {
  if (!args.name) {
    out({ success: false, error: 'Missing required --name', usage: 'node goals.js create --name "..." --description "..." --metric "..." --deadline "YYYY-MM-DD" --project "..."' });
    process.exit(1);
  }

  const store = loadStore();
  const goal = {
    id: generateId(),
    name: args.name,
    description: args.description || args.name,
    successMetric: args.metric || 'To be defined',
    deadline: args.deadline || null,
    project: args.project || 'General',
    status: 'active',
    todoListName: `🎯 ${args.name}`,
    heartbeatSchedule: args.schedule || '0 9,13,17 * * 1-5',
    heartbeatTaskId: null,
    createdAt: new Date().toISOString(),
    lastReviewAt: null,
    stats: {
      totalHeartbeats: 0,
      tasksCompleted: 0,
      tasksTotal: 0,
      consecutiveIdles: 0,
      consecutiveFailures: 0,
      lastHeartbeatAt: null
    },
    decisionLog: []
  };

  store.goals.push(goal);
  saveStore(store);

  // Create log directory for this goal
  const logDir = path.join(LOGS_DIR, goal.id);
  fs.mkdirSync(logDir, { recursive: true });

  out({ success: true, goal, message: `Goal created. Next: decompose into tasks and register heartbeat.` });
}

function cmdList() {
  const store = loadStore();
  const summary = store.goals.map(g => ({
    id: g.id,
    name: g.name,
    project: g.project,
    status: g.status,
    progress: `${g.stats.tasksCompleted}/${g.stats.tasksTotal}`,
    deadline: g.deadline,
    lastHeartbeat: g.stats.lastHeartbeatAt
  }));
  out({ success: true, goals: summary, total: summary.length, active: summary.filter(g => g.status === 'active').length });
}

function cmdShow(goalId) {
  if (!goalId) {
    out({ success: false, error: 'Missing goalId', usage: 'node goals.js show <goalId>' });
    process.exit(1);
  }
  const store = loadStore();
  const goal = findGoal(store, goalId);
  if (!goal) {
    out({ success: false, error: `Goal not found: ${goalId}` });
    process.exit(1);
  }
  out({ success: true, goal });
}

function cmdPause(goalId) {
  if (!goalId) {
    out({ success: false, error: 'Missing goalId' });
    process.exit(1);
  }
  const store = loadStore();
  const goal = findGoal(store, goalId);
  if (!goal) {
    out({ success: false, error: `Goal not found: ${goalId}` });
    process.exit(1);
  }
  goal.status = 'paused';
  goal.updatedAt = new Date().toISOString();
  saveStore(store);
  out({ success: true, message: `Goal "${goal.name}" paused. Heartbeat task should be cancelled separately.`, goalId });
}

function cmdResume(goalId) {
  if (!goalId) {
    out({ success: false, error: 'Missing goalId' });
    process.exit(1);
  }
  const store = loadStore();
  const goal = findGoal(store, goalId);
  if (!goal) {
    out({ success: false, error: `Goal not found: ${goalId}` });
    process.exit(1);
  }
  goal.status = 'active';
  goal.stats.consecutiveIdles = 0;
  goal.stats.consecutiveFailures = 0;
  goal.updatedAt = new Date().toISOString();
  saveStore(store);
  out({ success: true, message: `Goal "${goal.name}" resumed. Re-register heartbeat if needed.`, goalId });
}

function cmdComplete(goalId) {
  if (!goalId) {
    out({ success: false, error: 'Missing goalId' });
    process.exit(1);
  }
  const store = loadStore();
  const goal = findGoal(store, goalId);
  if (!goal) {
    out({ success: false, error: `Goal not found: ${goalId}` });
    process.exit(1);
  }
  goal.status = 'completed';
  goal.completedAt = new Date().toISOString();
  goal.updatedAt = new Date().toISOString();
  saveStore(store);
  out({
    success: true,
    message: `Goal "${goal.name}" completed! Cancel heartbeat task and write summary to MEMORY.md.`,
    goalId,
    stats: goal.stats
  });
}

function cmdLog(goalId, args) {
  if (!goalId) {
    out({ success: false, error: 'Missing goalId', usage: 'node goals.js log <goalId> --task "..." --tier "G|Y|R" --outcome "..."' });
    process.exit(1);
  }
  const store = loadStore();
  const goal = findGoal(store, goalId);
  if (!goal) {
    out({ success: false, error: `Goal not found: ${goalId}` });
    process.exit(1);
  }

  const now = new Date();
  const ts = now.toISOString().replace(/[T:]/g, '-').slice(0, 16);
  const logEntry = {
    goalId,
    goalName: goal.name,
    heartbeatNumber: goal.stats.totalHeartbeats + 1,
    timestamp: now.toISOString(),
    task: args.task || 'unknown',
    tier: args.tier || 'G',
    outcome: args.outcome || 'completed',
    auditRating: args['audit-rating'] || null,
    notes: args.notes || null
  };

  // Write log file
  const logDir = path.join(LOGS_DIR, goalId);
  fs.mkdirSync(logDir, { recursive: true });
  const logFile = path.join(logDir, `heartbeat-${ts}.json`);
  fs.writeFileSync(logFile, JSON.stringify(logEntry, null, 2), 'utf-8');

  // Update stats
  goal.stats.totalHeartbeats++;
  goal.stats.lastHeartbeatAt = now.toISOString();

  if (logEntry.outcome === 'completed') {
    goal.stats.tasksCompleted++;
    goal.stats.consecutiveIdles = 0;
    goal.stats.consecutiveFailures = 0;
  } else if (logEntry.outcome === 'idle') {
    goal.stats.consecutiveIdles++;
  } else if (logEntry.outcome === 'failed') {
    goal.stats.consecutiveFailures++;
  }

  goal.updatedAt = now.toISOString();
  saveStore(store);

  out({ success: true, log: logEntry, logFile, stats: goal.stats });
}

function cmdUpdateStats(goalId, args) {
  if (!goalId || !args.field) {
    out({ success: false, error: 'Missing goalId or --field', usage: 'node goals.js update-stats <goalId> --field <field> --value <value>' });
    process.exit(1);
  }
  const store = loadStore();
  const goal = findGoal(store, goalId);
  if (!goal) {
    out({ success: false, error: `Goal not found: ${goalId}` });
    process.exit(1);
  }

  const field = args.field;
  let value = args.value;

  // Type coercion based on existing field type
  if (field in goal.stats) {
    if (typeof goal.stats[field] === 'number') {
      value = Number(value);
    }
    goal.stats[field] = value;
  } else {
    out({ success: false, error: `Unknown stat field: ${field}. Valid: ${Object.keys(goal.stats).join(', ')}` });
    process.exit(1);
  }

  goal.updatedAt = new Date().toISOString();
  saveStore(store);
  out({ success: true, goalId, field, value, stats: goal.stats });
}

function cmdAddDecision(goalId, args) {
  if (!goalId || !args.decision) {
    out({ success: false, error: 'Missing goalId or --decision' });
    process.exit(1);
  }
  const store = loadStore();
  const goal = findGoal(store, goalId);
  if (!goal) {
    out({ success: false, error: `Goal not found: ${goalId}` });
    process.exit(1);
  }

  const entry = {
    date: new Date().toISOString().slice(0, 10),
    decision: args.decision,
    rationale: args.rationale || ''
  };
  goal.decisionLog.push(entry);
  goal.updatedAt = new Date().toISOString();
  saveStore(store);
  out({ success: true, goalId, entry, totalDecisions: goal.decisionLog.length });
}

// --- Main ---

const args = parseArgs(process.argv.slice(2));
const cmd = args._[0];

switch (cmd) {
  case 'create':
    cmdCreate(args);
    break;
  case 'list':
    cmdList();
    break;
  case 'show':
    cmdShow(args._[1]);
    break;
  case 'pause':
    cmdPause(args._[1]);
    break;
  case 'resume':
    cmdResume(args._[1]);
    break;
  case 'complete':
    cmdComplete(args._[1]);
    break;
  case 'log':
    cmdLog(args._[1], args);
    break;
  case 'update-stats':
    cmdUpdateStats(args._[1], args);
    break;
  case 'add-decision':
    cmdAddDecision(args._[1], args);
    break;
  default:
    out({
      error: `Unknown command: ${cmd || '(none)'}`,
      commands: ['create', 'list', 'show', 'pause', 'resume', 'complete', 'log', 'update-stats', 'add-decision'],
      usage: 'node goals.js <command> [options]'
    });
    process.exit(1);
}
