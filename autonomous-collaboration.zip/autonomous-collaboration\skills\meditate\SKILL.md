---
name: meditate
description: "{AGENT_NAME}'s self-improvement cycle — deliberate introspection over her own performance, memory hygiene, and system health. Runs as nightly scheduled task (23:30) or on-demand via /meditate. Analyzes proposal outcomes, detects stale memory, audits scheduled tasks, and generates actionable self-improvement insights. Safe actions execute automatically; risky ones queue for morning review."
---

# Meditate — {AGENT_NAME}'s Self-Improvement Cycle

**SOUL** (who I am) → **INSTINCT** (what I've learned) → **MEDITATE** (how I grow)

Meditation is {AGENT_NAME}'s deliberate, periodic self-examination. It reads all internal state — heartbeat, proposals, memory, instincts — and produces insights + actions to become better.

## Usage

```bash
# Full meditation cycle (all phases)
node {HOME_DIR}/teams-tasks/.claude/skills/meditate/scripts/meditate.js

# Specific phase only
node meditate.js --phase diagnose|reflect|hygiene|propose|self-heal

# Dry run — show what would happen, don't write anything
node meditate.js --dry-run

# Output raw JSON
node meditate.js --json
```

## When This Runs

| Trigger | How |
|---------|-----|
| **Nightly** | Recurring scheduled task at 23:30, after daily-worklog (22:00) |
| **On-demand** | User says `/meditate` or "time to meditate" |
| **Post-incident** | After a failed scheduled task or high-rejection streak |

## The Five Phases

### Phase 1: DIAGNOSE — Read the heartbeat
Read all state files and compute health metrics.

**Inputs:** heartbeat.js --json, proposal-outcomes.jsonl, scheduled-tasks.json, monitors.json
**Outputs:** Health score per subsystem, anomaly flags

Checks:
- Scheduled tasks: any failed? any overdue? any paused too long?
- Chat monitors: any with consecutiveFailures > 0? any unused slots?
- Action queue: approval rate trend (today vs 7-day avg)
- Disk: session/queue size growth rate

### Phase 2: REFLECT — Analyze patterns + deep LLM analysis
Go deeper than INSTINCT.md's approval rates. Look at *why* things are denied, *when* they succeed, and *what context matters*.

**Inputs:** proposal-outcomes.jsonl (full history), INSTINCT.md
**Outputs:** Pattern insights + deep-pattern rules (LLM-analyzed)

Analyses:
- **Temporal patterns**: "Proposals denied more on weekends" or "during leave period"
- **Context patterns**: "summarize-transcript approved only for Concordia/Halo meetings, never for FW Daily Sync"
- **Deep LLM analysis**: For high-volume action types (3+ approved, 5+ denied), uses LLM to extract concrete RULE/SKIP pairs (e.g., "RULE: propose for DKI meetings | SKIP: for Daily Syncs"). Max 5 buckets per run, graceful fallback if proxy unavailable.
- **Duplicate detection**: Same proposalId appearing multiple times in outcomes (data quality issue)
- **Instinct staleness**: Preferences that haven't been re-evaluated in >7 days

Deep insights are written to a dedicated `<!-- meditation-insights-start/end -->` section in INSTINCT.md, separate from ProposalReflector's learned-preferences section. When deep insights exist, the section includes a `meditation-calibrated` marker that tells ProposalReflector to defer overwriting.

### Phase 3: MEMORY HYGIENE — Escalation-based cleanup
Scan MEMORY.md for issues with escalation tiers to avoid repeating the same flag every night.

**Inputs:** MEMORY.md, INSTINCT.md, current date, meditation-hygiene-state.json
**Outputs:** Hygiene report + archive actions

**Escalation tiers:**
| Tier | Trigger | Behavior |
|------|---------|----------|
| 0 | First flag | Report normally in meditation log |
| 1 | Second flag | Report with `[Repeated]` prefix, escalate severity |
| 2 | Third flag | Auto-archive with `[ARCHIVED yyyy-mm-dd]` prefix |
| 3+ | Subsequent | Silently skip — stop mentioning |

State is persisted in `{HOME_DIR}/meditation-hygiene-state.json` (atomic write). Entries pruned weekly if tier 3+ and not flagged for 30 days. Already-archived lines are always skipped.

Checks:
- **Stale TODOs**: [TODO] entries with dates > 14 days old
- **Expired plans**: [PLAN] entries past 30 days
- **Deadline detection**: Text containing "by March 15" etc.
- **Stale facts**: [FACT] entries > 60 days old
- **Leave awareness**: Detects leave end dates for return-to-work prep

### Phase 3b: INSTINCT WRITING — Write contextual rules from meditation
After deep reflect analysis, writes concrete, narrow rules to INSTINCT.md based on LLM-extracted patterns. These are more specific than ProposalReflector's statistical preferences.

Also tracks proposal-for-review repetition via `meditation-proposals-tracker.json`:
- Proposals with `trackingKey` are tracked across nights
- After 3 appearances: annotated as `[STALE-PROPOSAL]`
- After 5 appearances: auto-archived (stop proposing)

### Phase 3c: SELF-HEAL — Detect and fix infrastructure issues
Checks {AGENT_NAME} infrastructure health and applies safe fixes.

**Checks:**
- Daemon health (port 11711)
- Copilot Proxy health (port 23333)
- KG server health
- Outcomes file size (rotates if >1MB, archives older entries)
- Meditation log size (rotates if >500KB, archives older entries)
- Stale background sessions (detection only — SessionCleaner handles cleanup)
- Scheduler reports (detection only — reportStore handles GC)
- Monitor consecutive failures (detection — logged for awareness)

**Safety:** Self-heal NEVER creates/cancels tasks, NEVER sends messages, NEVER modifies SOUL.md. All fixes are local file rotation/cleanup operations.

### Phase 4: PROPOSE — Generate self-improvement actions
Based on diagnose + reflect + hygiene, generate 0-5 concrete actions.

**Action classification:**

| Safety | Examples | Behavior |
|--------|----------|----------|
| **Safe** (auto-execute) | Deduplicate outcomes log, update stale dates in MEMORY.md, clean session files | Execute immediately, log result |
| **Risky** (queue for review) | Create new scheduled task, modify instinct thresholds, add/remove monitor | Write to meditation-log.md, present in morning briefing |

### Phase 5: LOG — Append to meditation log
Every meditation cycle produces a dated entry in `{HOME_DIR}/meditation-log.md`.

## Output Files

| File | Purpose |
|------|---------|
| `{HOME_DIR}/meditation-log.md` | Append-only log of all meditation cycles |
| `{HOME_DIR}/INSTINCT.md` | May be updated (learned preferences + meditation insights sections) |
| `{HOME_DIR}/MEMORY.md` | May be updated (auto-archive of stale entries — safe ops only) |
| `{HOME_DIR}/meditation-hygiene-state.json` | Escalation tier tracking per MEMORY.md item |
| `{HOME_DIR}/meditation-proposals-tracker.json` | Tracks proposal-for-review repetition across nights |
| `{HOME_DIR}/proposal-outcomes-archive-*.jsonl` | Rotated outcome archives (created by self-heal) |

## Safety Rules (CRITICAL)

1. **NEVER delete MEMORY.md entries** — only archive with [ARCHIVED date] prefix or flag as [DEPRECATED]
2. **NEVER modify SOUL.md** — identity is immutable by meditation
3. **NEVER create/cancel/disable scheduled tasks automatically** — always queue for review
4. **NEVER send messages or emails** — meditation is internal-only
5. **NEVER modify source code** — meditation operates on state files only
6. **Log everything** — every action (even skipped ones) goes to meditation-log.md
7. **Dry-run by default in first week** — set `--dry-run` until user trusts the cycle
8. **Self-heal: rotation not deletion** — outcomes and logs are archived/rotated, never truncated or deleted
9. **Self-heal: detection for managed services** — session cleanup and report GC are detection-only (existing TS services handle cleanup)

## Meditation Log Format

```markdown
---
## 🧘 Meditation — Feb 27, 2026 23:30

### Health Score: 7/10

### Diagnose
- ✅ 7/8 scheduled tasks healthy
- ⚠️ calendar-conflict-check paused 2d — still relevant?
- ✅ 3/10 monitor slots used, 0 failures
- 📊 Action queue: 0% 24h approval (leave context)

### Reflect
- 📈 Proposal approval dropped from 20% → 0% since leave started (2/24)
- 🔍 summarize-transcript: 2/2 approved for Concordia, 0/13 for other meetings
- 🔄 Duplicate proposalIds in outcomes log: 4 entries × 5 copies each

### Memory Hygiene
- 📅 [TODO] "Roadmap: Voice Wake + ElevenLabs TTS..." — no deadline, stale since 2/20
- 📅 [ASK] Qi Zhang's 3 asks — "Outlook scenario by March" deadline approaching (4 days)
- ✅ No contradictions found

### Actions Taken (safe)
- 🧹 Deduplicated proposal-outcomes.jsonl: 685 → ~140 unique entries

### Proposals for Review (risky)
- 💡 Add context-aware instinct: suppress all action proposals during leave (2/24–3/9)
- 💡 Re-enable calendar-conflict-check when leave ends (3/10)
- 💡 Create monitor for Qi Zhang (Concordia deadline approaching)

---
```

## Integration Points

| System | How Meditate Uses It |
|--------|---------------------|
| **Heartbeat** | Phase 1 input — `heartbeat.js --json` for current state |
| **ProposalReflector** | Complementary — Reflector updates INSTINCT.md reactively; Meditate writes deeper rules to a separate section |
| **ProposalAgent** | Reads INSTINCT.md (both Reflector + Meditation sections) for proposal generation |
| **Copilot Proxy** | Deep reflect uses proxy at port 23333 for LLM analysis calls |
| **Scheduled Tasks** | Meditate runs AS a scheduled task; also audits other tasks |
| **Morning Briefing** | Risky proposals from meditation surface in 8am briefing |
| **Memory Write** | Safe MEMORY.md archival uses `[ARCHIVED date]` prefix format |
| **Daemon** | Self-heal checks daemon health; KG ingest calls daemon endpoint |
| **SessionCleaner** | Self-heal detects stale sessions; SessionCleaner handles actual cleanup |

## Design Philosophy

Meditation is NOT a replacement for existing systems. It's a **meta-layer** that reviews how well other systems are working and suggests corrections.

```
ProposalReflector: "This action type has 0% approval" (reactive, statistical)
Meditate:          "WHY does it have 0% approval? Is it the action, the timing, or the context?" (deliberate, analytical)
```

The key difference: ProposalReflector computes stats. Meditate interprets them.
