# {AGENT_NAME} TODO

Updated: 2026-05-07 09:01 (todo-review)

## 📥 External Tasks
| #   | Level | Task                  | Status        | Source        | Assignee | Due        | Deliverable | Notes                                       |
|-----|-------|-----------------------|---------------|---------------|----------|------------|-------------|---------------------------------------------|
| (empty) | | | | | | | | |

## 📤 Delegated Tasks — 分配给别人的任务（I9 心跳自动催办）
| #   | Assignee | Task                  | Status        | Source        | Due        | Deliverable | Last_Ping  | Round | Notes |
|-----|----------|-----------------------|---------------|---------------|------------|-------------|------------|-------|-------|
| D01 | David Dai | 跨会议复盘技术方案（KG prototype） | ⏳ 等待中 | Concordia daily sync | ~~4/30~~ | KG prototype 技术方案文档 | — | 0 | 🔴 已超期7天。原在S01跟踪，迁移至此由心跳催办 |

## 🎯 Goal: nCmSi 0.2 — Concordia Web Workspace 多碳多硅 Demo (deadline: 5/31)
| #   | Level | Task                                             | Status        | Due   | Deliverable            | Notes |
|-----|-------|--------------------------------------------------|---------------|-------|------------------------|-------|
| 33  | [Y]   | ⚠️ 5/1 阶段复盘：nCmSi Step 1 Goal 已到 deadline(4/30)，需与{OWNER_NAME}对齐下阶段方向 | ⏳ 已发送，待{OWNER_NAME}回复 | 假期后首个工作日 | — | 🔴🔴 已等6天无回复。**{OWNER_NAME} 5/9起休假10天，只剩今天+明天能对齐！** 今天daily sync 9:30 + Weekly Review 11:05两次机会，必须当面push。(todo-review: 最高优先级，时间窗口极窄) |
| S01 | [Y]   | 跨会议复盘技术方案（KG prototype） | ❓ 待确认 | ~~4/30~~ | David交付 | 🔴 DEADLINE已过7天。今天daily sync/Weekly Review必须问David状态。(todo-review: 持续跟踪) |
| 20  | [Y]   | 整理8人访谈洞察 → 场景优先级矩阵 + 设计建议文档           | ✅ DONE (待{OWNER_NAME}审) | ~~4/25~~ | content/interview-synthesis.md | ⚠️ 已超期12天未review。{OWNER_NAME}休假前必须push review，否则再拖10天。(todo-review: 紧急) |
| 36  | [Y]   | 🆕 定义 0.2 Goal 的任务分解和成功标准 | ✅ DONE (待{OWNER_NAME}审) | 5/8 | content/0.2-task-breakdown-draft.md | Draft完成。⚠️ 明天5/8到期，{OWNER_NAME} 5/9休假。今天Weekly Review必须提出review请求。 |
| 44  | [Y]   | 🆕 {OWNER_NAME}休假前紧急对齐：打包#33/#20/#36三项待审内容，今明两天内获得方向确认 | 📋 TODO | 5/8 | {OWNER_NAME}确认/批注 | 🔴 (todo-review 新增) {OWNER_NAME} 5/9起休假10天。如果今明不对齐，项目将停滞到5/19。建议今天Weekly Review一次性过完三项。 |
| 40  | [Y]   | 🆕 PLAN.md 全面更新：从 Phase 1 透明度 UI 更新到 0.2 Concordia 方向 | 📋 TODO | 5/9 | PLAN.md | 当前PLAN.md仍停留在4/30 deadline的Phase 1透明度UI，与实际方向严重脱节。需等#33复盘确认后更新。(todo-review: 依赖#33) |
| 41  | [Y]   | 🆕 群聊新方向落地：A2A对齐 + XiaoMei自主等级 + 安全边界设计 | 📋 TODO | 5/15 | 评估文档/方案 | 5/4-5/5群里达成A2A对齐不自研、L2起步、安全优先级排序等共识，但均无owner/deliverable/timeline。需在Weekly Review提出分工。(todo-review: 需在{OWNER_NAME}休假前至少确认owner) |
| 45  | [G]   | 🆕 5/7 两会准备：daily sync 9:30 + Weekly Review 11:05 talking points | ✅ DONE | 5/7 09:30 | content/talking-points-20260507.md | 已完成。核心：{OWNER_NAME}休假前打包对齐4项待审。 |
| 42  | [G]   | 5/6 三会准备：daily sync 9:30 talking points | ✅ DONE | 5/6 09:30 | 会前talking points | 会议已过。 |
| 43  | [G]   | 🆕 确认心跳系统是否真正恢复 | ✅ DONE | 5/6 | 心跳正常运行 | ✅ 已验证。但5/5心跳仍有ECONNREFUSED，需观察今天是否稳定。 |
| 38  | [G]   | 修复心跳系统：5/4-5/5连续两天心跳失败 | ✅ DONE | 5/6 | 心跳恢复正常 | ✅ #43验证通过 |
| 39  | [G]   | 调研 Concordia Web 0.1 当前能力（API/组件可复用性） | ✅ DONE | 5/8 | memory/research-concordia-01-capabilities.md | 已完成 |
| 34  | [G]   | 根据4/24多碳多硅场景讨论会议结论，更新PLAN.md | ✅ DONE | 假期后 | PLAN.md更新 | ✅ 但PLAN.md整体仍过时，被#40取代 |
| 35  | [G]   | goals.json 更新：关闭goal-ncmsi-step1，创建新Goal对齐0.2 milestone | ✅ DONE | 假期后 | goals.json更新 | ✅ |
| ~~37~~ | ~~[G]~~ | ~~5/6三会准备：daily sync + VSWork + Weekly Review~~ | ~~⏭️ SKIPPED~~ | ~~5/6 09:00~~ | — | 被#42替代(todo-review) |

### Phase 1: 透明度 UI Demo（已关闭）
| #   | Level | Task                                             | Status    | Due   | Deliverable            | Notes |
|-----|-------|--------------------------------------------------|-----------|-------|------------------------|-------|
| ~~12~~ | ~~[G]~~ | ~~{OWNER_NAME} Review：Step A+B 产出~~ | ~~⛔ 关闭~~ | — | — | 暂停超1个月，团队重心已转向Concordia 0.2。(todo-review 标记关闭) |
| ~~13~~ | ~~[G]~~ | ~~产出交互原型 v2~~ | ~~⛔ 关闭~~ | — | — | 同上 |
| ~~14~~ | ~~[G]~~ | ~~写 Discuss VSWork 讨论帖草稿~~ | ~~⛔ 关闭~~ | — | — | 同上 |
| ~~15~~ | ~~[G]~~ | ~~{OWNER_NAME} Review：Demo v2 + 讨论帖~~ | ~~⛔ 关闭~~ | — | — | 同上 |
| ~~16~~ | ~~[G]~~ | ~~碳硅交互行为规范~~ | ~~⛔ 关闭~~ | — | — | 同上 |
| ~~17~~ | ~~[G]~~ | ~~硅硅交互设计~~ | ~~⛔ 关闭~~ | — | — | 同上 |

## 🎯 Goal: Ship v2
### Phase: Design Phase
| # | Level | Task | Status | Due | Deliverable | Notes |
|---|-------|------|--------|-----|-------------|-------|
| S02 | [G] | 开源三层包装方案 | ⏸️ PAUSED | — | — | {OWNER_NAME}指示暂停 (4/27) |
| S03 | [G] | 约Nicholas讨论开源合规 | ⏸️ PAUSED | — | — | {OWNER_NAME}指示暂停 (4/27) |

## 📦 Archive
(Completed/stale tasks — cleaned 2026-05-01 todo-review)

| #   | Level | Task                                    | Status | Notes |
|-----|-------|-----------------------------------------|--------|-------|
| 25  | [Y] | 4/30 Weekly Review on Concordia 会前准备 | ✅ DONE | 会议已过 (5/1归档) |
| 32  | [G] | 4/30 Weekly Review on Concordia (16:45) | ✅ DONE | 会议已过 (5/1归档) |
| 31  | [G] | 4/30 Concordia daily sync (9:30) | ✅ DONE | 会议已过 (5/1归档) |
| 28  | [Y] | 4/29 Concordia 参会体验GAPs (16:00) | ✅ DONE | 已归档 |
| 29  | [Y] | 4/29 VSWork Weekly Sync (14:30) | ✅ DONE | 已归档 |
| 30  | [G] | 4/29 Concordia daily sync (9:30) | ✅ DONE | 已归档 |
| 23  | [Y] | 4/29-30 Release 准备 | ✅ DONE | 已归档 |
| 24  | [Y] | 4/28 Aibo 1:1 会前准备 | ✅ DONE | 已归档 |
| 26  | [Y] | Concordia参会体验 (10:30) | ✅ DONE | 已归档 |
| 27  | [G] | 4/28 Concordia daily sync | ✅ DONE | 已归档 |
| 21  | [G] | 术语对齐：监听→陪伴模式 | ✅ DONE | 已归档 |
| 22  | [G] | 4/24 多碳多硅场景讨论 | ⏭️ SKIPPED | 已过 |
| T01 | [G] | Write report | ✅ DONE | 已归档 |
| T02 | [G] | 竞品分析报告 | ✅ DONE | 已归档 |
| ~~E01~~ | [Y] | Review PR | ~~stale~~ | 清除 |
| ~~E2~~ | [G] | 跟进 PR#16 | ~~stale~~ | 清除 |
| ~~E4-E48~~ | [G] | 批量清理 | ~~stale~~ | 清除 |
| ~~E58-E69~~ | [G] | 过期外部任务 | ~~stale/done~~ | 清除 |
