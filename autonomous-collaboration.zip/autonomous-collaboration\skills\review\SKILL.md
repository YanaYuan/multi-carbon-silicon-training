---
name: review
description: "On-demand review meeting — {OWNER_NAME} reviews all heartbeat outputs via an interactive HTML dashboard with AI chat sidebar. Use when user says '/review', 'review一下', '看看进展', '需要我做什么决策', 'what needs my attention', 'show me what you've done', 开个review meeting。"
---

# Review — {AGENT_NAME} 与 {OWNER_NAME} 的交互式 Review Dashboard

`/review` 是 {OWNER_NAME} 按需触发的 review 会议。与之前纯文本的对话式 review 不同，现在会生成一个 **HTML Dashboard**，{OWNER_NAME} 在浏览器中直接浏览待审项、做决策、跟 {AGENT_NAME} 实时对话。

## 触发方式

- `/review` — 生成 dashboard 并打开
- 自然语言："看看进展"、"需要我做什么"、"review 一下"

## 执行流程

### Step 1: 生成 Review Dashboard HTML

```bash
# 解析 TODO.md → 生成 _review.html
node {HOME_DIR}/teams-tasks/.claude/skills/review/scripts/generate-review.mjs --open --port 3457
```

这会：
1. 读取 `{HOME_DIR}/TODO.md`
2. 解析所有 External Tasks 和 Goal Tasks
3. 按状态分类：Needs Decision [R] / Needs Review [Y] / In Progress [G] / On Hold / Completed
4. 注入数据到 HTML 模板
5. 生成 `{HOME_DIR}/teams-tasks/outputs/_review.html`
6. 在默认浏览器中打开

### Step 2: 启动 Review Server（WebSocket + Claude CLI）

```bash
# 在后台启动 WebSocket server
node {HOME_DIR}/teams-tasks/.claude/skills/review/scripts/review-server.mjs 3457
```

这会启动一个 `localhost:3457` 的 WebSocket 服务器。当 {OWNER_NAME} 在 dashboard 侧边栏中发送消息时：
- Server 接收消息 + item 上下文
- Spawn Claude CLI 子进程（`claude -p --model sonnet`）
- 流式回传 Claude 的响应到浏览器

### Step 3: Dashboard 交互

{OWNER_NAME} 在浏览器中：
1. 看到所有待办项的卡片列表（按 Decision / Review / Action / Hold / Done 分类）
2. 点击某个 item → 右侧弹出 **AI Chat Sidebar**
   - 展示 item 完整上下文（来源、分配人、截止日期、交付物路径）
   - 预设决策按钮（Approve / Show deliverable / Request changes / Hold）
   - 自由文本对话
3. {AGENT_NAME} 实时回复，可以：
   - 读取交付物文件并摘要
   - 更新 TODO.md 状态
   - 回答关于 item 的任何问题

### Step 4: 结束 Review

{OWNER_NAME} 关闭浏览器 tab 即可。所有决策已由 {AGENT_NAME} 在对话中实时写入 TODO.md。

## 文件结构

```
.claude/skills/review/
├── SKILL.md                          # 本文件
├── scripts/
│   ├── generate-review.mjs           # TODO.md → _review.html 生成器
│   ├── review-server.mjs             # WebSocket server (Claude CLI bridge)
│   └── review-template.html          # HTML dashboard 模板
└── node_modules/
    └── ws/                           # WebSocket 依赖
```

## 与旧版 Review 的区别

| 旧版 (文本对话) | 新版 (Dashboard) |
|---|---|
| 在 Teams 对话流中逐项讨论 | 浏览器中可视化看所有 item |
| 缺少上下文，需要反复问路径 | 每个 item 自带完整上下文和文件链接 |
| 决策记录容易丢失 | {AGENT_NAME} 实时更新 TODO.md |
| 无法并行查看多个 item | 可自由切换 item，聊天记录按 item 缓存 |

## 注意事项

1. **Server 端口**：默认 3457（不与 Concordia 的 3456 冲突）
2. **模型**：默认使用 sonnet（速度更快），可通过 `CORTANA_REVIEW_MODEL=opus` 环境变量切换
3. **权限**：server 以 `bypassPermissions` 运行，{AGENT_NAME} 可以直接读写文件
4. **安全**：server 只监听 localhost，不暴露到外部网络
5. **不在心跳中生成**：只在 `/review` 显式触发时生成，避免不必要的开销
