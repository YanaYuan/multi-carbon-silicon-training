# {AGENT_NAME} Heartbeat Runner
# Called by Windows Task Scheduler every hour
# Runs claude -p to execute goal-heartbeat, independent of VS Code/Claude Code daemon

$ErrorActionPreference = "Stop"
$logFile = "$env:USERPROFILE\.{agent_name}\logs\heartbeat-runner.log"

# Ensure log directory exists
$logDir = Split-Path $logFile
if (-not (Test-Path $logDir)) { New-Item -ItemType Directory -Path $logDir -Force | Out-Null }

function Log($msg) {
    $ts = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    "$ts | $msg" | Out-File -Append -FilePath $logFile -Encoding utf8
}

# Check if we're in work hours (Beijing time UTC+8, weekdays 9-22)
$now = [System.TimeZoneInfo]::ConvertTimeBySystemTimeZoneId([DateTime]::UtcNow, "China Standard Time")
$hour = $now.Hour
$dow = $now.DayOfWeek

if ($dow -eq "Saturday" -or $dow -eq "Sunday") {
    Log "SKIP: Weekend ($dow)"
    exit 0
}

if ($hour -lt 9 -or $hour -ge 18) {
    Log "SKIP: Outside work hours ($hour`:00 Beijing)"
    exit 0
}

Log "START: heartbeat-runner (Beijing: $($now.ToString('HH:mm')), $dow)"

# Unset CLAUDECODE env var to allow nested execution
$env:CLAUDECODE = $null

# Read the prompt from file to avoid escaping issues
$promptFile = "$env:USERPROFILE\.{agent_name}\scripts\heartbeat-prompt.md"
$prompt = Get-Content $promptFile -Raw

# Change to project directory so claude picks up .claude/ config (CLAUDE.md, skills, etc.)
$projectDir = "$env:USERPROFILE\.{agent_name}\teams-tasks"
Push-Location $projectDir

try {
    $result = & "Q:\.tools\.npm-global\claude.cmd" -p $prompt --max-turns 30 --dangerously-skip-permissions 2>&1
    $lastLines = $result | Select-Object -Last 5 | Out-String
    Log "DONE: $lastLines"
} catch {
    Log "ERROR: $($_.Exception.Message)"
} finally {
    Pop-Location
}
