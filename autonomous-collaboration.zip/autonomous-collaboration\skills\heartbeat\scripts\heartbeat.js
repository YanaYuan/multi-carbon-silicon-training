#!/usr/bin/env node
/**
 * Heartbeat — {AGENT_NAME}'s unified proactive activity dashboard.
 * Aggregates: scheduled tasks, chat monitors, action queue, instincts.
 *
 * Usage:
 *   node heartbeat.js            # Full formatted report
 *   node heartbeat.js --json     # Raw JSON
 *   node heartbeat.js --section tasks|monitors|queue|instincts
 */

const fs = require('fs');
const path = require('path');
const os = require('os');
const { execSync } = require('child_process');

// --- Paths ---
const CORTANA_HOME = path.join(os.homedir(), '.{agent_name}');
const TASKS_FILE = path.join(CORTANA_HOME, 'teams-tasks', 'scheduled-tasks.json');
const MONITORS_FILE = path.join(CORTANA_HOME, 'teams-tasks', 'monitors.json');
const ACTION_QUEUE_FILE = path.join(CORTANA_HOME, 'action-queue.json');
const INSTINCT_FILE = path.join(CORTANA_HOME, 'INSTINCT.md');
const OUTCOMES_FILE = path.join(CORTANA_HOME, 'proposal-outcomes.jsonl');
const GOALS_FILE = path.join(CORTANA_HOME, 'goals.json');

// --- Helpers ---
function readJSON(filePath) {
  try {
    return JSON.parse(fs.readFileSync(filePath, 'utf8'));
  } catch {
    return null;
  }
}

function readText(filePath) {
  try {
    return fs.readFileSync(filePath, 'utf8');
  } catch {
    return null;
  }
}

function timeAgo(ms) {
  if (!ms) return 'never';
  const diff = Date.now() - ms;
  if (diff < 0) return timeUntil(ms);
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  const days = Math.floor(hrs / 24);
  return `${days}d ago`;
}

function timeUntil(ms) {
  if (!ms) return '--';
  const diff = ms - Date.now();
  if (diff < 0) return 'overdue';
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'now';
  if (mins < 60) return `in ${mins}m`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `in ${hrs}h`;
  const days = Math.floor(hrs / 24);
  return `in ${days}d`;
}

function cronToHuman(expr) {
  if (!expr) return '?';
  const parts = expr.split(' ');
  if (parts.length !== 5) return expr;
  const [min, hour, , , dow] = parts;

  const dowMap = { '0': 'Sun', '1-5': 'weekdays', '*': 'daily', '5': 'Fri' };
  const dowStr = dowMap[dow] || `dow:${dow}`;

  const hours = hour.split(',');
  if (hours.length > 1) {
    return `${hours.map(h => `${h}:${min.padStart(2, '0')}`).join('/')} ${dowStr}`;
  }
  return `${hour}:${min.padStart(2, '0')} ${dowStr}`;
}

function msToInterval(ms) {
  if (!ms) return '?';
  const mins = Math.floor(ms / 60000);
  if (mins < 60) return `${mins}min`;
  return `${Math.floor(mins / 60)}h`;
}

// --- Section: Scheduled Tasks ---
function getTasksSection() {
  const data = readJSON(TASKS_FILE);
  if (!data?.tasks) return { items: [], enabledCount: 0, totalCount: 0 };

  const items = data.tasks.map(t => ({
    id: t.id,
    name: t.name,
    enabled: t.enabled,
    schedule: t.schedule?.kind === 'cron' ? cronToHuman(t.schedule.expr) : t.schedule?.kind,
    lastRun: t.state?.lastRunAtMs ? timeAgo(t.state.lastRunAtMs) : 'never',
    lastRunMs: t.state?.lastRunAtMs || 0,
    nextRun: t.state?.nextRunAtMs ? timeUntil(t.state.nextRunAtMs) : '--',
    nextRunMs: t.state?.nextRunAtMs || 0,
    runCount: t.state?.runCount || 0,
    lastError: t.state?.lastError || null,
  }));

  return {
    items,
    enabledCount: items.filter(i => i.enabled).length,
    totalCount: items.length,
  };
}

// --- Section: Chat Monitors ---
function getMonitorsSection() {
  const data = readJSON(MONITORS_FILE);
  if (!data?.monitors) return { items: [], activeCount: 0, maxMonitors: 10 };

  const items = data.monitors.map(m => ({
    id: m.id,
    name: m.chatName,
    type: m.chatType,
    enabled: m.enabled,
    interval: msToInterval(m.pollIntervalMs),
    failures: m.consecutiveFailures || 0,
    personFilter: m.personFilter || null,
    suggestReply: m.suggestReply || false,
  }));

  return {
    items,
    activeCount: items.filter(i => i.enabled).length,
    maxMonitors: data.maxMonitors || 10,
  };
}

// --- Section: Action Queue ---
function getQueueSection() {
  const data = readJSON(ACTION_QUEUE_FILE);
  if (!data?.proposals) return { pending: 0, approved: 0, denied: 0, completed: 0, total: 0 };

  const proposals = data.proposals || [];
  const counts = { pending: 0, approved: 0, denied: 0, skipped: 0, completed: 0, failed: 0, executing: 0 };
  for (const p of proposals) {
    counts[p.status] = (counts[p.status] || 0) + 1;
  }

  // Recent proposals (last 24h)
  const oneDayAgo = Date.now() - 86400000;
  const recent = proposals.filter(p => new Date(p.createdAt).getTime() > oneDayAgo);
  const recentApproved = recent.filter(p => p.status === 'approved' || p.status === 'completed').length;
  const recentDenied = recent.filter(p => p.status === 'denied' || p.status === 'skipped').length;
  const approvalRate = (recentApproved + recentDenied) > 0
    ? Math.round(recentApproved / (recentApproved + recentDenied) * 100)
    : null;

  return {
    total: proposals.length,
    pending: counts.pending,
    completed: counts.completed,
    denied: counts.denied + counts.skipped,
    failed: counts.failed,
    recent24h: recent.length,
    approvalRate24h: approvalRate,
  };
}

// --- Section: Instincts ---
function getInstinctsSection() {
  const text = readText(INSTINCT_FILE);
  if (!text) return { rules: [] };

  const rules = [];
  const regex = /\[PROACTIVE-PREFERENCE\]\s+(.+?)(?:\n|$)/g;
  let m;
  while ((m = regex.exec(text)) !== null) {
    const line = m[1];
    // Extract action type, source, and approval rate
    const actionMatch = line.match(/"([^"]+)"/);
    const sourceMatch = line.match(/from\s+([\w-]+)/);
    const rateMatch = line.match(/\((\d+)% approval, n=(\d+)\)/);
    if (actionMatch && rateMatch) {
      const source = sourceMatch ? sourceMatch[1] : '?';
      rules.push({
        action: actionMatch[1],
        source,
        approvalRate: parseInt(rateMatch[1]),
        sampleSize: parseInt(rateMatch[2]),
        suppressed: parseInt(rateMatch[1]) === 0,
      });
    }
  }

  return { rules };
}

// --- Section: Goals ---
function getGoalsSection() {
  const data = readJSON(GOALS_FILE);
  if (!data?.goals || data.goals.length === 0) return null;

  const tasks = readJSON(TASKS_FILE);
  const taskMap = {};
  if (tasks?.tasks) {
    for (const t of tasks.tasks) {
      taskMap[t.id] = t;
    }
  }

  const items = data.goals.map(g => {
    const stepsCompleted = g.steps ? g.steps.filter(s => s.status === 'completed').length : 0;
    const stepsTotal = g.steps ? g.steps.length : 0;
    const lastHb = g.heartbeatLog?.length > 0
      ? g.heartbeatLog[g.heartbeatLog.length - 1]
      : null;
    let nextHeartbeat = null;
    if (g.heartbeatTaskId && taskMap[g.heartbeatTaskId]) {
      const task = taskMap[g.heartbeatTaskId];
      if (task.state?.nextRunAtMs) {
        nextHeartbeat = timeUntil(task.state.nextRunAtMs);
      }
    }
    return {
      displayIndex: g.displayIndex,
      title: g.title,
      status: g.status,
      cron: cronToHuman(g.heartbeatCron),
      stepsCompleted,
      stepsTotal,
      lastHeartbeat: lastHb ? timeAgo(new Date(lastHb.timestamp).getTime()) : 'never',
      lastSummary: lastHb ? lastHb.summary : null,
      nextHeartbeat: nextHeartbeat || '--',
    };
  });

  const activeCount = items.filter(i => i.status === 'active').length;
  return { items, activeCount, totalCount: items.length };
}

// --- Section: Knowledge Graph ---
function getKgSection() {
  try {
    const healthResp = execSync(
      `node -e "const http=require('http');const r=http.get('http://127.0.0.1:11718/health',res=>{let d='';res.on('data',c=>d+=c);res.on('end',()=>{console.log(d);process.exit(0)})});r.on('error',()=>{console.log('{}');process.exit(1)});r.setTimeout(3000,()=>{r.destroy();console.log('{}');process.exit(1)})"`,
      { encoding: 'utf8', timeout: 5000, windowsHide: true }
    ).trim();
    const health = JSON.parse(healthResp || '{}');
    if (health.status !== 'ok') {
      return null;
    }
    return {
      status: health.status,
      episodesToday: health.episodes_today || 0,
      maxEpisodes: health.max_episodes_per_day || 1000,
      extractionModel: health.extraction_model || 'unknown',
      dbPath: health.db_path || 'unknown',
    };
  } catch {
    return null;
  }
}

// --- Formatters ---
function formatText(sections, sectionFilter) {
  const { goals, tasks, monitors, queue, instincts, kg } = sections;
  const show = (name) => !sectionFilter || sectionFilter === name;
  const now = new Date();
  const lines = [];

  lines.push(`# {AGENT_NAME} Heartbeat`);
  lines.push(`_${now.toLocaleString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', hour12: false })}_`);
  lines.push('');

  // --- Goals ---
  if (show('goals') && goals) {
    lines.push(`## Goals (${goals.activeCount}/${goals.totalCount} active)`);
    lines.push('');
    lines.push('| Status | # | Goal | Progress | Next Heartbeat | Last |');
    lines.push('|--------|---|------|----------|----------------|------|');
    for (const g of goals.items) {
      const icon = g.status === 'active' ? '🟢' : g.status === 'paused' ? '⏸️' : g.status === 'completed' ? '✅' : '🚫';
      const progress = g.stepsTotal > 0 ? `${g.stepsCompleted}/${g.stepsTotal}` : '--';
      lines.push(`| ${icon} | #${g.displayIndex} | ${g.title} | ${progress} | ${g.nextHeartbeat} | ${g.lastHeartbeat} |`);
    }
    lines.push('');
  }

  // --- Tasks ---
  if (show('tasks') && tasks) {
    lines.push(`## Scheduled Tasks (${tasks.enabledCount}/${tasks.totalCount} active)`);
    lines.push('');
    lines.push('| Status | Time | Task | Last Run | Next Run | Runs |');
    lines.push('|--------|------|------|----------|----------|------|');
    for (const t of tasks.items) {
      const icon = t.lastError ? '❌' : (t.enabled ? '✅' : '⏸️');
      lines.push(`| ${icon} | ${t.schedule} | ${t.name} | ${t.lastRun} | ${t.nextRun} | ${t.runCount} |`);
    }
    lines.push('');
  }

  // --- Monitors ---
  if (show('monitors') && monitors) {
    lines.push(`## Chat Monitors (${monitors.activeCount}/${monitors.maxMonitors} slots)`);
    lines.push('');
    lines.push('| Status | Chat | Type | Interval | Filter | Reply |');
    lines.push('|--------|------|------|----------|--------|-------|');
    for (const m of monitors.items) {
      const icon = m.failures > 2 ? '⚠️' : (m.enabled ? '👁️' : '⏸️');
      const filter = m.personFilter ? m.personFilter.join(', ') : '--';
      const reply = m.suggestReply ? '💬' : '--';
      lines.push(`| ${icon} | ${m.name} | ${m.type} | ${m.interval} | ${filter} | ${reply} |`);
    }
    lines.push('');
  }

  // --- Queue ---
  if (show('queue') && queue) {
    lines.push(`## Action Queue`);
    lines.push('');
    lines.push(`- **Total proposals:** ${queue.total}`);
    lines.push(`- **Pending:** ${queue.pending}`);
    lines.push(`- **Completed:** ${queue.completed}`);
    lines.push(`- **Denied/Skipped:** ${queue.denied}`);
    lines.push(`- **Failed:** ${queue.failed}`);
    if (queue.approvalRate24h !== null) {
      lines.push(`- **24h approval rate:** ${queue.approvalRate24h}%  (${queue.recent24h} proposals)`);
    }
    lines.push('');
  }

  // --- Instincts ---
  if (show('instincts') && instincts && instincts.rules.length > 0) {
    lines.push(`## Learned Instincts`);
    lines.push('');
    lines.push('| Action | Source | Approval | Samples | Status |');
    lines.push('|--------|--------|----------|---------|--------|');
    for (const r of instincts.rules) {
      const status = r.suppressed ? '🔴 suppressed' : (r.approvalRate < 20 ? '🟡 low' : '🟢 ok');
      lines.push(`| ${r.action} | ${r.source} | ${r.approvalRate}% | n=${r.sampleSize} | ${status} |`);
    }
    lines.push('');
  }

  // Knowledge Graph
  if (show('kg') && kg) {
    lines.push(`## Knowledge Graph`);
    lines.push('');
    lines.push(`- Status: 🟢 ready`);
    lines.push(`- Episodes Today: ${kg.episodesToday} / ${kg.maxEpisodes}`);
    lines.push(`- Model: ${kg.extractionModel}`);
    lines.push('');
  }

  // --- Disk usage ---
  if (show('disk')) {
    try {
      const sessionsDir = path.join(CORTANA_HOME, 'sessions');
      let totalBytes = 0;
      if (fs.existsSync(sessionsDir)) {
        const files = fs.readdirSync(sessionsDir);
        for (const f of files) {
          try {
            totalBytes += fs.statSync(path.join(sessionsDir, f)).size;
          } catch {}
        }
      }
      const queueSize = fs.existsSync(ACTION_QUEUE_FILE) ? fs.statSync(ACTION_QUEUE_FILE).size : 0;
      const kgDir = path.join(CORTANA_HOME, 'knowledge-graph', 'kuzu');
      let kgSize = 0;
      if (fs.existsSync(kgDir)) {
        try {
          const kgFiles = fs.readdirSync(kgDir);
          for (const f of kgFiles) {
            try {
              kgSize += fs.statSync(path.join(kgDir, f)).size;
            } catch {}
          }
        } catch {}
      }
      const totalMB = ((totalBytes + queueSize + kgSize) / 1048576).toFixed(1);
      lines.push(`## Disk`);
      lines.push('');
      lines.push(`- Sessions: ${(totalBytes / 1048576).toFixed(1)} MB (${fs.existsSync(sessionsDir) ? fs.readdirSync(sessionsDir).length : 0} files)`);
      lines.push(`- Action Queue: ${(queueSize / 1048576).toFixed(1)} MB`);
      if (kgSize > 0) {
        lines.push(`- Knowledge Graph DB: ${(kgSize / 1048576).toFixed(1)} MB`);
      }
      lines.push(`- **Total proactive state:** ${totalMB} MB`);
      if (parseFloat(totalMB) > 100) {
        lines.push(`- ⚠️ **Over 100MB** — consider running session cleanup`);
      }
      lines.push('');
    } catch {}
  }

  return lines.join('\n');
}

// --- Main ---
function main() {
  const args = process.argv.slice(2);
  const isJson = args.includes('--json');
  const sectionIdx = args.indexOf('--section');
  const sectionFilter = sectionIdx !== -1 ? args[sectionIdx + 1] : null;

  const all = {
    goals: getGoalsSection(),
    tasks: getTasksSection(),
    monitors: getMonitorsSection(),
    queue: getQueueSection(),
    instincts: getInstinctsSection(),
    kg: getKgSection(),
  };

  if (sectionFilter) {
    const section = all[sectionFilter];
    if (!section) {
      console.error(`Unknown section: ${sectionFilter}. Valid: goals, tasks, monitors, queue, instincts, kg`);
      process.exit(1);
    }
    if (isJson) {
      console.log(JSON.stringify({ [sectionFilter]: section }, null, 2));
    } else {
      console.log(formatText(all, sectionFilter));
    }
    return;
  }

  if (isJson) {
    console.log(JSON.stringify(all, null, 2));
  } else {
    console.log(formatText(all, null));
  }
}

main();
